

def EightNumberToTextDate(NumberDateBefore):
    NumberDate = str(NumberDateBefore)
    Year = NumberDate[0:4]
    Month = NumberDate[4:6]
    Day = NumberDate[6:8]

    TextDate = Year+"年"+Month+"月"+Day+"日"
    #考虑了一下，年不要了
    TextDate = Month+"月"+Day+"日"
    return TextDate