import openpyxl
import sqlite3
import MyStringMethod
from openpyxl.styles import PatternFill, Border, Side, Alignment, Protection, Font

# 填入默认难度
def DefaultWord_Difficult(Sheet_1):
    Sheet_1.cell(1, 2).value = "A"
    Sheet_1.cell(1, 3).value = "B"
    Sheet_1.cell(1, 4).value = "C"
    Sheet_1.cell(1, 5).value = "D"
    Sheet_1.cell(1, 6).value = "E"
    Sheet_1.cell(1, 7).value = "未定义"


# 第一张表写入人名,人名要以ListWorker返回
def AddInName(Sheet_1, Group_In, connent):
    sql = F"SELECT* FROM 员工信息 WHERE 是否隐藏 = '否' AND 所属班组 = '{Group_In}'"
    cursor_1 = connent.execute(sql)
    ListWorker = []
    ListJobNumber = []
    n = 2
    for ThisWorkerName in cursor_1:
        ListWorker.append(ThisWorkerName[1])
        ListJobNumber.append(ThisWorkerName[0])
        Sheet_1.cell(n, 1).value = ThisWorkerName[1]
        n += 1
    return ListWorker, ListJobNumber

# 以ListWorker为依据为第二张表写入人名
def AddInName_Second(Sheet_2, ListWorker):
    n = 2
    for Name in ListWorker:
        Sheet_2.cell(1, n).value = Name
        n += 2

# 把表2中的人名格子合并并居中
def MergeNameCell(Sheet_2,ListWorker):
    n = 2
    for Name in ListWorker:
        Sheet_2.merge_cells(F'{MyStringMethod.TransfromNumberToChar(n)}1:{MyStringMethod.TransfromNumberToChar(n+1)}1')
        Sheet_2.cell(1, n).alignment = Alignment(horizontal='center', vertical='center', wrapText=True)
        n += 2

# 给表2填入详细的任务列表和时间，并返回该难度下该人的总时间
def WriteInPartTime(Sheet_2, connent, Difficult, Worker, TimeMin, TimeMax, ColWorker, RowMaxEnd, RowMaxMark):
    TotalTime = 0
    RowThisArea = RowMaxEnd


    sql_temp = F"""
        SELECT * FROM 任务分配0试制班 INNER JOIN 任务信息 ON 任务分配0试制班.统一编号 = 任务信息.统一编号 WHERE 项目等级 = '{Difficult}' AND 工号 = {Worker} AND 发布时间 >= {TimeMin} AND 发布时间 <= {TimeMax} AND 工作类型 <> '（请假）' AND 工作类型 <> '（分配标记）'
        UNION
        SELECT * FROM 任务分配0试验班 INNER JOIN 任务信息 ON 任务分配0试验班.统一编号 = 任务信息.统一编号 WHERE 项目等级 = '{Difficult}' AND 工号 = {Worker} AND 发布时间 >= {TimeMin} AND 发布时间 <= {TimeMax} AND 工作类型 <> '（请假）' AND 工作类型 <> '（分配标记）' 
        UNION
        SELECT * FROM 台架分配 INNER JOIN 任务信息 ON 台架分配.统一编号 = 任务信息.统一编号 WHERE 项目等级 = '{Difficult}' AND 工号 = {Worker} AND 发布时间 >= {TimeMin} AND 发布时间 <= {TimeMax} AND 工作类型 <> '（请假）' AND 工作类型 <> '（分配标记）' 
        ORDER BY 统一编号
        """
    if (Difficult == "未定义"):
        sql_temp = F"""
                SELECT * FROM 任务分配0试制班 INNER JOIN 任务信息 ON 任务分配0试制班.统一编号 = 任务信息.统一编号 WHERE (项目等级 = '' OR 项目等级 IS NULL) AND 工号 = {Worker} AND 发布时间 >= {TimeMin} AND 发布时间 <= {TimeMax} AND 工作类型 <> '（请假）' AND 工作类型 <> '（分配标记）'
                UNION
                SELECT * FROM 任务分配0试验班 INNER JOIN 任务信息 ON 任务分配0试验班.统一编号 = 任务信息.统一编号 WHERE (项目等级 = '' OR 项目等级 IS NULL) AND 工号 = {Worker} AND 发布时间 >= {TimeMin} AND 发布时间 <= {TimeMax} AND 工作类型 <> '（请假）' AND 工作类型 <> '（分配标记）' 
                UNION
                SELECT * FROM 台架分配 INNER JOIN 任务信息 ON 台架分配.统一编号 = 任务信息.统一编号 WHERE (项目等级 = '' OR 项目等级 IS NULL) AND 工号 = {Worker} AND 发布时间 >= {TimeMin} AND 发布时间 <= {TimeMax} AND 工作类型 <> '（请假）' AND 工作类型 <> '（分配标记）' 
                ORDER BY 统一编号
                """
    cursor_a = connent.execute(sql_temp)
    NowTime = 0
    NowQuestName = ""
    NowQuestNumber = ""
    for Quest in cursor_a:
        ThisQuestNumber = Quest[1]
        ThisQuestName = Quest[10]
        if(ThisQuestNumber == NowQuestNumber):
            NowTime += Quest[5]
        else:
            # 先判断是不是空，以此来判断是不是第一个
            if(NowQuestNumber == ""):  # 那么说明是第一个，不需要填写
                NowQuestNumber = ThisQuestNumber
                NowQuestName = ThisQuestName
                NowTime += Quest[5]
            else:  # 说明此时不是空，除了要改变当前名字以外，还要填写时间
                Sheet_2.cell(RowThisArea, ColWorker).value = NowQuestName
                Sheet_2.cell(RowThisArea, ColWorker + 1).value = NowTime
                TotalTime += NowTime
                RowThisArea += 1
                NowTime = 0

                NowQuestNumber = ThisQuestNumber
                NowQuestName = ThisQuestName
                NowTime += Quest[5]

    # 最后残留的一个要填上
    Sheet_2.cell(RowThisArea, ColWorker).value = NowQuestName
    Sheet_2.cell(RowThisArea, ColWorker + 1).value = NowTime
    TotalTime += NowTime
    RowThisArea += 1
    NowTime = 0

    if(RowThisArea > RowMaxMark):
        RowMaxMark = RowThisArea

    return TotalTime, RowMaxMark

# 加上了系数，Debug用
def WriteInPartTime_Debug(Sheet_2, connent, Difficult, Worker, TimeMin, TimeMax, ColWorker, RowMaxEnd, RowMaxMark):
    TotalTime = 0
    RowThisArea = RowMaxEnd
    if(Difficult == "未定义"):
        Difficult = ""

    sql_temp = F"""
        SELECT * FROM 任务分配0试制班 INNER JOIN 任务信息 ON 任务分配0试制班.统一编号 = 任务信息.统一编号 WHERE 项目等级 = '{Difficult}' AND 工号 = {Worker} AND 发布时间 >= {TimeMin} AND 发布时间 <= {TimeMax} AND 工作类型 <> '（请假）' AND 工作类型 <> '（分配标记）'
        UNION
        SELECT * FROM 任务分配0试验班 INNER JOIN 任务信息 ON 任务分配0试验班.统一编号 = 任务信息.统一编号 WHERE 项目等级 = '{Difficult}' AND 工号 = {Worker} AND 发布时间 >= {TimeMin} AND 发布时间 <= {TimeMax} AND 工作类型 <> '（请假）' AND 工作类型 <> '（分配标记）' 
        UNION
        SELECT * FROM 台架分配 INNER JOIN 任务信息 ON 台架分配.统一编号 = 任务信息.统一编号 WHERE 项目等级 = '{Difficult}' AND 工号 = {Worker} AND 发布时间 >= {TimeMin} AND 发布时间 <= {TimeMax} AND 工作类型 <> '（请假）' AND 工作类型 <> '（分配标记）' 
        ORDER BY 统一编号
        """
    cursor_a = connent.execute(sql_temp)
    NowTime = 0
    NowQuestName = ""
    NowQuestNumber = ""
    for Quest in cursor_a:
        ThisQuestNumber = Quest[1]
        ThisQuestName = Quest[10]
        if(ThisQuestNumber == NowQuestNumber):
            NowTime += Quest[5] * Quest[4]
        else:
            # 先判断是不是空，以此来判断是不是第一个
            if(NowQuestNumber == ""):  # 那么说明是第一个，不需要填写
                NowQuestNumber = ThisQuestNumber
                NowQuestName = ThisQuestName
                NowTime += Quest[5] * Quest[4]
            else:  # 说明此时不是空，除了要改变当前名字以外，还要填写时间
                Sheet_2.cell(RowThisArea, ColWorker).value = NowQuestName
                Sheet_2.cell(RowThisArea, ColWorker + 1).value = NowTime
                TotalTime += NowTime
                RowThisArea += 1
                NowTime = 0

                NowQuestNumber = ThisQuestNumber
                NowQuestName = ThisQuestName
                NowTime += Quest[5] * Quest[4]

    # 最后残留的一个要填上
    Sheet_2.cell(RowThisArea, ColWorker).value = NowQuestName
    Sheet_2.cell(RowThisArea, ColWorker + 1).value = NowTime
    TotalTime += NowTime
    RowThisArea += 1
    NowTime = 0

    if(RowThisArea > RowMaxMark):
        RowMaxMark = RowThisArea

    return TotalTime, RowMaxMark


# 先写吧，先写难度的字母
def WriteInDifficult(Difficult, Sheet_2, RowMaxEnd):
    Sheet_2.cell(RowMaxEnd, 1).value = Difficult

# 把返回的时间填入表1
def WriteInTotalTime(TotalTime, Sheet_1, Postion_Col, Postion_Row):
    Sheet_1.cell(Postion_Row, Postion_Col).value = TotalTime