import sqlite3
import openpyxl
from openpyxl.styles import PatternFill, Border, Side, Alignment, Protection, Font

import MyStringMethod
import MyConstant

#写入“统计情况”中的人员、总工时、总加班、总请假默认字符
def DefaultWord_TotalWorkTime(Sheet_1):
    Sheet_1.cell(1, 1).value = "工号"
    Sheet_1.cell(1, 2).value = "人员"
    Sheet_1.cell(1, 3).value = "不包括台架"
    Sheet_1.cell(1, 4).value = "台架值班"
    Sheet_1.cell(1, 5).value = "总工时"
    Sheet_1.cell(1, 6).value = "总加班"
    Sheet_1.cell(1, 7).value = "总请假"