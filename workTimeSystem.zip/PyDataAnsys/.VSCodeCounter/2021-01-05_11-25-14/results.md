# Summary

Date : 2021-01-05 11:25:14

Directory f:\Script\ProjectForCompany\200822_ForgeWorkHoursManagementSystem\201129_PY_DataAnsys_Beta

Total : 22 files,  31132 codes, 559 comments, 5516 blanks, all 37207 lines

[details](details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| HTML | 4 | 29,911 | 0 | 5,176 | 35,087 |
| Python | 12 | 702 | 269 | 185 | 1,156 |
| XML | 4 | 270 | 0 | 4 | 274 |
| C++ | 1 | 248 | 290 | 150 | 688 |
| JSON | 1 | 1 | 0 | 1 | 2 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 22 | 31,132 | 559 | 5,516 | 37,207 |
| build | 1 | 28,651 | 0 | 5,170 | 33,821 |
| build\main | 1 | 28,651 | 0 | 5,170 | 33,821 |
| data | 3 | 1,260 | 0 | 6 | 1,266 |
| data\result | 3 | 1,260 | 0 | 6 | 1,266 |
| dist | 6 | 519 | 290 | 155 | 964 |
| dist\main | 6 | 519 | 290 | 155 | 964 |
| dist\main\Include | 1 | 248 | 290 | 150 | 688 |
| dist\main\docx | 4 | 270 | 0 | 4 | 274 |
| dist\main\docx\templates | 4 | 270 | 0 | 4 | 274 |
| dist\main\wcwidth | 1 | 1 | 0 | 1 | 2 |

[details](details.md)