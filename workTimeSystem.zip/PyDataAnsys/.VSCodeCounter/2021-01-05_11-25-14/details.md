# Details

Date : 2021-01-05 11:25:14

Directory f:\Script\ProjectForCompany\200822_ForgeWorkHoursManagementSystem\201129_PY_DataAnsys_Beta

Total : 22 files,  31132 codes, 559 comments, 5516 blanks, all 37207 lines

[summary](results.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [Ansys_01_OldExcel.py](/Ansys_01_OldExcel.py) | Python | 37 | 18 | 8 | 63 |
| [Ansys_02_StatisticsWorkTime.py](/Ansys_02_StatisticsWorkTime.py) | Python | 349 | 118 | 92 | 559 |
| [Ansys_03_SummaryWorkTime.py](/Ansys_03_SummaryWorkTime.py) | Python | 23 | 6 | 11 | 40 |
| [ForTest.py](/ForTest.py) | Python | 2 | 1 | 1 | 4 |
| [Method_01.py](/Method_01.py) | Python | 197 | 101 | 36 | 334 |
| [Method_02.py](/Method_02.py) | Python | 13 | 1 | 2 | 16 |
| [Method_03.py](/Method_03.py) | Python | 29 | 4 | 8 | 41 |
| [MyConstant.py](/MyConstant.py) | Python | 6 | 3 | 3 | 12 |
| [MyStringMethod.py](/MyStringMethod.py) | Python | 7 | 3 | 3 | 13 |
| [MyTool.py](/MyTool.py) | Python | 0 | 0 | 1 | 1 |
| [Visual_01_VisualOfWorkTime.py](/Visual_01_VisualOfWorkTime.py) | Python | 9 | 0 | 4 | 13 |
| [build/main/xref-main.html](/build/main/xref-main.html) | HTML | 28,651 | 0 | 5,170 | 33,821 |
| [data/result/折线图.html](/data/result/折线图.html) | HTML | 574 | 0 | 2 | 576 |
| [data/result/柱状图.html](/data/result/柱状图.html) | HTML | 439 | 0 | 2 | 441 |
| [data/result/饼图.html](/data/result/饼图.html) | HTML | 247 | 0 | 2 | 249 |
| [dist/main/Include/pyconfig.h](/dist/main/Include/pyconfig.h) | C++ | 248 | 290 | 150 | 688 |
| [dist/main/docx/templates/default-footer.xml](/dist/main/docx/templates/default-footer.xml) | XML | 27 | 0 | 1 | 28 |
| [dist/main/docx/templates/default-header.xml](/dist/main/docx/templates/default-header.xml) | XML | 27 | 0 | 1 | 28 |
| [dist/main/docx/templates/default-settings.xml](/dist/main/docx/templates/default-settings.xml) | XML | 26 | 0 | 1 | 27 |
| [dist/main/docx/templates/default-styles.xml](/dist/main/docx/templates/default-styles.xml) | XML | 190 | 0 | 1 | 191 |
| [dist/main/wcwidth/version.json](/dist/main/wcwidth/version.json) | JSON | 1 | 0 | 1 | 2 |
| [main.py](/main.py) | Python | 30 | 14 | 16 | 60 |

[summary](results.md)