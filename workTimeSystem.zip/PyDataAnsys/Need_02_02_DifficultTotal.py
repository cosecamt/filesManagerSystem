import Method_2_2
import MyConstant

import sqlite3
import openpyxl

# 根据难度进行统计，共生成2张表：每人每个难度对应的时间 | 详细的项目表
def DifficultShow(Group_In):
    connent = sqlite3.connect(MyConstant.DataBaseAddress)
    TimeMin = MyConstant.TimeMin
    TimeMax = MyConstant.TimeMax

    # 建表
    WorkBook_Result = openpyxl.Workbook()
    Sheet_1 = WorkBook_Result.active
    Sheet_1.title = "小时统计"
    Sheet_2 = WorkBook_Result.create_sheet("按项目统计")

    # 注意添加一列“未定义”的情况！！！！！！！！！！！！！！

    # 说起来应该是两张表交叉着写、并且第二张表先写比较有效率
    # 为第一张表写入固定字段ABCDE，第二张表最后写
    Method_2_2.DefaultWord_Difficult(Sheet_1)
    # 第一张表写入人名,人名要以ListWorker返回
    ListWorker, ListJobNumber = Method_2_2.AddInName(Sheet_1, Group_In, connent)
    # 以ListWorker为依据为第二张表写入人名
    Method_2_2.AddInName_Second(Sheet_2, ListWorker)
    # 把表2中的人名格子合并并居中
    Method_2_2.MergeNameCell(Sheet_2, ListWorker)
    # 循环前构建一个ABCDE的List，用来在后面每个人中循环
    ListDifficult = ["A", "B", "C", "D", "E", "未定义"]
    # 先循环难度，A-E还有“未定义”的遍历
    # 再嵌套每个人的循环
    RowMaxEnd = 2  # 当前难度中的最大行数，用来决定下一个难度的起点（当前 + 1）
    Postion_Col = 2
    Postion_Row = 2
    for Difficult in ListDifficult:
        Postion_Row = 2
        ColWorker = 2
        RowMaxMark = RowMaxEnd
        # 先写吧，先写难度的字母
        Method_2_2.WriteInDifficult(Difficult, Sheet_2, RowMaxEnd)
        for Worker in ListJobNumber:
            # 给表2填入详细的任务列表和时间，并返回该难度下该人的总时间
            TotalTime, RowMaxMark = Method_2_2.WriteInPartTime(Sheet_2, connent, Difficult, Worker, TimeMin, TimeMax, ColWorker, RowMaxEnd, RowMaxMark)
            # 把返回的时间填入表1
            Method_2_2.WriteInTotalTime(TotalTime, Sheet_1, Postion_Col, Postion_Row)
            # 每次循环列数加2
            ColWorker += 2
            Postion_Row += 1
        RowMaxEnd = RowMaxMark
        Postion_Col += 1


    ##################   保存excel部分  ###################

    connent.close() #别忘了关连接
    WorkBook_Result.save(F'data/result/生成难度制统计-{Group_In}.xlsx')    #别忘了保存


