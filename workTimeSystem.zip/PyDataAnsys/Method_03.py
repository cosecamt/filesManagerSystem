import sqlite3
import openpyxl
from openpyxl.styles import PatternFill, Border, Side, Alignment, Protection, Font

import MyStringMethod
import MyConstant

#填入人员,并返回两个Dict，分别是工时和加班所在的位置，Key为工号
#再维护两个Dict，用来记录每个人的踪迹工时和加班时长，Key为工号
def WriteInWorkerNameAndDict(Sheet_1,connent,Group):
    sql = F"SELECT * FROM 员工信息 WHERE 所属班组 = '{Group}'"
    cursor_ThisGroupWorker = connent.execute(sql)

    Dict_PositionTotalTime = {}
    Dict_PositionOverTime = {}
    Dict_NumberTotalTime = {}
    Dict_NumberOverTime = {}
    List_Worker = []

    #要循环记录两次，一次是合计工时，一次是加班
    Position_OfMaxColumn = 1
    for Row_WorkerInGroup in cursor_ThisGroupWorker:
        Position_OfMaxColumn += 1 
        Sheet_1.cell(2,Position_OfMaxColumn).value = Row_WorkerInGroup[1]
        Dict_PositionTotalTime[str(Row_WorkerInGroup[0])] = Position_OfMaxColumn
        Dict_NumberTotalTime[str(Row_WorkerInGroup[0])] = 0
        List_Worker.append(str(Row_WorkerInGroup[0]))

    Col_TotalEnd = Position_OfMaxColumn
    Position_OfMaxColumn += 2 
    
    #完全不明白一个游标为什么不能重复使用，重复使用就不能进入循环，非常奇怪
    sql = F"SELECT * FROM 员工信息 WHERE 所属班组 = '{Group}'"
    cursor_ThisGroupWorker = connent.execute(sql)
    for Row_WorkerInGroup in cursor_ThisGroupWorker:
        Position_OfMaxColumn += 1 
        Sheet_1.cell(2,Position_OfMaxColumn).value = Row_WorkerInGroup[1]
        Dict_PositionOverTime[str(Row_WorkerInGroup[0])] = Position_OfMaxColumn
        Dict_NumberOverTime[str(Row_WorkerInGroup[0])] = 0
    
    Col_OverEnd = Position_OfMaxColumn

    return Dict_PositionTotalTime,Dict_PositionOverTime,Dict_NumberTotalTime,Dict_NumberOverTime,Col_TotalEnd,Col_OverEnd,List_Worker

def HolidayMark(Sheet_1,Row_Max,Col_Now):
    Sheet_1.cell(Row_Max,Col_Now).fill = PatternFill(fill_type = 'solid',fgColor="66B3FF")

