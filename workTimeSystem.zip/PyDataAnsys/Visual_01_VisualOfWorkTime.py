import sqlite3
import openpyxl

import MyStringMethod
import MyConstant
import Method_01

def DrawPicture_TwoGroupMix():
    pass


def DrawPicture(GroupInThisMethod,TimeMin,TimeMax):
    pass