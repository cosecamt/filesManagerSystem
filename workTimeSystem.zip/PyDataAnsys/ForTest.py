#本文件只用于测试函数功能，别无他用
import MyStringMethod
import sqlite3
import MyConstant
import random

# ################# 测试字符转字母的方法 #################
#print(MyStringMethod.TransfromNumberToChar(28))

# ################# 给数据库中的项目随机分配难度（A-E）#################
# 一次性的方法，为了验证统计方法的可用性
connent = sqlite3.connect("work_info.db3")

#读取所有项目的“统一编号”，读一个改一个，随机分配难度并UPDATE数据库

# 全拿出来
sql = "SELECT* FROM 任务信息"
cursor_1 = connent.execute(sql)

# 开始遍历
for Row_QuestInfo in cursor_1:
    QuestNumber_This = Row_QuestInfo[2]
    RandomNum = random.randint(1, 6)
    RandomClass = ''

    # 枚举一下数字对应的难度等级
    if(RandomNum == 1):
        RandomClass = "A"
    elif(RandomNum == 2):
        RandomClass = "B"
    elif(RandomNum == 3):
        RandomClass = "C"
    elif(RandomNum == 4):
        RandomClass = "D"
    elif(RandomNum == 5):
        RandomClass = "E"
    elif (RandomNum == 6):
        RandomClass = ""

    sql = F"UPDATE 任务信息 SET 项目等级 = '{RandomClass}' WHERE 统一编号 = '{QuestNumber_This}'"
    connent.execute(sql)

connent.commit()


