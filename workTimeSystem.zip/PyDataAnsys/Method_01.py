import sqlite3
import openpyxl
from openpyxl.styles import PatternFill, Border, Side, Alignment, Protection, Font

import MyStringMethod
import MyConstant

#填入预置的文字，在填入员工名之前（因为有些位置不好确定）
def WriteInDefaultWords_BeforeWorker(Sheet_NowDays, Group_InThisMethod, TodayTime):
    #“试制班”和“试验班”的标签
    SettingStyleByParameter(Sheet_NowDays,F"{Group_InThisMethod}",(2,1),(2,9))
    #第三行的一列内容
    SettingStyleByParameter(Sheet_NowDays,"序号",(3,1),(3,1))
    SettingStyleByParameter(Sheet_NowDays,"统一编号",(3,2),(3,2))
    SettingStyleByParameter(Sheet_NowDays,"生产订单号",(3,3),(3,3))
    SettingStyleByParameter(Sheet_NowDays,"内部订单号",(3,4),(3,4))
    SettingStyleByParameter(Sheet_NowDays,"编制部门（人）",(3,5),(3,5))
    SettingStyleByParameter(Sheet_NowDays,"任务内容",(3,6),(3,6))
    SettingStyleByParameter(Sheet_NowDays,"任务要求",(3,7),(3,7))
    SettingStyleByParameter(Sheet_NowDays,"任务分配",(3,8),(3,8))
    SettingStyleByParameter(Sheet_NowDays,"完成情况",(3,9),(3,9))
    
#写入员工名字
def WriteInWorkerName(Sheet_NowDays,connent,Group_InThisMethod,Row_OfDays):
    sql = F"SELECT * FROM 员工信息 WHERE 所属班组 = '{Group_InThisMethod}'"
    cursor_ThisGroupWorker = connent.execute(sql)
    Dict_PositionAndWorker = {}


    Position_OfMaxColumn = 9
    for Row_WorkerInGroup in cursor_ThisGroupWorker:
        Position_OfMaxColumn += 1 
        WriteIn_SingleName(Sheet_NowDays,Row_WorkerInGroup,Position_OfMaxColumn)
        Dict_PositionAndWorker[str(Row_WorkerInGroup[0])] = Position_OfMaxColumn
    return Position_OfMaxColumn,Dict_PositionAndWorker   

#填入任务，返回台架行数和最大行数
def WriteInQuestInfo(Sheet_NowDays,connent,Row_OfDays,Group_InThisMethod,Dict_PositionAndWorker): 
    #要注意这里实际上是由两部分组成的，台架和一般任务
    sql = F"SELECT * FROM 台架发布 INNER JOIN 任务信息 ON 台架发布.统一编号 = 任务信息.统一编号 WHERE 发布时间 = {Row_OfDays} AND 数据类型 = '项目'"
    cursor_TodayBenchQuest = connent.execute(sql)
    Position_OfMaxRow = 3
    for Row_QuestInfo in cursor_TodayBenchQuest:
        Position_OfMaxRow += 1
        WriteIn_QuestInfo_Bench(Sheet_NowDays,Row_QuestInfo,Position_OfMaxRow)
        #填写工时，台架部分
        Number_Quest = Row_QuestInfo[8]
        Dict_PositionAndWorker = WriteInTimeForEachQuest_Bench(Sheet_NowDays,connent,Row_OfDays,Dict_PositionAndWorker,Number_Quest,Position_OfMaxRow)

    #记录一下台架的任务位置
    BenchRow = Position_OfMaxRow

    sql = F"SELECT * FROM 任务发布0{Group_InThisMethod} INNER JOIN 任务信息 ON 任务发布0{Group_InThisMethod}.统一编号 = 任务信息.统一编号 WHERE 发布时间 = {Row_OfDays}"
    cursor_ThisGroupQuest = connent.execute(sql)

    for Row_QuestInfo in cursor_ThisGroupQuest:
        Position_OfMaxRow += 1 
        WriteIn_QuestInfo(Sheet_NowDays,Row_QuestInfo,Position_OfMaxRow)
        #填写工时，任务部分
        Number_Quest = Row_QuestInfo[7]
        Dict_PositionAndWorker = WriteInTimeForEachQuest(Sheet_NowDays,connent,Row_OfDays,Dict_PositionAndWorker,Number_Quest,Position_OfMaxRow,Group_InThisMethod)

    return BenchRow,Position_OfMaxRow + 3,Dict_PositionAndWorker

#填入预置的文字，在确定位置以后
def WriteInDefaultWords_AfterWorker(Sheet_NowDays, TodayTime,MaxColumnInExcel,BenchRowInExcel,MaxRowInExcel):
    #最左边的序号
    if(BenchRowInExcel != 3):
        SettingStyleByParameter(Sheet_NowDays,"1",(4,1),(BenchRowInExcel,1))
    if(BenchRowInExcel != MaxRowInExcel - 3):
        for i in range(BenchRowInExcel + 1, MaxRowInExcel + 1 - 3):
            SettingStyleByParameter(Sheet_NowDays,F"{i - BenchRowInExcel}",(i,1),(i,1))
    #工时合计，加班，请假，班组成员，日期
    SettingStyleByParameter(Sheet_NowDays,"工时合计",(MaxRowInExcel - 2,1),(MaxRowInExcel - 2,9))
    SettingStyleByParameter(Sheet_NowDays,"加班",(MaxRowInExcel - 1,1),(MaxRowInExcel - 1,9))
    SettingStyleByParameter(Sheet_NowDays,"请假",(MaxRowInExcel,1),(MaxRowInExcel,9))
    SettingStyleByParameter(Sheet_NowDays,"班组成员",(2,10),(2,MaxColumnInExcel))
    Year,Month,Day = MyStringMethod.TheStringOfTime_ToYearMonthDay(str(TodayTime))
    Date = Year +"-"+ Month +"-"+ Day
    SettingStyleByParameter(Sheet_NowDays,F"日期 {Date}",(1,1),(1,MaxColumnInExcel))

    #把工时填进去


#将格式通过部分参数来进行设置
def SettingStyleByParameter(Sheet_NowDays,Content,StartCell,EndCell):
    #填写内容
    Sheet_NowDays.cell(StartCell[0],StartCell[1]).value = Content
    #合并
    Sheet_NowDays.merge_cells(F'{MyStringMethod.TransfromNumberToChar(StartCell[1])}{StartCell[0]}:{MyStringMethod.TransfromNumberToChar(EndCell[1])}{EndCell[0]}')
    #字体
    Sheet_NowDays.cell(StartCell[0],StartCell[1]).font = Font(name = '宋体', size='12', bold = True)
    #居中
    Sheet_NowDays.cell(StartCell[0],StartCell[1]).alignment = Alignment(horizontal = 'center', vertical = 'center',wrapText = True)
    for i in range(StartCell[1],EndCell[1] + 1):
        Sheet_NowDays.cell(StartCell[0],i).border = Border(left=Side(border_style='thin',color='000000'),
                                                    right=Side(border_style='thin',color='000000'),
                                                    top=Side(border_style='thin',color='000000'),
                                                    bottom=Side(border_style='thin',color='000000'))

#将格式通过部分参数来进行设置_不加粗版
def SettingStyleByParameter_NoBold(Sheet_NowDays,Content,WriteCell):
    #填写内容
    Sheet_NowDays.cell(WriteCell[0],WriteCell[1]).value = Content
    #字体
    Sheet_NowDays.cell(WriteCell[0],WriteCell[1]).font = Font(name = '宋体', size='10')
    #居中
    Sheet_NowDays.cell(WriteCell[0],WriteCell[1]).alignment = Alignment(horizontal = 'center', vertical = 'center',wrapText = True)
    #边框
    Sheet_NowDays.cell(WriteCell[0],WriteCell[1]).border = Border(left=Side(border_style='thin',color='000000'),
                                                    right=Side(border_style='thin',color='000000'),
                                                    top=Side(border_style='thin',color='000000'),
                                                    bottom=Side(border_style='thin',color='000000'))

def WriteIn_SingleName(Sheet_NowDays,Row_WorkerInGroup,Position_OfMaxColumn):
    #要注意查一下，如果值班，底色要变黄
    Sheet_NowDays.cell(3,Position_OfMaxColumn).value = Row_WorkerInGroup[1]

#让值班的人变黄，废弃
""" def BenchMan_ToYellow(Sheet_NowDays,Row_WorkerInGroup,Position_OfMaxColumn):
    #if(str(Row_WorkerInGroup[0]) == str(BenchWorkerToday[4])):            
        Sheet_NowDays.cell(3,Position_OfMaxColumn).fill = PatternFill(fill_type = 'solid',fgColor="FFFF00")  """

#写入任务——台架任务
def WriteIn_QuestInfo_Bench(Sheet_NowDays,Row_QuestInfo,Position_OfMaxRow):
    #统一编号
    SettingStyleByParameter_NoBold(Sheet_NowDays,Row_QuestInfo[8],(Position_OfMaxRow,2))
    #生产订单号
    SettingStyleByParameter_NoBold(Sheet_NowDays,Row_QuestInfo[7],(Position_OfMaxRow,3))
    #内部订单号
    SettingStyleByParameter_NoBold(Sheet_NowDays,Row_QuestInfo[6],(Position_OfMaxRow,4))
    #编制部门
    SettingStyleByParameter_NoBold(Sheet_NowDays,Row_QuestInfo[9],(Position_OfMaxRow,5))
    #任务内容
    SettingStyleByParameter_NoBold(Sheet_NowDays,Row_QuestInfo[10],(Position_OfMaxRow,6))

#写入任务——普通任务
def WriteIn_QuestInfo(Sheet_NowDays,Row_QuestInfo,Position_OfMaxRow):
    #统一编号
    SettingStyleByParameter_NoBold(Sheet_NowDays,Row_QuestInfo[7],(Position_OfMaxRow,2))
    #生产订单号
    SettingStyleByParameter_NoBold(Sheet_NowDays,Row_QuestInfo[6],(Position_OfMaxRow,3))
    #内部订单号
    SettingStyleByParameter_NoBold(Sheet_NowDays,Row_QuestInfo[5],(Position_OfMaxRow,4))
    #编制部门
    SettingStyleByParameter_NoBold(Sheet_NowDays,Row_QuestInfo[8],(Position_OfMaxRow,5))
    #任务内容
    SettingStyleByParameter_NoBold(Sheet_NowDays,Row_QuestInfo[9],(Position_OfMaxRow,6))

#填写工时,台架部分
def WriteInTimeForEachQuest_Bench(Sheet_NowDays,connent,Row_OfDays,Dict_PositionAndWorker,Number_Quest,Position_OfMaxRow):
    #这里要注意一下，如果遇到一种情况：此项目的参与人员不在字典当中，那么应该，将此人添加进表格，列数+1，再把工时填进去，此人也要加入字典以供后续的工时总计。
    #但是台架则不需要考虑这个，毕竟一个人不可能在两边都没有,所以这个部分全都pass
    #由于字典会变化，要注意把字典return回去
    sql = F"SELECT * FROM 台架分配 WHERE 统一编号 = '{Number_Quest}' AND 发布时间={Row_OfDays} ORDER BY 工号"
    cursor_BenchWorkTime = connent.execute(sql)
    #工号在里面是int，但是在判断的时候，或者写入的时候，还是要强转成str好一点
    TemporaryValue_NowWorkerNumber = ""
    TemporaryValue_BeforeWorkerNumber = ""
    String_WriteIn = ""

    #遍历该统一编号的所有工时记录，每条以Now_WorkTime呈现
    for Now_WorkTime in cursor_BenchWorkTime:
        #判断该条记录中的工号是否与上一条工号（TemporaryValue_NowWorkerNumber）相同……
        if(TemporaryValue_NowWorkerNumber == str(Now_WorkTime[2])):
            #判断该条记录的工号是否在Dict中，由于是台架，不需要考虑两边都不存在的情况
            if(str(Now_WorkTime[2]) in Dict_PositionAndWorker):
                #做一个str单独记录该条X*X
                TemporaryString = str(Now_WorkTime[5]) + "*" + str(Now_WorkTime[4]) + "+"  
                #将该条str与原有的字符串拼接               
                String_WriteIn = String_WriteIn + TemporaryString
            else:
                pass
        #如果该条记录中的工号与上一条工号不同……
        else:            
            #更换“上一条工号”为当前工号
            TemporaryValue_NowWorkerNumber = str(Now_WorkTime[2])
            #由于上个人员的相关信息已经结束，并且在Dict中，所以直接填写
            if(TemporaryValue_BeforeWorkerNumber == ""):
                #此时必为第一次
                TemporaryValue_BeforeWorkerNumber = TemporaryValue_NowWorkerNumber
                TemporaryString = str(Now_WorkTime[5]) + "*" + str(Now_WorkTime[4]) + "+"               
                String_WriteIn = String_WriteIn + TemporaryString
            elif((TemporaryValue_BeforeWorkerNumber in Dict_PositionAndWorker) == False):
                #此时为不在Dict中的情况，但是这里是台架，所以不用考虑
                TemporaryValue_BeforeWorkerNumber = TemporaryValue_NowWorkerNumber
            else:
                WriteIn_CellOfWorkTime(Sheet_NowDays,String_WriteIn,Position_OfMaxRow,Dict_PositionAndWorker[TemporaryValue_BeforeWorkerNumber])
                TemporaryValue_BeforeWorkerNumber = TemporaryValue_NowWorkerNumber
                #填写完后将内容清空供下个人员
                String_WriteIn = ""
                #拼接字符串
                TemporaryString = str(Now_WorkTime[5]) + "*" + str(Now_WorkTime[4]) + "+"               
                String_WriteIn = String_WriteIn + TemporaryString
                #两种情况下写入，一种是在工号突然变化的时候，一种是在该统一编号的内容遍历结束的时候  
    if(TemporaryValue_NowWorkerNumber in Dict_PositionAndWorker):
        WriteIn_CellOfWorkTime(Sheet_NowDays,String_WriteIn,Position_OfMaxRow,Dict_PositionAndWorker[TemporaryValue_NowWorkerNumber])
    return Dict_PositionAndWorker

#填写工时,非台架部分
def WriteInTimeForEachQuest(Sheet_NowDays,connent,Row_OfDays,Dict_PositionAndWorker,Number_Quest,Position_OfMaxRow,Group_InThisMethod):
    #这里要注意一下，如果遇到一种情况：此项目的参与人员不在字典当中，那么应该，将此人添加进表格，列数+1，再把工时填进去，此人也要加入字典以供后续的工时总计。
    #这里不是台架了，必须考虑这个问题
    #由于字典会变化，要注意把字典return回去
    sql = F"SELECT * FROM 任务分配0{Group_InThisMethod} WHERE 统一编号 = '{Number_Quest}' AND 发布时间={Row_OfDays} AND 工作类型 = '废弃属性' ORDER BY 工号"
    cursor_BenchWorkTime = connent.execute(sql)
    #工号在里面是int，但是在判断的时候，或者写入的时候，还是要强转成str好一点
    TemporaryValue_NowWorkerNumber = ""
    TemporaryValue_BeforeWorkerNumber = ""
    String_WriteIn = ""

    #遍历该统一编号的所有工时记录，每条以Now_WorkTime呈现
    for Now_WorkTime in cursor_BenchWorkTime:
        #判断该条记录中的工号是否与上一条工号（TemporaryValue_NowWorkerNumber）相同……
        if(TemporaryValue_NowWorkerNumber == str(Now_WorkTime[2])):
            #判断该条记录的工号是否在Dict中，由于是台架，不需要考虑两边都不存在的情况
            if(str(Now_WorkTime[2]) in Dict_PositionAndWorker):
                #做一个str单独记录该条X*X
                TemporaryString = str(Now_WorkTime[5]) + "*" + str(Now_WorkTime[4]) + "+"  
                #将该条str与原有的字符串拼接               
                String_WriteIn = String_WriteIn + TemporaryString
            else:
                pass
        #如果该条记录中的工号与上一条工号不同……
        else:            
            #更换“上一条工号”为当前工号
            TemporaryValue_NowWorkerNumber = str(Now_WorkTime[2])
            #由于上个人员的相关信息已经结束，并且在Dict中，所以直接填写
            if(TemporaryValue_BeforeWorkerNumber == ""):
                #此时必为第一次
                TemporaryValue_BeforeWorkerNumber = TemporaryValue_NowWorkerNumber
                TemporaryString = str(Now_WorkTime[5]) + "*" + str(Now_WorkTime[4]) + "+"               
                String_WriteIn = String_WriteIn + TemporaryString
            elif((TemporaryValue_BeforeWorkerNumber in Dict_PositionAndWorker) == False):
                #此时为不在Dict中的情况，但是这里是台架，所以不用考虑
                TemporaryValue_BeforeWorkerNumber = TemporaryValue_NowWorkerNumber
            else:
                WriteIn_CellOfWorkTime(Sheet_NowDays,String_WriteIn,Position_OfMaxRow,Dict_PositionAndWorker[TemporaryValue_BeforeWorkerNumber])
                TemporaryValue_BeforeWorkerNumber = TemporaryValue_NowWorkerNumber
                #填写完后将内容清空供下个人员
                String_WriteIn = ""
                #拼接字符串
                TemporaryString = str(Now_WorkTime[5]) + "*" + str(Now_WorkTime[4]) + "+"               
                String_WriteIn = String_WriteIn + TemporaryString
                #两种情况下写入，一种是在工号突然变化的时候，一种是在该统一编号的内容遍历结束的时候  
    if(TemporaryValue_NowWorkerNumber in Dict_PositionAndWorker):
        WriteIn_CellOfWorkTime(Sheet_NowDays,String_WriteIn,Position_OfMaxRow,Dict_PositionAndWorker[TemporaryValue_NowWorkerNumber])
    return Dict_PositionAndWorker

#将工时公式填入单独用一个方法（万一要修改也方便点）
def WriteIn_CellOfWorkTime(Sheet_NowDays,Content,Position_Row,Position_Column):
    #不知为何，加了=就会让数值无法显示（明明数值是存在的），原因未知
    #让他格式居中就可以显示了，谜
    #又不行了，谜，算了，这个问题最后解决吧，这个东西只是用来转移数据的，并不是用来修改的，要修改在软件里面改
    #Content = "=" + Content
    Content = Content[0:-1]
    Sheet_NowDays.cell(Position_Row,Position_Column).value = Content
    #居中
    Sheet_NowDays.cell(Position_Row,Position_Column).alignment = Alignment(horizontal = 'center', vertical = 'center',wrapText = True)

#填入合计工时、加班时间和请假时间
def WriteInSumOverLeave(Sheet_NowDays,Row_OfDays,MaxRowInExcel,Dict_PositionAndWorker,Group_InThisMethod,connent):
    #遍历Dict应该是比较合理的方法
    #实际上不需要考虑通谁来两个班组的问题，因为一个人必然只在一边

    for NowWorker in Dict_PositionAndWorker:
        #每轮清空
        Sum_WorkTime = 0
        Sum_OverTime = 0
        Sum_LeaveTime = 0

        sql = F"SELECT * FROM 任务分配0{Group_InThisMethod} WHERE 工号 = {NowWorker} AND 发布时间={Row_OfDays} AND 工作类型 = '废弃属性'"
        cursor_WorkInformation_Quest = connent.execute(sql)
        sql = F"SELECT * FROM 台架分配 WHERE 工号 = {NowWorker} AND 发布时间={Row_OfDays}"
        cursor_WorkInformation_Bench = connent.execute(sql)
        
        #先看普通任务部分
        for EachQuestInformation in cursor_WorkInformation_Quest:
            Sum_WorkTime = Sum_WorkTime + (EachQuestInformation[5] * EachQuestInformation[4])
            Sum_OverTime = Sum_OverTime + EachQuestInformation[5]
        #再看台架部分
        for EachBenchInformation in cursor_WorkInformation_Bench:
            Sum_WorkTime = Sum_WorkTime + (EachBenchInformation[5] * EachBenchInformation[4])
            Sum_OverTime = Sum_OverTime + EachBenchInformation[5]

        #还得考虑当天是否为假期
        sql = F"SELECT * FROM 每日流程0{Group_InThisMethod} WHERE 发布时间={Row_OfDays}"
        cursor_ForCheckHoliday = connent.execute(sql)
        Bool_Holiday = "否"
        for ThisCheck in cursor_ForCheckHoliday:
            Bool_Holiday = ThisCheck[3]
        #根据是否是假期来调整
        if(Bool_Holiday == "否"):
            Sum_OverTime = Sum_OverTime - 8 
            if(Sum_OverTime <= 0):
                Sum_OverTime = 0

        #最后查休假
        sql = F"SELECT * FROM 任务分配0{Group_InThisMethod} WHERE 发布时间={Row_OfDays} AND 工作类型 = '（请假）' AND 工号 = {NowWorker}"
        cursor_AskLeaveHours = connent.execute(sql)     
        for This_Leave in cursor_AskLeaveHours:
            Sum_LeaveTime = Sum_LeaveTime + This_Leave[5]
        
        #填入结果
        WriteIn_CellOfThereValue(Sheet_NowDays,str("%.1f" %(Sum_WorkTime)),MaxRowInExcel - 2,Dict_PositionAndWorker[NowWorker])
        WriteIn_CellOfThereValue(Sheet_NowDays,str("%.1f" %(Sum_OverTime)),MaxRowInExcel - 1,Dict_PositionAndWorker[NowWorker])
        WriteIn_CellOfThereValue(Sheet_NowDays,str("%.1f" %(Sum_LeaveTime)),MaxRowInExcel,Dict_PositionAndWorker[NowWorker])

#将总计、加班和请假的填入单独用一个方法（万一要修改也方便点）
def WriteIn_CellOfThereValue(Sheet_NowDays,Content,Position_Row,Position_Column):
    if(Content == "0.0"):
        return
    #不知为何，加了=就会让数值无法显示（明明数值是存在的），原因未知
    #让他格式居中就可以显示了，谜
    #又不行了，谜，算了，这个问题最后解决吧，这个东西只是用来转移数据的，并不是用来修改的，要修改在软件里面改
    #Content = "=" + Content
    Sheet_NowDays.cell(Position_Row,Position_Column).value = Content
    #居中
    Sheet_NowDays.cell(Position_Row,Position_Column).alignment = Alignment(horizontal = 'center', vertical = 'center',wrapText = True)

def Format_Adjustment(Sheet_NowDays,MaxRowInExcel,MaxColumnInExcel):
    #先总体上边框和居中
    for Row in range(1,MaxRowInExcel + 1,1):
        for Colum in range(1,MaxColumnInExcel + 1,1):
                #居中
                Sheet_NowDays.cell(Row,Colum).alignment = Alignment(horizontal = 'center', vertical = 'center',wrapText = True)
                #边框
                Sheet_NowDays.cell(Row,Colum).border = Border(left=Side(border_style='thin',color='000000'),
                                                                right=Side(border_style='thin',color='000000'),
                                                                top=Side(border_style='thin',color='000000'),
                                                                bottom=Side(border_style='thin',color='000000'))


