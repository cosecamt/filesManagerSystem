import sqlite3

TimeMin = ""
TimeMax = ""

DataBaseAddress = ""
Group_IfNeed = ""

#关于班组参数有
#关于功能参数有
#1.旧版Excel
TheKindOfOutput = "" 