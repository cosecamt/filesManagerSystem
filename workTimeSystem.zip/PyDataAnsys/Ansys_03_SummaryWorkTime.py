import sqlite3
import openpyxl
import docx
import sys

from openpyxl.styles import PatternFill, Border, Side, Alignment, Protection, Font
import MyStringMethod
import MyConstant
import Method_03
import MyTool

from docx import Document
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT
from decimal import Decimal


def SummaryData(GroupInThisMethod,TimeMin,TimeMax):
    connent = sqlite3.connect(MyConstant.DataBaseAddress)
    
    #建立新表
    WorkBook_Result = openpyxl.Workbook()
    Sheet_1 = WorkBook_Result.active
    Sheet_1.title = GroupInThisMethod

    #填入人员,并返回两个Dict，分别是工时和加班所在的位置，Key为工号
    #再维护两个Dict，用来记录每个人的踪迹工时和加班时长，Key为工号
    #再返回两个列数吧
    #我竟然又增加了一个List来存人员工号（？？？算了，就这样吧，懒得优化了
    Dict_PositionTotalTime,Dict_PositionOverTime, Dict_NumberTotalTime,Dict_NumberOverTime, Col_TotalEnd,Col_OverEnd, List_Worker = Method_03.WriteInWorkerNameAndDict(Sheet_1,connent,GroupInThisMethod)

    #按Day来循环，要先查当月有哪些Day
    sql = F"SELECT * FROM 每日流程0{GroupInThisMethod} WHERE 发布时间 >= {TimeMin} AND 发布时间 <= {TimeMax} "
    cursor_DaysOfThisMonth = connent.execute(sql)

    Row_Max = 2
    for Row_OfDays in cursor_DaysOfThisMonth:
        #先把每天日期输进去
        Row_Max += 1
        Time_Today = Row_OfDays[0]
        Sheet_1.cell(Row_Max,1).value = MyTool.EightNumberToTextDate(Time_Today)
        Sheet_1.cell(Row_Max,Col_TotalEnd + 2).value = MyTool.EightNumberToTextDate(Time_Today)
        #看看是否是假期，如果是就染蓝色
        if(Row_OfDays[3] == "是"):
            for i in range(1, Col_OverEnd + 1):
                Method_03.HolidayMark(Sheet_1,Row_Max,i)

        #懒得优化，就按列表挨个查吧
        for Now_Worker in List_Worker:
            Value_WorkTime = 0
            Value_OverTime = 0

            sql_temp =F"""
            SELECT* FROM 任务分配0试制班 WHERE 工号 = {Now_Worker} AND 发布时间 = {Row_OfDays[0]} AND 工作类型 = '废弃属性'
            UNION ALL
            SELECT* FROM 任务分配0试验班 WHERE 工号 = {Now_Worker} AND 发布时间 = {Row_OfDays[0]} AND 工作类型 = '废弃属性'
            UNION ALL
            SELECT* FROM 台架分配 WHERE 工号 = {Now_Worker} AND 发布时间 = {Row_OfDays[0]} AND 工作类型 = '废弃属性'
            """ 

            cursor_2 = connent.execute(sql_temp)
            for Row_NoteToday in cursor_2:
                Value_WorkTime += (Row_NoteToday[4] * Row_NoteToday[5])
                Value_OverTime += Row_NoteToday[5]
            
            #在录入之前要按当天是否假日处理
            if(Row_OfDays[3] == "否"):
                Value_OverTime -= 8
            if(Value_OverTime < 0):
                Value_OverTime = 0

            #在录入之前把数值录入Dict里
            Dict_NumberTotalTime[Now_Worker] += Value_WorkTime
            Dict_NumberOverTime[Now_Worker] += Value_OverTime

            #把公式和加班小时填进去
            if(Value_WorkTime != 0):
                Sheet_1.cell(Row_Max,Dict_PositionTotalTime[Now_Worker]).value = Value_WorkTime
            if(Value_OverTime != 0):
                Sheet_1.cell(Row_Max,Dict_PositionOverTime[Now_Worker]).value = Value_OverTime

    #把总和填进去
    Sheet_1.cell(Row_Max + 1,1).value = "合计:"
    for Total_Worker in List_Worker:
        Sheet_1.cell(Row_Max + 1,Dict_PositionTotalTime[Total_Worker]).value = Dict_NumberTotalTime[Total_Worker]
        Sheet_1.cell(Row_Max + 1,Dict_PositionOverTime[Total_Worker]).value = Dict_NumberOverTime[Total_Worker]

    #开始调整格式
    #"工时"和“加班”的标题栏
    Sheet_1.cell(1,1).value = "工时"
    Sheet_1.merge_cells(F'{MyStringMethod.TransfromNumberToChar(1)}{1}:{MyStringMethod.TransfromNumberToChar(Col_TotalEnd)}{1}')
    Sheet_1.cell(1,1).alignment = Alignment(horizontal = 'center', vertical = 'center',wrapText = True)
    Sheet_1.cell(1,Col_TotalEnd + 2).value = "加班"
    Sheet_1.merge_cells(F'{MyStringMethod.TransfromNumberToChar(Col_TotalEnd + 2 )}{1}:{MyStringMethod.TransfromNumberToChar(Col_OverEnd)}{1}')
    Sheet_1.cell(1,Col_TotalEnd + 2).alignment = Alignment(horizontal = 'center', vertical = 'center',wrapText = True)

    #全部加上格子，中间空开
    for i in range(1, Row_Max + 1):
        for j in range(1, Col_TotalEnd + 1):
            Sheet_1.cell(i,j).border = Border(left=Side(border_style='thin',color='000000'),
                                                        right=Side(border_style='thin',color='000000'),
                                                        top=Side(border_style='thin',color='000000'),
                                                        bottom=Side(border_style='thin',color='000000'))

    for i in range(1, Row_Max + 1):
        for j in range(Col_TotalEnd + 2, Col_OverEnd + 1):
            Sheet_1.cell(i,j).border = Border(left=Side(border_style='thin',color='000000'),
                                                        right=Side(border_style='thin',color='000000'),
                                                        top=Side(border_style='thin',color='000000'),
                                                        bottom=Side(border_style='thin',color='000000'))                                                       

    #列宽
    Sheet_1.column_dimensions['A'].width = 10
    for i in range(2,Col_TotalEnd + 1):
        Sheet_1.column_dimensions[MyStringMethod.TransfromNumberToChar(i)].width = 5
    Sheet_1.column_dimensions[MyStringMethod.TransfromNumberToChar(Col_TotalEnd+1)].width = 10
    Sheet_1.column_dimensions[MyStringMethod.TransfromNumberToChar(Col_TotalEnd+2)].width = 10
    for i in range(Col_TotalEnd+3,Col_OverEnd + 1):
        Sheet_1.column_dimensions[MyStringMethod.TransfromNumberToChar(i)].width = 5

    #人名那列自动换行
    for i in range(1, Col_OverEnd+1):
        Sheet_1.cell(2,i).alignment = Alignment(horizontal = 'center', vertical = 'center',wrapText = True)

    ##################   保存excel部分  ###################

    connent.close() #别忘了关连接
    WorkBook_Result.save(F'data/result/工时、加班汇总-{GroupInThisMethod}.xlsx')    #别忘了保存