
#输入String形式的8位数，返回元组（年，月，日）
def TheStringOfTime_ToYearMonthDay(Time):
    Year = Time[0:4]
    Month = Time[4:6]
    Day = Time[6:8]
    return(Year,Month,Day)

#用于openpyxl里合并单元格，实现数字和字母的转换，用1-26替换A-Z
#传进来的数字应该介于1-26这个范围
def TransfromNumberToChar(Number):
    if(Number >= 27):
        N_Other = Number - 26
        C_Other = chr(N_Other + 64)
        return F"A{C_Other}"

    return chr(Number + 64)
