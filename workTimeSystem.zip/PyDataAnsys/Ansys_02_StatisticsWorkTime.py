import sqlite3
import openpyxl
import docx
import sys

import MyStringMethod
import MyConstant
import Method_02

from docx import Document
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT
from decimal import Decimal

from pyecharts.faker import Faker
from pyecharts import options as opts
from pyecharts.charts import Bar
from pyecharts.charts import Line
from pyecharts.charts import Pie

def OutPutWorkData_TwoGroupMix(TimeMin,TimeMax):
    connent = sqlite3.connect(MyConstant.DataBaseAddress)
    
    #建立新表
    WorkBook_Result = openpyxl.Workbook()
    Sheet_1 = WorkBook_Result.active
    Sheet_1.title = "统计情况"
    Sheet_2 = WorkBook_Result.create_sheet("按人员统计") 
    Sheet_3 = WorkBook_Result.create_sheet("按项目统计")

    ##################   1-统计情况  ###################
    #先把默认字符填进去：人员、总工时、总加班、总请假
    Method_02.DefaultWord_TotalWorkTime(Sheet_1)

    #把所有该班组的人找出来
    sql = F"SELECT* FROM 员工信息 WHERE 是否隐藏 = '否' "
    cursor_1 = connent.execute(sql)
    NowRows = 2  #记一下行数给后面写入用

    #弄一些List给后面数据分析用
    List_1_WorkNumber = []  #工号列表
    List_2_WorkerName = []  #姓名列表
    List_3_TimeWithOutBench = []    #不包含台架的工时
    List_4_TimeOfBench = []     #台架的工时
    List_5_AllHours = []     #包含台架的工时
    List_6_LaterWork = []     #加班时间
    List_7_TakeLeave = []     #请假时间

    for RowOfWorkerInfo in cursor_1:
        #先把人名和工号填进去
        Sheet_1.cell(NowRows, 1).value = RowOfWorkerInfo[0]
        Sheet_1.cell(NowRows, 2).value = RowOfWorkerInfo[1]
        #添加进数组给以后使用
        List_1_WorkNumber.append(RowOfWorkerInfo[0])
        List_2_WorkerName.append(RowOfWorkerInfo[1])

        #先来计算总工时（台架除外）
        SumOfHours = 0  #把总工时初始化为0
    
        sql_temp =F"""
        SELECT* FROM 任务分配0试制班 WHERE 工号 = {RowOfWorkerInfo[0]} AND 发布时间 >= {TimeMin} AND 发布时间 <= {TimeMax} AND 工作类型 <> '（分配标记）' AND 工作类型 <> '（请假）'
        UNION ALL
        SELECT* FROM 任务分配0试验班 WHERE 工号 = {RowOfWorkerInfo[0]} AND 发布时间 >= {TimeMin} AND 发布时间 <= {TimeMax} AND 工作类型 <> '（分配标记）' AND 工作类型 <> '（请假）'
        """ 

        cursor_2 = connent.execute(sql_temp)
        for RowOfTime in cursor_2:
            SumOfHours = SumOfHours + ( RowOfTime[4] * RowOfTime[5] )

        Sheet_1.cell(NowRows, 3).value = SumOfHours
        List_3_TimeWithOutBench.append("%.1f" %(SumOfHours))

        #然后计算台架的工时
        SumOfBench = 0
        cursor_2 = connent.execute(F"SELECT* FROM 台架分配 WHERE 工号 = {RowOfWorkerInfo[0]} AND 发布时间 >= {TimeMin} AND 发布时间 <= {TimeMax}")
        for RowOfTime in cursor_2:
            SumOfBench = SumOfBench + ( RowOfTime[4] * RowOfTime[5] )
        Sheet_1.cell(NowRows, 4).value = SumOfBench
        List_4_TimeOfBench.append("%.1f" %(SumOfBench))

        #计算加在一起的工时
        Sheet_1.cell(NowRows, 5).value = SumOfHours + SumOfBench
        List_5_AllHours.append("%.1f" %(SumOfHours + SumOfBench))


        #然后是加班，这个很麻烦，因为没现成的数据用
        SumOfLateWork = 0
        #这个只是查个假期，放在最后用的
        cursor_2 = connent.execute(F"SELECT DISTINCT 发布时间,是否假期 FROM 每日流程0试制班 WHERE 发布时间 >= {TimeMin} AND 发布时间 <= {TimeMax}")
        #很迷啊，我当时为什么要这么写呢？导致了在只有台架的情况下，当日被跳过，谜啊，五怎么呢……我为什么要自找麻烦呢
        #cursor_2 = connent.execute(F"SELECT DISTINCT 任务分配0{GroupInThisMethod}.发布时间,是否假期 FROM 任务分配0{GroupInThisMethod} INNER JOIN 每日流程0{GroupInThisMethod} ON 任务分配0{GroupInThisMethod}.发布时间 = 每日流程0{GroupInThisMethod}.发布时间 WHERE 任务分配0{GroupInThisMethod}.发布时间 >= {TimeMin} AND 任务分配0{GroupInThisMethod}.发布时间 <= {TimeMax}")
        for RowOfLate in cursor_2:
            #先处理普通任务的
            #说起来按照算法来说，请假也是要算在内的，当然只在加班的时候算

            sql_temp =F"""
            SELECT * FROM 任务分配0试制班 WHERE 发布时间 = {RowOfLate[0]} AND 工号 = {RowOfWorkerInfo[0]} AND 工作类型 <> '（分配标记）'
            UNION ALL
            SELECT * FROM 任务分配0试验班 WHERE 发布时间 = {RowOfLate[0]} AND 工号 = {RowOfWorkerInfo[0]} AND 工作类型 <> '（分配标记）'
            """
            cursor_3 = connent.execute(sql_temp)
            DependLaterHours = 0
            for EachDayTime in cursor_3:
                DependLaterHours += EachDayTime[5]

            #然后要加上台架的，之前忘了加了
            cursor_3 = connent.execute(F"SELECT * FROM 台架分配 WHERE 发布时间 = {RowOfLate[0]} AND 工号 = {RowOfWorkerInfo[0]}")
            for EachDayTime in cursor_3:
                DependLaterHours += EachDayTime[5]

            #根据cursor_2判断是否假期
            if(RowOfLate[1] == "否"):
                if(DependLaterHours <= 8):
                    DependLaterHours = 0
                else:
                    DependLaterHours -= 8
            #如果是假期，就不需要上述操作
            SumOfLateWork += DependLaterHours
        
        Sheet_1.cell(NowRows, 6).value = SumOfLateWork
        List_6_LaterWork.append("%.1f" %(SumOfLateWork))

        #请假倒是比较简单
        SumOfLeave = 0
        sql_temp = F"""
        SELECT* FROM 任务分配0试制班 WHERE 工号 = {RowOfWorkerInfo[0]} AND 发布时间 >= {TimeMin} AND 发布时间 <= {TimeMax} AND 工作类型 = '（请假）'
        UNION ALL
        SELECT* FROM 任务分配0试验班 WHERE 工号 = {RowOfWorkerInfo[0]} AND 发布时间 >= {TimeMin} AND 发布时间 <= {TimeMax} AND 工作类型 = '（请假）'
        """
        cursor_2 = connent.execute(sql_temp)
        for RowOfLeave in cursor_2:
            SumOfLeave += RowOfLeave[5]

        Sheet_1.cell(NowRows, 7).value = SumOfLeave
        List_7_TakeLeave.append("%.1f" %(SumOfLeave))

        NowRows += 1    #循环结束后再自加

    ##################   2-按人员统计  ###################

    #把所有试制班的人找出来
    cursor_1 = connent.execute(F"SELECT* FROM 员工信息 WHERE 是否隐藏 = '否' ")
    NowRows = 1  #记一下行数给后面写入用
    NowCols = 1  #记一下列数给后面写入用

    #弄一些List给后面数据分析用
    ListByWorker_1_WorkNumber = []
    ListByWorker_2_WorkerName = []
    ListByWorker_3_QuestTimeSum = []

    #按人员循环
    for RowOfWorkerInfo in cursor_1:
        #每个人统计完以后要把NowRows重置
        NowRows = 1
        #先把人名和工号填进去
        Sheet_2.cell(1, NowCols).value = RowOfWorkerInfo[0]
        Sheet_2.cell(2, NowCols).value = RowOfWorkerInfo[1]
        #添加进数组给以后使用(还是有点问题，不知道怎么存，等会再说吧)
        ListByWorker_1_WorkNumber.append(RowOfWorkerInfo[0])
        ListByWorker_2_WorkerName.append(RowOfWorkerInfo[1])

        #开始填项目
        sql_temp = F"""
        SELECT DISTINCT 任务分配0试制班.统一编号,项目名 FROM 任务分配0试制班 INNER JOIN 任务信息 ON 任务分配0试制班.统一编号 = 任务信息.统一编号 WHERE 工号 = {RowOfWorkerInfo[0]} AND 发布时间 >= {TimeMin} AND 发布时间 <= {TimeMax} AND 工作类型 <> '（请假）' AND 工作类型 <> '（分配标记）'
        UNION ALL
        SELECT DISTINCT 任务分配0试验班.统一编号,项目名 FROM 任务分配0试验班 INNER JOIN 任务信息 ON 任务分配0试验班.统一编号 = 任务信息.统一编号 WHERE 工号 = {RowOfWorkerInfo[0]} AND 发布时间 >= {TimeMin} AND 发布时间 <= {TimeMax} AND 工作类型 <> '（请假）' AND 工作类型 <> '（分配标记）'
        """
        cursor_2 = connent.execute(sql_temp)
        for RowOfQuest in cursor_2:
            sql_temp2 = F"""
            SELECT * FROM 任务分配0试制班 WHERE 统一编号 ='{RowOfQuest[0]}' AND 工号 = {RowOfWorkerInfo[0]} AND 发布时间 >= {TimeMin} AND 发布时间 <= {TimeMax} AND 工作类型 <> '（请假）' AND 工作类型 <> '（分配标记）'
            UNION ALL
            SELECT * FROM 任务分配0试验班 WHERE 统一编号 ='{RowOfQuest[0]}' AND 工号 = {RowOfWorkerInfo[0]} AND 发布时间 >= {TimeMin} AND 发布时间 <= {TimeMax} AND 工作类型 <> '（请假）' AND 工作类型 <> '（分配标记）'
            """

            cursor_3 = connent.execute(sql_temp2)
            HoursForThisQuest = 0   #用来记录每个项目用的工时
            for RowOfWiatForAdd in cursor_3:
                HoursForThisQuest = HoursForThisQuest + (RowOfWiatForAdd[4] * RowOfWiatForAdd[5])
            Sheet_2.cell(NowRows, NowCols + 1).value = RowOfQuest[0]
            Sheet_2.cell(NowRows, NowCols + 2).value = RowOfQuest[1]
            Sheet_2.cell(NowRows, NowCols + 3).value = HoursForThisQuest

            NowRows += 1 

        NowCols += 4

    ##################   3-按项目统计  ###################
    sql_temp= F"""
    SELECT DISTINCT 任务分配0试制班.统一编号,项目名,内部编号 FROM 任务分配0试制班 INNER JOIN 任务信息 ON 任务分配0试制班.统一编号 = 任务信息.统一编号 WHERE  发布时间 >= {TimeMin} AND 发布时间 <= {TimeMax} AND 工作类型 <> '（请假）' AND 工作类型 <> '（分配标记）'
    UNION
    SELECT DISTINCT 任务分配0试验班.统一编号,项目名,内部编号 FROM 任务分配0试验班 INNER JOIN 任务信息 ON 任务分配0试验班.统一编号 = 任务信息.统一编号 WHERE  发布时间 >= {TimeMin} AND 发布时间 <= {TimeMax} AND 工作类型 <> '（请假）' AND 工作类型 <> '（分配标记）' ORDER BY 任务分配0试验班.统一编号
    """
    cursor_a = connent.execute(sql_temp)
    #cursor_b = connent.execute(F"SELECT DISTINCT 任务分配0试制班.统一编号,项目名,内部编号 FROM 任务分配0试制班 INNER JOIN 任务信息 ON 任务分配0试制班.统一编号 = 任务信息.统一编号 WHERE  发布时间 >= {TimeMin} AND 发布时间 <= {TimeMax} AND 工作类型 <> '（请假）' AND 工作类型 <> '（分配标记）' ORDER BY 任务分配0试制班.统一编号")
    
    cursor_c = connent.execute(F"SELECT DISTINCT 台架分配.统一编号,项目名,内部编号 FROM 台架分配 INNER JOIN 任务信息 ON 台架分配.统一编号 = 任务信息.统一编号 WHERE  发布时间 >= {TimeMin} AND 发布时间 <= {TimeMax} AND 工作类型 <> '（请假）' AND 工作类型 <> '（分配标记）' ORDER BY 台架分配.统一编号")
    NowRows = 1  #记一下行数给后面写入用

    for RowOfQuest in cursor_a:
        #先把项目编号和名字写进去
        Sheet_3.cell(NowRows, 1).value = RowOfQuest[0]
        Sheet_3.cell(NowRows, 2).value = RowOfQuest[1]
        Sheet_3.cell(NowRows, 3).value = RowOfQuest[2]
        SaveForAllTimePostion = NowRows
        AllTime = 0
        #然后查查这个项目谁在做

        sql_temp2 = F"""
        SELECT DISTINCT 任务分配0试制班.工号,姓名 FROM 任务分配0试制班 INNER JOIN 员工信息 ON 任务分配0试制班.工号 = 员工信息.工号 WHERE 统一编号 = '{RowOfQuest[0]}' AND 发布时间 >= {TimeMin} AND 发布时间 <= {TimeMax} AND 工作类型 <> '（请假）' AND 工作类型 <> '（分配标记）'
        UNION ALL
        SELECT DISTINCT 任务分配0试验班.工号,姓名 FROM 任务分配0试验班 INNER JOIN 员工信息 ON 任务分配0试验班.工号 = 员工信息.工号 WHERE 统一编号 = '{RowOfQuest[0]}' AND 发布时间 >= {TimeMin} AND 发布时间 <= {TimeMax} AND 工作类型 <> '（请假）' AND 工作类型 <> '（分配标记）'
        """
        cursor_2 = connent.execute(sql_temp2)
        for RowOfJoinWorker in cursor_2:
            Sheet_3.cell(NowRows, 5).value = RowOfJoinWorker[0]
            Sheet_3.cell(NowRows, 6).value = RowOfJoinWorker[1]
            #查查这个人做了多久
            sql_temp3 = F"""
            SELECT * FROM 任务分配0试制班 WHERE 工号={RowOfJoinWorker[0]} AND 统一编号 = '{RowOfQuest[0]}' AND 发布时间 >= {TimeMin} AND 发布时间 <= {TimeMax} AND 工作类型 <> '（请假）' AND 工作类型 <> '（分配标记）'
            UNION ALL
            SELECT * FROM 任务分配0试验班 WHERE 工号={RowOfJoinWorker[0]} AND 统一编号 = '{RowOfQuest[0]}' AND 发布时间 >= {TimeMin} AND 发布时间 <= {TimeMax} AND 工作类型 <> '（请假）' AND 工作类型 <> '（分配标记）'
            """
            cursor_3 = connent.execute(sql_temp3)
            QuestTime = 0
            for RowOfTime in cursor_3:
                QuestTime += (RowOfTime[4] * RowOfTime[5])
            Sheet_3.cell(NowRows, 7).value = QuestTime
            AllTime += QuestTime
            NowRows += 1
        Sheet_3.cell(SaveForAllTimePostion, 4).value = AllTime

    for RowOfQuest in cursor_c:
        #先把项目编号和名字写进去
        Sheet_3.cell(NowRows, 1).value = "(台架)"+RowOfQuest[0]
        Sheet_3.cell(NowRows, 2).value = RowOfQuest[1]
        Sheet_3.cell(NowRows, 3).value = RowOfQuest[2]
        SaveForAllTimePostion = NowRows
        AllTime = 0
        #然后查查这个项目谁在做
        cursor_2 = connent.execute(F"SELECT DISTINCT 台架分配.工号,姓名 FROM 台架分配 INNER JOIN 员工信息 ON 台架分配.工号 = 员工信息.工号 WHERE 统一编号 = '{RowOfQuest[0]}' AND 发布时间 >= {TimeMin} AND 发布时间 <= {TimeMax} AND 工作类型 <> '（请假）' AND 工作类型 <> '（分配标记）' ")
        for RowOfJoinWorker in cursor_2:
            Sheet_3.cell(NowRows, 5).value = RowOfJoinWorker[0]
            Sheet_3.cell(NowRows, 6).value = RowOfJoinWorker[1]
            #查查这个人做了多久
            cursor_3 = connent.execute(F"SELECT * FROM 台架分配 WHERE 工号={RowOfJoinWorker[0]} AND 统一编号 = '{RowOfQuest[0]}' AND 发布时间 >= {TimeMin} AND 发布时间 <= {TimeMax} AND 工作类型 <> '（请假）' AND 工作类型 <> '（分配标记）' ")
            QuestTime = 0
            for RowOfTime in cursor_3:
                QuestTime += (RowOfTime[4] * RowOfTime[5])
            Sheet_3.cell(NowRows, 7).value = QuestTime
            AllTime += QuestTime
            NowRows += 1
        Sheet_3.cell(SaveForAllTimePostion, 4).value = AllTime

    ##################   保存excel部分  ###################

    connent.close() #别忘了关连接
    WorkBook_Result.save('data/result/生成统计表-两班组.xlsx')    #别忘了保存

    ##################   PYecharts部分  ###################
    ##################   PYecharts部分  ###################

    ##################   1.柱状图  ###################
    bar = Bar()
    bar.add_xaxis(List_2_WorkerName)
    bar.add_yaxis("总工时",List_5_AllHours,stack='stack1')
    bar.add_yaxis("加班时间",List_6_LaterWork,stack='stack1')
    bar.add_yaxis("请假时间",List_7_TakeLeave,stack='stack1')
    bar.set_global_opts(title_opts=opts.TitleOpts(title = "工时总览",subtitle = "包含三种数据"))

    bar.set_series_opts(
        label_opts=opts.LabelOpts(is_show=False),
        markpoint_opts=opts.MarkPointOpts(
            data=[
                opts.MarkPointItem(type_="max",name="最大值"),
                opts.MarkPointItem(type_="min",name="最小值")

            ]
        ),
        markline_opts=opts.MarkLineOpts(
            data=[
                opts.MarkLineItem(type_="average",name="平均值")
            ]
        ),
    )
    bar.render(path="snapshot.png")
    bar.render("data/result/柱状图.html")

    ##################   2.柱状图  ###################
    line = Line()
    line.add_xaxis(List_2_WorkerName)
    line.add_yaxis("总工时",List_5_AllHours,is_smooth=True)
    line.add_yaxis("加班时间",List_6_LaterWork)
    line.add_yaxis("请假时间",List_7_TakeLeave)
    line.set_global_opts(title_opts=opts.TitleOpts(title = "工时总览",subtitle = "包含三种数据"))

    line.render("data/result/折线图.html")

    ##################   3.饼图  ###################
    #这玩意得做个元组列表
    List_Merge = []
    for i in range(len(List_2_WorkerName)):
        List_Merge.append((List_2_WorkerName[i],List_5_AllHours[i]))

    pie = Pie()
    pie.add("",List_Merge)
    pie.set_global_opts(title_opts=opts.TitleOpts(title = "工时总览",subtitle = "仅有总工时"))
    pie.set_series_opts(label_opts=opts.LabelOpts(formatter="{b}:{c}"))
    pie.render("data/result/饼图.html")





def OutPutWorkData(GroupInThisMethod,TimeMin,TimeMax):
    connent = sqlite3.connect(MyConstant.DataBaseAddress)
    
    #建立新表
    WorkBook_Result = openpyxl.Workbook()
    Sheet_1 = WorkBook_Result.active
    Sheet_1.title = "统计情况"
    Sheet_2 = WorkBook_Result.create_sheet("按人员统计") 
    Sheet_3 = WorkBook_Result.create_sheet("按项目统计")

    ##################   1-统计情况  ###################
    #先把默认字符填进去：人员、总工时、总加班、总请假
    Method_02.DefaultWord_TotalWorkTime(Sheet_1)

    #把所有该班组的人找出来
    sql = F"SELECT* FROM 员工信息 WHERE 所属班组 = '{GroupInThisMethod}' AND 是否隐藏 = '否' "
    cursor_1 = connent.execute(sql)
    NowRows = 2  #记一下行数给后面写入用

    #弄一些List给后面数据分析用
    List_1_WorkNumber = []  #工号列表
    List_2_WorkerName = []  #姓名列表
    List_3_TimeWithOutBench = []    #不包含台架的工时
    List_4_TimeOfBench = []     #台架的工时
    List_5_AllHours = []     #包含台架的工时
    List_6_LaterWork = []     #加班时间
    List_7_TakeLeave = []     #请假时间

    for RowOfWorkerInfo in cursor_1:
        #先把人名和工号填进去
        Sheet_1.cell(NowRows, 1).value = RowOfWorkerInfo[0]
        Sheet_1.cell(NowRows, 2).value = RowOfWorkerInfo[1]
        #添加进数组给以后使用
        List_1_WorkNumber.append(RowOfWorkerInfo[0])
        List_2_WorkerName.append(RowOfWorkerInfo[1])

        #先来计算总工时（台架除外）
        SumOfHours = 0  #把总工时初始化为0
    
        cursor_2 = connent.execute(F"SELECT* FROM 任务分配0{GroupInThisMethod} WHERE 工号 = {RowOfWorkerInfo[0]} AND 发布时间 >= {TimeMin} AND 发布时间 <= {TimeMax} AND 工作类型 <> '（分配标记）' AND 工作类型 <> '（请假）'")
        for RowOfTime in cursor_2:
            SumOfHours = SumOfHours + ( RowOfTime[4] * RowOfTime[5] )

        Sheet_1.cell(NowRows, 3).value = SumOfHours
        List_3_TimeWithOutBench.append("%.1f" %(SumOfHours))

        #然后计算台架的工时
        SumOfBench = 0
        cursor_2 = connent.execute(F"SELECT* FROM 台架分配 WHERE 工号 = {RowOfWorkerInfo[0]} AND 发布时间 >= {TimeMin} AND 发布时间 <= {TimeMax}")
        for RowOfTime in cursor_2:
            SumOfBench = SumOfBench + ( RowOfTime[4] * RowOfTime[5] )
        Sheet_1.cell(NowRows, 4).value = SumOfBench
        List_4_TimeOfBench.append("%.1f" %(SumOfBench))

        #计算加在一起的工时
        Sheet_1.cell(NowRows, 5).value = SumOfHours + SumOfBench
        List_5_AllHours.append("%.1f" %(SumOfHours + SumOfBench))


        #然后是加班，这个很麻烦，因为没现成的数据用
        SumOfLateWork = 0
        #这个只是查个假期，放在最后用的
        cursor_2 = connent.execute(F"SELECT DISTINCT 发布时间,是否假期 FROM 每日流程0{GroupInThisMethod} WHERE 发布时间 >= {TimeMin} AND 发布时间 <= {TimeMax}")
        #很迷啊，我当时为什么要这么写呢？导致了在只有台架的情况下，当日被跳过，谜啊，五怎么呢……我为什么要自找麻烦呢
        #cursor_2 = connent.execute(F"SELECT DISTINCT 任务分配0{GroupInThisMethod}.发布时间,是否假期 FROM 任务分配0{GroupInThisMethod} INNER JOIN 每日流程0{GroupInThisMethod} ON 任务分配0{GroupInThisMethod}.发布时间 = 每日流程0{GroupInThisMethod}.发布时间 WHERE 任务分配0{GroupInThisMethod}.发布时间 >= {TimeMin} AND 任务分配0{GroupInThisMethod}.发布时间 <= {TimeMax}")
        for RowOfLate in cursor_2:
            #先处理普通任务的
            #说起来按照算法来说，请假也是要算在内的，当然只在加班的时候算
            cursor_3 = connent.execute(F"SELECT * FROM 任务分配0{GroupInThisMethod} WHERE 发布时间 = {RowOfLate[0]} AND 工号 = {RowOfWorkerInfo[0]} AND 工作类型 <> '（分配标记）'")
            DependLaterHours = 0
            for EachDayTime in cursor_3:
                DependLaterHours += EachDayTime[5]

            #然后要加上台架的，之前忘了加了
            cursor_3 = connent.execute(F"SELECT * FROM 台架分配 WHERE 发布时间 = {RowOfLate[0]} AND 工号 = {RowOfWorkerInfo[0]}")
            for EachDayTime in cursor_3:
                DependLaterHours += EachDayTime[5]

            #根据cursor_2判断是否假期
            if(RowOfLate[1] == "否"):
                if(DependLaterHours <= 8):
                    DependLaterHours = 0
                else:
                    DependLaterHours -= 8
            #如果是假期，就不需要上述操作
            SumOfLateWork += DependLaterHours
        
        Sheet_1.cell(NowRows, 6).value = SumOfLateWork
        List_6_LaterWork.append("%.1f" %(SumOfLateWork))

        #请假倒是比较简单
        SumOfLeave = 0
        cursor_2 = connent.execute(F"SELECT* FROM 任务分配0{GroupInThisMethod} WHERE 工号 = {RowOfWorkerInfo[0]} AND 发布时间 >= {TimeMin} AND 发布时间 <= {TimeMax} AND 工作类型 = '（请假）'")
        for RowOfLeave in cursor_2:
            SumOfLeave += RowOfLeave[5]

        Sheet_1.cell(NowRows, 7).value = SumOfLeave
        List_7_TakeLeave.append("%.1f" %(SumOfLeave))

        NowRows += 1    #循环结束后再自加

    ##################   2-按人员统计  ###################

    #把所有试制班的人找出来
    cursor_1 = connent.execute(F"SELECT* FROM 员工信息 WHERE 所属班组 = '{GroupInThisMethod}' AND 是否隐藏 = '否' ")
    NowRows = 1  #记一下行数给后面写入用
    NowCols = 1  #记一下列数给后面写入用

    #弄一些List给后面数据分析用
    ListByWorker_1_WorkNumber = []
    ListByWorker_2_WorkerName = []
    ListByWorker_3_QuestTimeSum = []

    #按人员循环
    for RowOfWorkerInfo in cursor_1:
        #每个人统计完以后要把NowRows重置
        NowRows = 1
        #先把人名和工号填进去
        Sheet_2.cell(1, NowCols).value = RowOfWorkerInfo[0]
        Sheet_2.cell(2, NowCols).value = RowOfWorkerInfo[1]
        #添加进数组给以后使用(还是有点问题，不知道怎么存，等会再说吧)
        ListByWorker_1_WorkNumber.append(RowOfWorkerInfo[0])
        ListByWorker_2_WorkerName.append(RowOfWorkerInfo[1])

        #开始填项目
        cursor_2 = connent.execute(F"SELECT DISTINCT 任务分配0{GroupInThisMethod}.统一编号,项目名 FROM 任务分配0{GroupInThisMethod} INNER JOIN 任务信息 ON 任务分配0{GroupInThisMethod}.统一编号 = 任务信息.统一编号 WHERE 工号 = {RowOfWorkerInfo[0]} AND 发布时间 >= {TimeMin} AND 发布时间 <= {TimeMax} AND 工作类型 <> '（请假）' AND 工作类型 <> '（分配标记）'")
        for RowOfQuest in cursor_2:
            cursor_3 = connent.execute(F"SELECT * FROM 任务分配0{GroupInThisMethod} WHERE 统一编号 ='{RowOfQuest[0]}' AND 工号 = {RowOfWorkerInfo[0]} AND 发布时间 >= {TimeMin} AND 发布时间 <= {TimeMax} AND 工作类型 <> '（请假）' AND 工作类型 <> '（分配标记）'")
            HoursForThisQuest = 0   #用来记录每个项目用的工时
            for RowOfWiatForAdd in cursor_3:
                HoursForThisQuest = HoursForThisQuest + (RowOfWiatForAdd[4] * RowOfWiatForAdd[5])
            Sheet_2.cell(NowRows, NowCols + 1).value = RowOfQuest[0]
            Sheet_2.cell(NowRows, NowCols + 2).value = RowOfQuest[1]
            Sheet_2.cell(NowRows, NowCols + 3).value = HoursForThisQuest

            NowRows += 1 

        NowCols += 4

    ##################   3-按项目统计  ###################
    cursor_a = connent.execute(F"SELECT DISTINCT 任务分配0{GroupInThisMethod}.统一编号,项目名,内部编号 FROM 任务分配0{GroupInThisMethod} INNER JOIN 任务信息 ON 任务分配0{GroupInThisMethod}.统一编号 = 任务信息.统一编号 WHERE  发布时间 >= {TimeMin} AND 发布时间 <= {TimeMax} AND 工作类型 <> '（请假）' AND 工作类型 <> '（分配标记）' ORDER BY 任务分配0{GroupInThisMethod}.统一编号")
    #cursor_b = connent.execute(F"SELECT DISTINCT 任务分配0试制班.统一编号,项目名,内部编号 FROM 任务分配0试制班 INNER JOIN 任务信息 ON 任务分配0试制班.统一编号 = 任务信息.统一编号 WHERE  发布时间 >= {TimeMin} AND 发布时间 <= {TimeMax} AND 工作类型 <> '（请假）' AND 工作类型 <> '（分配标记）' ORDER BY 任务分配0试制班.统一编号")
    cursor_c = connent.execute(F"SELECT DISTINCT 台架分配.统一编号,项目名,内部编号 FROM 台架分配 INNER JOIN 任务信息 ON 台架分配.统一编号 = 任务信息.统一编号 WHERE  发布时间 >= {TimeMin} AND 发布时间 <= {TimeMax} AND 工作类型 <> '（请假）' AND 工作类型 <> '（分配标记）' ORDER BY 台架分配.统一编号")
    NowRows = 1  #记一下行数给后面写入用

    for RowOfQuest in cursor_a:
        #先把项目编号和名字写进去
        Sheet_3.cell(NowRows, 1).value = RowOfQuest[0]
        Sheet_3.cell(NowRows, 2).value = RowOfQuest[1]
        Sheet_3.cell(NowRows, 3).value = RowOfQuest[2]
        SaveForAllTimePostion = NowRows
        AllTime = 0
        #然后查查这个项目谁在做
        cursor_2 = connent.execute(F"SELECT DISTINCT 任务分配0{GroupInThisMethod}.工号,姓名 FROM 任务分配0{GroupInThisMethod} INNER JOIN 员工信息 ON 任务分配0{GroupInThisMethod}.工号 = 员工信息.工号 WHERE 统一编号 = '{RowOfQuest[0]}' AND 发布时间 >= {TimeMin} AND 发布时间 <= {TimeMax} AND 工作类型 <> '（请假）' AND 工作类型 <> '（分配标记）' ")
        for RowOfJoinWorker in cursor_2:
            Sheet_3.cell(NowRows, 5).value = RowOfJoinWorker[0]
            Sheet_3.cell(NowRows, 6).value = RowOfJoinWorker[1]
            #查查这个人做了多久
            cursor_3 = connent.execute(F"SELECT * FROM 任务分配0{GroupInThisMethod} WHERE 工号={RowOfJoinWorker[0]} AND 统一编号 = '{RowOfQuest[0]}' AND 发布时间 >= {TimeMin} AND 发布时间 <= {TimeMax} AND 工作类型 <> '（请假）' AND 工作类型 <> '（分配标记）' ")
            QuestTime = 0
            for RowOfTime in cursor_3:
                QuestTime += (RowOfTime[4] * RowOfTime[5])
            Sheet_3.cell(NowRows, 7).value = QuestTime
            AllTime += QuestTime
            NowRows += 1
        Sheet_3.cell(SaveForAllTimePostion, 4).value = AllTime

    for RowOfQuest in cursor_c:
        #先把项目编号和名字写进去
        Sheet_3.cell(NowRows, 1).value = "(台架)"+RowOfQuest[0]
        Sheet_3.cell(NowRows, 2).value = RowOfQuest[1]
        Sheet_3.cell(NowRows, 3).value = RowOfQuest[2]
        SaveForAllTimePostion = NowRows
        AllTime = 0
        #然后查查这个项目谁在做
        cursor_2 = connent.execute(F"SELECT DISTINCT 台架分配.工号,姓名 FROM 台架分配 INNER JOIN 员工信息 ON 台架分配.工号 = 员工信息.工号 WHERE 统一编号 = '{RowOfQuest[0]}' AND 发布时间 >= {TimeMin} AND 发布时间 <= {TimeMax} AND 工作类型 <> '（请假）' AND 工作类型 <> '（分配标记）' AND 所属班组 = '{GroupInThisMethod}' ")
        for RowOfJoinWorker in cursor_2:
            Sheet_3.cell(NowRows, 5).value = RowOfJoinWorker[0]
            Sheet_3.cell(NowRows, 6).value = RowOfJoinWorker[1]
            #查查这个人做了多久
            cursor_3 = connent.execute(F"SELECT * FROM 台架分配 WHERE 工号={RowOfJoinWorker[0]} AND 统一编号 = '{RowOfQuest[0]}' AND 发布时间 >= {TimeMin} AND 发布时间 <= {TimeMax} AND 工作类型 <> '（请假）' AND 工作类型 <> '（分配标记）' ")
            QuestTime = 0
            for RowOfTime in cursor_3:
                QuestTime += (RowOfTime[4] * RowOfTime[5])
            Sheet_3.cell(NowRows, 7).value = QuestTime
            AllTime += QuestTime
            NowRows += 1
        Sheet_3.cell(SaveForAllTimePostion, 4).value = AllTime

    ##################   保存excel部分  ###################

    connent.close() #别忘了关连接
    WorkBook_Result.save(F'data/result/生成统计表-{GroupInThisMethod}.xlsx')    #别忘了保存

    ##################   PYecharts部分  ###################
    ##################   PYecharts部分  ###################

    ##################   1.柱状图  ###################
    bar = Bar()
    bar.add_xaxis(List_2_WorkerName)
    bar.add_yaxis("总工时",List_5_AllHours,stack='stack1')
    bar.add_yaxis("加班时间",List_6_LaterWork,stack='stack1')
    bar.add_yaxis("请假时间",List_7_TakeLeave,stack='stack1')
    bar.set_global_opts(title_opts=opts.TitleOpts(title = "工时总览",subtitle = "包含三种数据"))

    bar.set_series_opts(
        label_opts=opts.LabelOpts(is_show=False),
        markpoint_opts=opts.MarkPointOpts(
            data=[
                opts.MarkPointItem(type_="max",name="最大值"),
                opts.MarkPointItem(type_="min",name="最小值")

            ]
        ),
        markline_opts=opts.MarkLineOpts(
            data=[
                opts.MarkLineItem(type_="average",name="平均值")
            ]
        ),
    )
    bar.render(path="snapshot.png")
    bar.render("data/result/柱状图.html")

    ##################   2.柱状图  ###################
    line = Line()
    line.add_xaxis(List_2_WorkerName)
    line.add_yaxis("总工时",List_5_AllHours,is_smooth=True)
    line.add_yaxis("加班时间",List_6_LaterWork)
    line.add_yaxis("请假时间",List_7_TakeLeave)
    line.set_global_opts(title_opts=opts.TitleOpts(title = "工时总览",subtitle = "包含三种数据"))

    line.render("data/result/折线图.html")

    ##################   3.饼图  ###################
    #这玩意得做个元组列表
    List_Merge = []
    for i in range(len(List_2_WorkerName)):
        List_Merge.append((List_2_WorkerName[i],List_5_AllHours[i]))

    pie = Pie()
    pie.add("",List_Merge)
    pie.set_global_opts(title_opts=opts.TitleOpts(title = "工时总览",subtitle = "仅有总工时"))
    pie.set_series_opts(label_opts=opts.LabelOpts(formatter="{b}:{c}"))
    pie.render("data/result/饼图.html")

