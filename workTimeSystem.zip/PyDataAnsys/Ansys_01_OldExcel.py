import sqlite3
import openpyxl

import MyStringMethod
import MyConstant
import Method_01

#将数据转为原版Excel
def DataToOldExcel():
    #先把通道打开
    connent = sqlite3.connect(MyConstant.DataBaseAddress)
    #把两组时间都拆分成年、月、日，方便分开成表（年因为偷懒没有用，日暂时也没有用，不管多少天我都输出整个月的）
    YearMin,MonthMin,DayMin = MyStringMethod.TheStringOfTime_ToYearMonthDay(MyConstant.TimeMin)
    YearMax,MonthMax,DayMax = MyStringMethod.TheStringOfTime_ToYearMonthDay(MyConstant.TimeMax)
    #对于每个月都要进行处理，但是每个月处理得方法都是一样的
    #先判断年份是不是一样，根据结果不同，月数也是不同的（先不做了，偷懒，以后补，现在的部分就是“Max和Min年份一样”的情况）
    for NowMonth in range(int(MonthMin),int(MonthMax) + 1):
        StringNowMonth = str(NowMonth)
        if(len(StringNowMonth) == 1):
            StringNowMonth = "0" + StringNowMonth
        else:
            pass
        MinDate = YearMin + StringNowMonth + "00"
        MaxDate = YearMax + StringNowMonth + "99"

        ############# 试验班 #############
        RebuildOldExcel(MinDate,MaxDate,YearMin,StringNowMonth,"试验班")

        ############# 试制班 #############
        RebuildOldExcel(MinDate,MaxDate,YearMin,StringNowMonth,"试制班")


#为各个班组重构老版Excel，以每个月为单位   
def RebuildOldExcel(MinDate,MaxDate,YearMin,StringNowMonth,Group_InThisMethod):
    #创建新的Excel
    WorkBook_Result = openpyxl.Workbook()
    Sheet_1 = WorkBook_Result.active
    Sheet_1.title = "待删除"
    #按Day来循环，要先查当月有哪些Day
    sql = F"SELECT DISTINCT 发布时间 FROM 每日流程0{Group_InThisMethod} WHERE 发布时间 >= {MinDate} AND 发布时间 <= {MaxDate} "
    connent = sqlite3.connect(MyConstant.DataBaseAddress)
    cursor_DaysOfThisMonth = connent.execute(sql)
    for Row_OfDays in cursor_DaysOfThisMonth:
        #先建立一个Sheet
        TodayTitle = str(Row_OfDays[0])[4:6] + "." + str(Row_OfDays[0])[6:8]
        Sheet_NowDays = WorkBook_Result.create_sheet(TodayTitle) 
        #填入预置的文字,前半部分
        Method_01.WriteInDefaultWords_BeforeWorker(Sheet_NowDays,Group_InThisMethod,Row_OfDays[0])
        #填入人员,返回最大列数,还返回了一个工号-列数的字典
        MaxColumnInExcel,Dict_PositionAndWorker = Method_01.WriteInWorkerName(Sheet_NowDays,connent,Group_InThisMethod,Row_OfDays[0])
        #填入任务，返回台架行数和最大行数
        BenchRowInExcel,MaxRowInExcel,Dict_PositionAndWorker = Method_01.WriteInQuestInfo(Sheet_NowDays,connent,Row_OfDays[0],Group_InThisMethod,Dict_PositionAndWorker)
        #填入预置的文字,后半部分
        Method_01.WriteInDefaultWords_AfterWorker(Sheet_NowDays,Row_OfDays[0],MaxColumnInExcel,BenchRowInExcel,MaxRowInExcel)
        #填入合计工时、加班时间和请假时间
        Method_01.WriteInSumOverLeave(Sheet_NowDays,Row_OfDays[0],MaxRowInExcel,Dict_PositionAndWorker,Group_InThisMethod,connent)
        #调整整体的格式
        Method_01.Format_Adjustment(Sheet_NowDays,MaxRowInExcel,MaxColumnInExcel)

    #保存Excel-当月的结果
    WorkBook_Result.remove_sheet(WorkBook_Result.get_sheet_by_name("待删除"))
    WorkBook_Result.save(F'data/result/原版Excel-{YearMin}年-{StringNowMonth}月-{Group_InThisMethod}.xlsx')
