import sqlite3
import openpyxl
import sys

import Ansys_01_OldExcel
import Ansys_02_StatisticsWorkTime
import Ansys_03_SummaryWorkTime
import Visual_01_VisualOfWorkTime
import Need_02_02_DifficultTotal
import MyConstant

# #################   测试用字段  ###################

# 由于有pyecharts，所以打包方法比较特殊

# pyinstaller -D -p D:\clean_masssoft\python3.8.2\Lib\site-packages main.py
# 并且将“prettytable-1.0.1.dist-info”和“pyecharts”两个文件夹放入


MyConstant.DataBaseAddress = sys.argv[1]
MyConstant.TimeMin = sys.argv[2]
MyConstant.TimeMax = sys.argv[3]
MyConstant.Group_IfNeed = sys.argv[4]
MyConstant.TheKindOfOutput = sys.argv[5]


# MyConstant.DataBaseAddress = "work_info.db3"
# MyConstant.TimeMin = "20201101"
# MyConstant.TimeMax = "20201131"
# MyConstant.Group_IfNeed = "两班组"
#
# MyConstant.TheKindOfOutput = "2-2-项目难度统计"


# #################   根据功能来进行  ###################

if(MyConstant.TheKindOfOutput == "1-1-原版Excel"):
    # #######此处其实是有问题的，暂时没有处理“如果人员有变动”的情况，全都是以“任务分配”里进行分别，如果人不在了，就pass了
    # 此功能暂时只能最多一次性导出一年的，请确认年份是一样的
    # 并且“日”是毫无意义的，反正总会导出整个月的
    Ansys_01_OldExcel.DataToOldExcel()

if(MyConstant.TheKindOfOutput == "1-2-工时统计"):
    if(MyConstant.Group_IfNeed == "两班组"):
        Ansys_02_StatisticsWorkTime.OutPutWorkData_TwoGroupMix(MyConstant.TimeMin,MyConstant.TimeMax)
        Ansys_03_SummaryWorkTime.SummaryData("试验班",MyConstant.TimeMin,MyConstant.TimeMax)
        Ansys_03_SummaryWorkTime.SummaryData("试制班",MyConstant.TimeMin,MyConstant.TimeMax)
    else:
        Ansys_02_StatisticsWorkTime.OutPutWorkData(MyConstant.Group_IfNeed,MyConstant.TimeMin,MyConstant.TimeMax)
        Ansys_03_SummaryWorkTime.SummaryData(MyConstant.Group_IfNeed,MyConstant.TimeMin,MyConstant.TimeMax)

if(MyConstant.TheKindOfOutput == "1-3-工时加班汇总"):#暂且废弃，和1-2合而为一
    if(MyConstant.Group_IfNeed == "两班组"):
        pass
    else:
        Ansys_03_SummaryWorkTime.SummaryData(MyConstant.Group_IfNeed,MyConstant.TimeMin,MyConstant.TimeMax)

if(MyConstant.TheKindOfOutput == "2-1-人员工时可视化"):
    if(MyConstant.Group_IfNeed == "两班组"):
        Visual_01_VisualOfWorkTime.DrawPicture_TwoGroupMix()
    else:
        Visual_01_VisualOfWorkTime.DrawPicture(MyConstant.Group_IfNeed,MyConstant.TimeMin,MyConstant.TimeMax)

if(MyConstant.TheKindOfOutput == "2-2-项目难度统计"):
    if(MyConstant.Group_IfNeed == "两班组"):
        Need_02_02_DifficultTotal.DifficultShow("试验班")
        Need_02_02_DifficultTotal.DifficultShow("试制班")
    else:
        Need_02_02_DifficultTotal.DifficultShow(MyConstant.Group_IfNeed)



