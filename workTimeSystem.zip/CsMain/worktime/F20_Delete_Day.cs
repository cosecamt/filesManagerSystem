﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace worktime
{
    public partial class F20_Delete_Day : Form
    {
        public F20_Delete_Day()
        {
            InitializeComponent();
        }

        private void F20_Delete_Day_Load(object sender, EventArgs e)
        {
            listView1.Items.Clear();
            //查询现在所有日期以及他们所处的流程状态
            string sql = "SELECT* FROM 每日流程0试验班 WHERE 台架流程 <> '已审核'";
            string sql2 = "SELECT* FROM 每日流程0试制班 WHERE 台架流程 <> '已审核'";
            DataSet ds = MySQL_Method.SQLite_search(sql);
            DataSet ds2 = MySQL_Method.SQLite_search(sql2);

            foreach (DataRow row in ds.Tables[0].Rows) {
                ListViewItem first = new ListViewItem(row["发布时间"].ToString());
                first.SubItems.Add(row["台架流程"].ToString());
                first.SubItems.Add(row["普通流程"].ToString());
                //然后在ds2中查找试制班的流程
                foreach (DataRow row2 in ds2.Tables[0].Rows) {
                    if (row["发布时间"].ToString() == row2["发布时间"].ToString()) {
                        first.SubItems.Add(row2["普通流程"].ToString());
                    }
                }

                listView1.Items.Add(first);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {



            if (listView1.FocusedItem != null) {
                string time = listView1.FocusedItem.SubItems[0].Text;
                if (MessageBox.Show("这将删除这一天的一切！包括发布、说明、工时、分配等等所有信息，一定要删除么？这些信息将无法恢复！", "Confirm Message", MessageBoxButtons.OKCancel) == DialogResult.OK) {
                    F16_password_whendelete F16_password_whendelete = new F16_password_whendelete(time);
                    F16_password_whendelete.ShowDialog();

                    //应该把这段封装的
                    listView1.Items.Clear();
                    //查询现在所有日期以及他们所处的流程状态
                    string sql = "SELECT* FROM 每日流程0试验班 WHERE 台架流程 <> '已审核'";
                    string sql2 = "SELECT* FROM 每日流程0试制班 WHERE 台架流程 <> '已审核'";
                    DataSet ds = MySQL_Method.SQLite_search(sql);
                    DataSet ds2 = MySQL_Method.SQLite_search(sql2);

                    foreach (DataRow row in ds.Tables[0].Rows) {
                        ListViewItem first = new ListViewItem(row["发布时间"].ToString());
                        first.SubItems.Add(row["台架流程"].ToString());
                        first.SubItems.Add(row["普通流程"].ToString());
                        //然后在ds2中查找试制班的流程
                        foreach (DataRow row2 in ds2.Tables[0].Rows) {
                            if (row["发布时间"].ToString() == row2["发布时间"].ToString()) {
                                first.SubItems.Add(row2["普通流程"].ToString());
                            }
                        }

                        listView1.Items.Add(first);
                    }

                }
            }
            else {
                MessageBox.Show("请先选择需要删除的目标");
            }



        }
    }
}
