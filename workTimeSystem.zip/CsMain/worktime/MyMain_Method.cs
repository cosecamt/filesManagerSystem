﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Data;
using System.Windows.Forms;
using System.Data.SQLite;
using System.Data.Common;
using System.Diagnostics;

namespace worktime
{
    class MyMain_Method   //此类保存主界面或多界面调用的方法
    {
        //读取员工信息并显示在列表
        public static void Read_WorkerList(F1_Main F1_Main)
        {
            F1_Main.listView1.Items.Clear();
            //查询所有员工的信息
            string sql = "SELECT* FROM 员工信息 WHERE 是否隐藏 = '否'";
            DataSet ds = MySQL_Method.SQLite_search(sql);

            foreach (DataRow row in ds.Tables[0].Rows) {
                ListViewItem first = new ListViewItem(row["工号"].ToString());
                first.SubItems.Add(row["姓名"].ToString());
                first.SubItems.Add(row["所属班组"].ToString());

                F1_Main.listView1.Items.Add(first);
            }
        }

        //按条件检索项目信息
        public static void Read_Quest_ByLimit(F1_Main F1_Main)
        {
            F1_Main.listView2.Items.Clear();
            string type = F1_Main.comboBox1.Text;
            string keyword = F1_Main.textBox5.Text;
            string sql = $"SELECT* FROM 任务信息 WHERE 项目状态 = '未完成' AND 项目分类 = '{type}' AND ( 项目名 LIKE '%{keyword}%' OR 编制部门 LIKE '%{keyword}%' OR 统一编号 LIKE '%{keyword}%') AND 是否隐藏 = '否' ORDER BY 录入时间 DESC";

            DataSet ds = MySQL_Method.SQLite_search(sql);

            foreach (DataRow row in ds.Tables[0].Rows) {
                ListViewItem first = new ListViewItem(row["统一编号"].ToString());
                first.SubItems.Add(row["生产订单号"].ToString());
                first.SubItems.Add(row["内部编号"].ToString());
                first.SubItems.Add(row["编制部门"].ToString());
                first.SubItems.Add(row["项目名"].ToString());
                first.SubItems.Add(row["项目要求"].ToString());
                first.SubItems.Add(row["项目状态"].ToString());
                first.SubItems.Add(row["录入时间"].ToString());
                first.SubItems.Add(row["项目分类"].ToString());
                first.SubItems.Add(row["项目等级"].ToString());

                F1_Main.listView2.Items.Add(first);
            }
        }

        //删除选中的员工信息，但实际上是被隐藏
        public static void Delete_ThisWorker(string num)
        {
            if (MessageBox.Show("确定要删除此条信息么？", "Confirm Message", MessageBoxButtons.OKCancel) == DialogResult.OK) {
                string sql = $"UPDATE 员工信息 SET 是否隐藏 = '是' WHERE 工号 = {num}";
                MySQL_Method.SQLite_update(sql);
            }
        }

        //删除所选的任务信息，不过实际上是隐藏而不是真的删除
        public static void Delete_ThisQuest(string num)
        {
            string sql = $"UPDATE 任务信息 SET 是否隐藏 = '是' WHERE 统一编号 = '{num}'";
            MySQL_Method.SQLite_update(sql);
        }

        //读取"已完成"任务信息并显示在列表
        public static void Read_Quest_HasDone(F1_Main F1_Main, string year, string month)
        {
            F1_Main.listView3.Items.Clear();

            //通过年月组合出当月的上下限
            string min = year + month + "00";
            string max = year + month + "99";

            //查询所有已完成的任务
            //string sql = $"SELECT* FROM 任务信息 WHERE 项目状态 = '已完成' AND 是否隐藏 = '否' AND 录入时间 > {min} AND 录入时间 < {max}";
            string sql = $"SELECT* FROM 任务信息 WHERE 项目状态 = '已完成' AND 是否隐藏 = '否'";
            DataSet ds = MySQL_Method.SQLite_search(sql);

            foreach (DataRow row in ds.Tables[0].Rows) {
                ListViewItem first = new ListViewItem(row["统一编号"].ToString());

                first.SubItems.Add(row["生产订单号"].ToString());
                first.SubItems.Add(row["内部编号"].ToString());
                first.SubItems.Add(row["编制部门"].ToString());
                first.SubItems.Add(row["项目名"].ToString());
                first.SubItems.Add(row["项目要求"].ToString());
                first.SubItems.Add(row["项目状态"].ToString());
                first.SubItems.Add(row["录入时间"].ToString());
                first.SubItems.Add(row["项目分类"].ToString());
                first.SubItems.Add(row["完成时间"].ToString());

                F1_Main.listView3.Items.Add(first);
            }

        }

        //读取任务分配部分的日期列表并显示在列表（分试验班和试制班和管理员）
        public static void Read_Distribute_DateList(F1_Main F1_Main)
        {
            F1_Main.listBox1.Items.Clear();
            //此处分两种情况
            //1.流程部分，如果普通流程=“已发布”并且查询发布表中存在是否分配 =“否”的情况，则视为正常分配
            //2.普通流程 = “已分配”，并且在发布表中存在是否分配 =“否”的情况，则视为追加
            //如果还处于“起草”或是已经“提交”“审核”，则不能发起追加任务

            //分三种权限来更新
            if (MyConstant_1.now_group == "管理员" || MyConstant_1.now_group == "技术组") {
                //先试验班
                string sql = $"SELECT* FROM 每日流程0试验班 WHERE 普通流程 = '已发布' OR 普通流程 = '已分配' ORDER BY 发布时间 DESC";
                DataSet ds = MySQL_Method.SQLite_search(sql);
                if (ds.Tables[0].Rows.Count >= 1) {
                    foreach (DataRow row in ds.Tables[0].Rows) {
                        if (row["普通流程"].ToString() == "已发布") {
                            string time = MyTools_Method.Num_ToDate(Convert.ToInt32(row["发布时间"].ToString()));
                            F1_Main.listBox1.Items.Add(time + "-" + "试验");
                        }
                        else {
                            string time = MyTools_Method.Num_ToDate(Convert.ToInt32(row["发布时间"].ToString()));
                            string sql2 = $"SELECT* FROM 任务发布0试验班 WHERE 发布时间 = {row["发布时间"].ToString()} AND 是否分配 = '没有分配'";
                            DataSet ds2 = MySQL_Method.SQLite_search(sql2);
                            if (ds2.Tables[0].Rows.Count >= 1) {
                                F1_Main.listBox1.Items.Add(time + "-" + "试验.追加");
                            }
                        }

                    }
                }

                //加一串分隔符
                F1_Main.listBox1.Items.Add("###############");

                //再查试制班
                string sql3 = $"SELECT* FROM 每日流程0试制班 WHERE 普通流程 = '已发布' OR 普通流程 = '已分配' ORDER BY 发布时间 DESC";
                DataSet ds3 = MySQL_Method.SQLite_search(sql3);
                if (ds3.Tables[0].Rows.Count >= 1) {
                    foreach (DataRow row in ds3.Tables[0].Rows) {
                        if (row["普通流程"].ToString() == "已发布") {
                            string time = MyTools_Method.Num_ToDate(Convert.ToInt32(row["发布时间"].ToString()));
                            F1_Main.listBox1.Items.Add(time + "-" + "试制");
                        }
                        else {
                            string time = MyTools_Method.Num_ToDate(Convert.ToInt32(row["发布时间"].ToString()));
                            string sql4 = $"SELECT* FROM 任务发布0试制班 WHERE 发布时间 = {row["发布时间"].ToString()} AND 是否分配 = '没有分配'";
                            DataSet ds4 = MySQL_Method.SQLite_search(sql4);
                            if (ds4.Tables[0].Rows.Count >= 1) {
                                F1_Main.listBox1.Items.Add(time + "-" + "试制.追加");
                            }
                        }

                    }
                }
            }
            else if (MyConstant_1.now_group == "试验班") {
                string sql5 = $"SELECT* FROM 每日流程0试验班 WHERE 普通流程 = '已发布' OR 普通流程 = '已分配' ORDER BY 发布时间 DESC";
                DataSet ds5 = MySQL_Method.SQLite_search(sql5);
                if (ds5.Tables[0].Rows.Count >= 1) {
                    foreach (DataRow row in ds5.Tables[0].Rows) {
                        if (row["普通流程"].ToString() == "已发布") {
                            string time = MyTools_Method.Num_ToDate(Convert.ToInt32(row["发布时间"].ToString()));
                            F1_Main.listBox1.Items.Add(time);
                        }
                        else {//换句话说，就是处于“已分配”状态
                            string time = MyTools_Method.Num_ToDate(Convert.ToInt32(row["发布时间"].ToString()));
                            string sql6 = $"SELECT* FROM 任务发布0试验班 WHERE 发布时间 = {row["发布时间"].ToString()} AND 是否分配 = '没有分配'";
                            DataSet ds6 = MySQL_Method.SQLite_search(sql6);
                            if (ds6.Tables[0].Rows.Count >= 1) {
                                F1_Main.listBox1.Items.Add(time + ".追加");
                            }
                        }

                    }
                }
            }
            else {
                string sql7 = $"SELECT* FROM 每日流程0试制班 WHERE 普通流程 = '已发布' OR 普通流程 = '已分配' ORDER BY 发布时间 DESC";
                DataSet ds7 = MySQL_Method.SQLite_search(sql7);
                if (ds7.Tables[0].Rows.Count >= 1) {
                    foreach (DataRow row in ds7.Tables[0].Rows) {
                        if (row["普通流程"].ToString() == "已发布") {
                            string time = MyTools_Method.Num_ToDate(Convert.ToInt32(row["发布时间"].ToString()));
                            F1_Main.listBox1.Items.Add(time);
                        }
                        else {
                            string time = MyTools_Method.Num_ToDate(Convert.ToInt32(row["发布时间"].ToString()));
                            string sql8 = $"SELECT* FROM 任务发布0试制班 WHERE 发布时间 = {row["发布时间"].ToString()} AND 是否分配 = '没有分配'";
                            DataSet ds8 = MySQL_Method.SQLite_search(sql8);
                            if (ds8.Tables[0].Rows.Count >= 1) {
                                F1_Main.listBox1.Items.Add(time + ".追加");
                            }
                        }
                    }
                }
            }
        }

        //更新待分配列表-任务
        public static void Read_DistributeResult(F1_Main F1_Main, string time, string group)
        {
            F1_Main.listView4.Items.Clear();

            //事务读取开始              
            DataSet ds = new DataSet();
            DataSet ds2 = new DataSet();
            SQLiteConnection connect = new SQLiteConnection(MyConstant_1.conStr);
            string sql = $"SELECT* FROM 任务发布0{group} INNER JOIN 任务信息 ON 任务发布0{group}.统一编号 = 任务信息.统一编号 WHERE 发布时间 = {time}";
            string sql2 = $"SELECT * FROM 任务分配0{group} INNER JOIN 员工信息 ON 任务分配0{group}.工号 = 员工信息.工号 WHERE 发布时间 = {time} AND 工作类型 = '（分配标记）'";

            connect.Open();
            DbTransaction trans = connect.BeginTransaction();

            SQLiteDataAdapter oleDapAdapter = new SQLiteDataAdapter(sql, MyConstant_1.conStr);
            oleDapAdapter.Fill(ds);
            SQLiteDataAdapter oleDapAdapter2 = new SQLiteDataAdapter(sql2, MyConstant_1.conStr);
            oleDapAdapter2.Fill(ds2);

            trans.Commit();
            connect.Close();
            //事务读取结束  


            /*
            string sql = $"SELECT* FROM 任务发布0{group} INNER JOIN 任务信息 ON 任务发布0{group}.统一编号 = 任务信息.统一编号 WHERE 发布时间 = {time}";
            DataSet ds = MySQL_Method.SQLite_search(sql);   //ds是所有任务的列表
            string sql2 = $"SELECT * FROM 任务分配0{group} INNER JOIN 员工信息 ON 任务分配0{group}.工号 = 员工信息.工号 WHERE 发布时间 = {time} AND 工作类型 = '（分配标记）'";
            DataSet ds2 = MySQL_Method.SQLite_search(sql2);   //ds_2是所有分配数据的列表
            */


            foreach (DataRow row in ds.Tables[0].Rows) {
                ListViewItem first = new ListViewItem(row["统一编号"].ToString());
                first.SubItems.Add(row["项目名"].ToString());

                string NoDistributeMark = "没有分配";
                string Result = "";
                foreach (DataRow row2 in ds2.Tables[0].Rows) {
                    if (row2["统一编号"].ToString() == row["统一编号"].ToString()) {
                        NoDistributeMark = "有分配";
                        Result = Result + " ，" + row2["姓名"].ToString();
                    }
                }
                if (NoDistributeMark == "没有分配") {
                    Result = "  （未设置）";
                }
                Result = Result.Substring(2);
                first.SubItems.Add(Result);

                F1_Main.listView4.Items.Add(first);

            }

        }

        //单击分配列表中的某个项目，显示他的信息
        public static void Read_InfoOf_ThisTodayQuest(string time, string num, string group, F1_Main F1_Main)
        {

            /*
            F1_Main.textBox7.Text = "";

            string sql = $"SELECT* FROM 任务信息 WHERE 统一编号 = '{num}'";

            DataSet ds = MySQL_Method.SQLite_search(sql);

            string text_num = ds.Tables[0].Rows[0]["统一编号"].ToString();
            string text_name = ds.Tables[0].Rows[0]["项目名"].ToString();
            string text_numin = ds.Tables[0].Rows[0]["内部编号"].ToString();
            string text_nummake = ds.Tables[0].Rows[0]["生产订单号"].ToString();
            string text_questask = ds.Tables[0].Rows[0]["项目要求"].ToString();
            string text_timeadd = ds.Tables[0].Rows[0]["录入时间"].ToString();
            string text_whogive = ds.Tables[0].Rows[0]["编制部门"].ToString();

            string text_today_ask = "";

            string sql2 = $"SELECT* FROM 任务说明0{group} WHERE 发布时间 = {time} AND 统一编号 = '{num}'";
            DataSet ds2 = MySQL_Method.SQLite_search(sql2);
            try {
                text_today_ask = ds2.Tables[0].Rows[0]["当日说明"].ToString();
            }
            catch { }

            string all_text = $"统一编号：{text_num}\r\n \r\n任务名：{text_name}\r\n \r\n当日说明：{text_today_ask}\r\n \r\n内部编号：{text_numin}\r\n生产订单号：{text_nummake}\r\n任务要求：{text_questask}\r\n录入时间：{text_timeadd}\r\n下发人:{text_whogive}";

            F1_Main.textBox7.Text = all_text;
            */

        }

        //单击分配列表中的某个项目，显示他的信息——台架版
        public static void Read_InfoOf_ThisTodayQuestBench(string time, string num, F1_Main F1_Main)
        {

            F1_Main.textBox11.Text = "";

            string sql = $"SELECT* FROM 任务信息 WHERE 统一编号 = '{num}'";

            DataSet ds = MySQL_Method.SQLite_search(sql);

            string text_num = ds.Tables[0].Rows[0]["统一编号"].ToString();
            string text_name = ds.Tables[0].Rows[0]["项目名"].ToString();
            string text_numin = ds.Tables[0].Rows[0]["内部编号"].ToString();
            string text_nummake = ds.Tables[0].Rows[0]["生产订单号"].ToString();
            string text_questask = ds.Tables[0].Rows[0]["项目要求"].ToString();
            string text_timeadd = ds.Tables[0].Rows[0]["录入时间"].ToString();
            string text_whogive = ds.Tables[0].Rows[0]["编制部门"].ToString();

            string text_today_ask = "";

            string sql2 = $"SELECT* FROM 台架说明 WHERE 发布时间 = {time} AND 统一编号 = '{num}'";
            DataSet ds2 = MySQL_Method.SQLite_search(sql2);
            try {
                text_today_ask = ds2.Tables[0].Rows[0]["当日说明"].ToString();
            }
            catch { }

            string all_text = $"统一编号：{text_num}\r\n \r\n任务名：{text_name}\r\n \r\n当日说明：{text_today_ask}\r\n \r\n内部编号：{text_numin}\r\n生产订单号：{text_nummake}\r\n任务要求：{text_questask}\r\n录入时间：{text_timeadd}\r\n下发人:{text_whogive}";

            F1_Main.textBox11.Text = all_text;


        }



        //改变当日流程-已分配
        public static void Change_TodayHasDistributed(string time)
        {
            string sql = $"UPDATE 每日流程0{MyConstant_1.now_group} SET 普通流程 = '已分配' WHERE 发布时间 = {time}";
            MySQL_Method.SQLite_update(sql);
        }

        //读取当日任务的日期列表并显示在列表（分试验班和试制班和管理员）
        public static void Read_TodayQuestList(F1_Main F1_Main)
        {
            F1_Main.listBox2.Items.Clear();
            //只有一种可能，那就是流程部分 = “已分配”。对于处于“已发布”时，或是“已提交”都不能有
            //里面的数据也只能和“分配”这张表相关，不涉及其他的。

            //分三种情况来更新
            if (MyConstant_1.now_group == "管理员" || MyConstant_1.now_group == "技术组") {
                //查询所有试验班的当日任务时间列表
                string sql = $"SELECT* FROM 每日流程0试验班 WHERE 普通流程 = '已分配' ORDER BY 发布时间 DESC";
                DataSet ds = MySQL_Method.SQLite_search(sql);
                foreach (DataRow row in ds.Tables[0].Rows) {
                    string time = MyTools_Method.Num_ToDate(Convert.ToInt32(row["发布时间"].ToString()));
                    F1_Main.listBox2.Items.Add(time + "-" + "试验班");
                }

                F1_Main.listBox2.Items.Add("###############");

                //查询所有试制班的当日任务时间列表
                string sql2 = $"SELECT* FROM 每日流程0试制班 WHERE 普通流程 = '已分配' ORDER BY 发布时间 DESC";
                DataSet ds2 = MySQL_Method.SQLite_search(sql2);
                foreach (DataRow row in ds2.Tables[0].Rows) {
                    string time = MyTools_Method.Num_ToDate(Convert.ToInt32(row["发布时间"].ToString()));
                    F1_Main.listBox2.Items.Add(time + "-" + "试制班");
                }

            }
            else if (MyConstant_1.now_group == "试制班") {
                //查询所有试制班的当日任务时间列表
                string sql = $"SELECT* FROM 每日流程0试制班 WHERE 普通流程 = '已分配' ORDER BY 发布时间 DESC";
                DataSet ds = MySQL_Method.SQLite_search(sql);
                foreach (DataRow row in ds.Tables[0].Rows) {
                    string time = MyTools_Method.Num_ToDate(Convert.ToInt32(row["发布时间"].ToString()));
                    F1_Main.listBox2.Items.Add(time);
                }
            }
            else {
                //查询所有试验班的当日任务时间列表
                string sql = $"SELECT* FROM 每日流程0试验班 WHERE 普通流程 = '已分配' ORDER BY 发布时间 DESC";
                DataSet ds = MySQL_Method.SQLite_search(sql);
                foreach (DataRow row in ds.Tables[0].Rows) {
                    string time = MyTools_Method.Num_ToDate(Convert.ToInt32(row["发布时间"].ToString()));
                    F1_Main.listBox2.Items.Add(time);
                }
            }
        }

        //更新今日需要做的任务以及相应的完成情况
        public static void Read_TodayQuest(F1_Main F1_Main, string time, string group)
        {
            F1_Main.dataGridView1.Rows.Clear();

            string sql = $"SELECT* FROM 任务发布0{group} INNER JOIN 任务信息 ON 任务信息.统一编号 = 任务发布0{group}.统一编号 WHERE 发布时间 = {time}";
            DataSet ds = MySQL_Method.SQLite_search(sql);//抓出当日所有任务
            string sql2 = $"SELECT* FROM 任务分配0{group} INNER JOIN 员工信息 ON 任务分配0{group}.工号 = 员工信息.工号 WHERE 发布时间 = {time} AND (工作类型 = '（分配标记）' OR 工作类型 = '废弃属性')";
            DataSet ds2 = MySQL_Method.SQLite_search(sql2);//抓出安排人员和结果，在一张表中
            foreach (DataRow row in ds.Tables[0].Rows) {
                string people = "";
                string result = "";
                string Note = row["当日备注"].ToString();

                int NumberOfWorker = 0;
                foreach (DataRow row2 in ds2.Tables[0].Rows) {
                    if (row2["工作类型"].ToString() == "（分配标记）" && row2["统一编号"].ToString() == row["统一编号"].ToString()) {
                        NumberOfWorker++;
                    }
                }


                if(NumberOfWorker == 0) {
                    people = "(无)";
                    result = "(请先分配人员)";
                }else {
                    foreach (DataRow row2 in ds2.Tables[0].Rows) {
                        if (row2["工作类型"].ToString() == "（分配标记）" && row2["统一编号"].ToString() == row["统一编号"].ToString()) {
                            people = people + "\r\n" + row2["姓名"].ToString();
                        }
                        if (row2["工作类型"].ToString() == "废弃属性" && row2["统一编号"].ToString() == row["统一编号"].ToString()) {
                            result = result + "\r\n" + row2["姓名"].ToString() + "-" + row2["工时系数"].ToString() + "-" + row2["工作小时"].ToString() + "h；";
                        }
                    }

                    if (result == "") {
                        result = "（未填报）";
                    }
                    else {
                        result = result.Substring(2);
                    }
                    people = people.Substring(2);
                }
                               

                F1_Main.dataGridView1.Rows.Add(row["统一编号"].ToString(), row["项目名"].ToString(), people, result, Note);
            }



        }



        //更新今日需要做的任务以及相应的完成情况——每个人单独的情况
        public static void Read_TodayQuest_ForEachWorker(F1_Main F1_Main, string time, string group)
        {
            F1_Main.dataGridView6.Rows.Clear();

            string sql = $"SELECT* FROM 员工信息 WHERE 所属班组 = '{group}'";
            DataSet ds = MySQL_Method.SQLite_search(sql);//抓出当前班组的所有人
            string sql2 = $"SELECT* FROM 任务分配0{group} WHERE 发布时间 = {time}";
            DataSet ds2 = MySQL_Method.SQLite_search(sql2);//抓出所有的任务





            foreach (DataRow row in ds.Tables[0].Rows) {

                double D_Hours = 0;
                double D_WorkTime = 0;
                double D_TakeLeave = 0;

                foreach (DataRow row2 in ds2.Tables[0].Rows) {
                    if (row2["工作类型"].ToString() == "废弃属性" && row2["工号"].ToString() == row["工号"].ToString()) {
                        D_Hours += Convert.ToDouble(row2["工作小时"]);
                        D_WorkTime = D_WorkTime + Convert.ToDouble(row2["工作小时"]) * Convert.ToDouble(row2["工时系数"]);
                    }

                    if (row2["工作类型"].ToString() == "（请假）" && row2["工号"].ToString() == row["工号"].ToString()) {
                        D_TakeLeave += Convert.ToDouble(row2["工作小时"]);
                    }
                }
                            
                
                F1_Main.dataGridView6.Rows.Add(row["工号"].ToString(), row["姓名"].ToString(), D_Hours.ToString(), D_WorkTime.ToString(), D_TakeLeave.ToString());
            }

        }

        //今日任务界面-单击-右方显示详细信息
        public static void TodayQuest_ThisInfo(F1_Main F1_Main, string num, string time)
        {
            /*
            string group = "";
            if (MyConstant_1.now_group == "管理员") {
                if (F1_Main.listBox2.SelectedItem.ToString().Contains("试验班") == true) {
                    group = "试验班";
                }
                else {
                    group = "试制班";
                }
            }
            else if (MyConstant_1.now_group == "试验班") {
                group = "试验班";
            }
            else {
                group = "试制班";
            }

            F1_Main.textBox6.Clear();
            string sql = $"SELECT* FROM 任务信息 WHERE 统一编号 = '{num}'";

            DataSet ds = MySQL_Method.SQLite_search(sql);

            string text_num = ds.Tables[0].Rows[0]["统一编号"].ToString();
            string text_name = ds.Tables[0].Rows[0]["项目名"].ToString();
            string text_numin = ds.Tables[0].Rows[0]["内部编号"].ToString();
            string text_nummake = ds.Tables[0].Rows[0]["生产订单号"].ToString();
            string text_questask = ds.Tables[0].Rows[0]["项目要求"].ToString();
            string text_timeadd = ds.Tables[0].Rows[0]["录入时间"].ToString();
            string text_whogive = ds.Tables[0].Rows[0]["编制部门"].ToString();

            string text_today_ask = "";

            string sql2 = $"SELECT* FROM 任务说明0{group} WHERE 统一编号 = '{num}' AND 发布时间 = {time}";
            DataSet ds2 = MySQL_Method.SQLite_search(sql2);
            try {
                text_today_ask = ds2.Tables[0].Rows[0]["当日说明"].ToString();
            }
            catch { }

            string all_text = $"统一编号：{text_num}\r\n \r\n任务名：{text_name}\r\n \r\n当日说明：{text_today_ask}\r\n \r\n内部编号：{text_numin}\r\n生产订单号：{text_nummake}\r\n任务要求：{text_questask}\r\n录入时间：{text_timeadd}\r\n下发人:{text_whogive}";

            F1_Main.textBox6.Text = all_text;
            */

        }

        //今日任务界面-单击-右方显示详细信息——富文本
        public static void TodayQuest_ThisInfo_InRichTextBox(F1_Main F1_Main, string num, string time)
        {
            string group = "";
            if (MyConstant_1.now_group == "管理员") {
                if (F1_Main.listBox2.SelectedItem.ToString().Contains("试验班") == true) {
                    group = "试验班";
                }
                else {
                    group = "试制班";
                }
            }
            else if (MyConstant_1.now_group == "试验班") {
                group = "试验班";
            }
            else {
                group = "试制班";
            }

            F1_Main.richTextBox1.Clear();
            string sql = $"SELECT* FROM 任务信息 WHERE 统一编号 = '{num}'";

            DataSet ds = MySQL_Method.SQLite_search(sql);

            string text_num = ds.Tables[0].Rows[0]["统一编号"].ToString();
            string text_name = ds.Tables[0].Rows[0]["项目名"].ToString();
            string text_numin = ds.Tables[0].Rows[0]["内部编号"].ToString();
            string text_nummake = ds.Tables[0].Rows[0]["生产订单号"].ToString();
            string text_questask = ds.Tables[0].Rows[0]["项目要求"].ToString();
            string text_timeadd = ds.Tables[0].Rows[0]["录入时间"].ToString();
            string text_whogive = ds.Tables[0].Rows[0]["编制部门"].ToString();

            string text_today_ask = "";

            string sql2 = $"SELECT* FROM 任务说明0{group} WHERE 统一编号 = '{num}' AND 发布时间 = {time}";
            DataSet ds2 = MySQL_Method.SQLite_search(sql2);
            try {
                text_today_ask = ds2.Tables[0].Rows[0]["当日说明"].ToString();
            }
            catch { }

            string all_text = $"统一编号：{text_num}\r\n \r\n任务名：{text_name}\r\n \r\n当日说明：\r\n{text_today_ask}\r\n \r\n内部编号：{text_numin}\r\n生产订单号：{text_nummake}\r\n任务要求：{text_questask}\r\n录入时间：{text_timeadd}\r\n下发人:{text_whogive}";

            F1_Main.richTextBox1.Text = all_text;

            F1_Main.richTextBox1.SelectionStart = text_num.Length + text_name.Length + 15;
            F1_Main.richTextBox1.SelectionLength = text_today_ask.Length +6;
            F1_Main.richTextBox1.SelectionFont = new System.Drawing.Font("黑体", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point,((System.Byte)(0)));
            F1_Main.richTextBox1.SelectionColor = System.Drawing.Color.Blue;


        }

        //每日流程-提交
        public static void Change_ToSubmit(string time)
        {
            string sql = $"UPDATE 每日流程0{MyConstant_1.now_group} SET 普通流程 = '已提交' WHERE 发布时间 = {time}";
            MySQL_Method.SQLite_update(sql);
        }

        //每日流程-提交——仅存在台架
        public static void Change_ToSubmitBench(string time)
        {
            //现在改为管理员提交，所以需要在两个班组进行提交
            string sql = $"UPDATE 每日流程0试验班 SET 台架流程 = '已提交' WHERE 发布时间 = {time}";
            MySQL_Method.SQLite_update(sql);
            sql = $"UPDATE 每日流程0试制班 SET 台架流程 = '已提交' WHERE 发布时间 = {time}";
            MySQL_Method.SQLite_update(sql);
        }


        //读取历史记录中“未审核”的事件列表并显示（分试验班和试制班和管理员）
        public static void Read_ListOfJudging(F1_Main F1_Main)
        {
            //此处的逻辑，要考虑到一份未审核记录是由普通项目和台架项目结合而成的
            //1-普通和台架都是“已提交”，正常显示
            //2-如果只是其中一个“已提交”，那么另一个有两种情况：“已分配/已分配”和“无”
            //3-因此要在页面上标记台架和普通，是否已经都提交/本身就不存在
            //4-如果存在某一个不处于“已提交”或“无 ”，那么“过审”按钮不能用

            F1_Main.listBox3.Items.Clear();
            //分三种情况来更新
            if (MyConstant_1.now_group == "管理员" || MyConstant_1.now_group == "技术组") {
                //查询所有试验班的未审核历史
                string sql = $"SELECT* FROM 每日流程0试验班 WHERE 普通流程 = '已提交' OR 台架流程 = '已提交' ORDER BY 发布时间 DESC";
                DataSet ds = MySQL_Method.SQLite_search(sql);
                foreach (DataRow row in ds.Tables[0].Rows) {
                    string time = MyTools_Method.Num_ToDate(Convert.ToInt32(row["发布时间"].ToString()));
                    if (row["是否假期"].ToString() == "是") {
                        time = time + "（休）";
                    }

                    F1_Main.listBox3.Items.Add(time + "-" + "试验班");
                }

                F1_Main.listBox3.Items.Add("###############");

                //查询所有试制班的未审核历史
                string sql2 = $"SELECT* FROM 每日流程0试制班 WHERE 普通流程 = '已提交' OR 台架流程 = '已提交'";
                DataSet ds2 = MySQL_Method.SQLite_search(sql2);
                foreach (DataRow row in ds2.Tables[0].Rows) {
                    string time = MyTools_Method.Num_ToDate(Convert.ToInt32(row["发布时间"].ToString()));
                    if (row["是否假期"].ToString() == "是") {
                        time = time + "（休）";
                    }

                    F1_Main.listBox3.Items.Add(time + "-" + "试制班");
                }

            }
            else if (MyConstant_1.now_group == "试制班") {
                //查询所有试制班的未审核历史
                string sql = $"SELECT* FROM 每日流程0试制班 WHERE 普通流程 = '已提交' OR 台架流程 = '已提交'";
                DataSet ds = MySQL_Method.SQLite_search(sql);
                foreach (DataRow row in ds.Tables[0].Rows) {
                    string time = MyTools_Method.Num_ToDate(Convert.ToInt32(row["发布时间"].ToString()));
                    if (row["是否假期"].ToString() == "是") {
                        time = time + "（休）";
                    }

                    F1_Main.listBox3.Items.Add(time);
                }
            }
            else {
                //查询所有试验班的未审核历史
                string sql = $"SELECT* FROM 每日流程0试验班 WHERE 普通流程 = '已提交' OR 台架流程 = '已提交'";
                DataSet ds = MySQL_Method.SQLite_search(sql);
                foreach (DataRow row in ds.Tables[0].Rows) {
                    string time = MyTools_Method.Num_ToDate(Convert.ToInt32(row["发布时间"].ToString()));
                    if (row["是否假期"].ToString() == "是") {
                        time = time + "（休）";
                    }

                    F1_Main.listBox3.Items.Add(time);
                }
            }
        }

        //读取-列表-未审核
        public static void Read_JudgingQuestInfo(F1_Main F1_Main, string time, string group)
        {
            F1_Main.dataGridView2.Rows.Clear();

            string sql = $"SELECT* FROM 任务发布0{group} INNER JOIN 任务信息 ON 任务信息.统一编号 = 任务发布0{group}.统一编号 WHERE 发布时间 = {time}";
            DataSet ds = MySQL_Method.SQLite_search(sql);//抓出当日所有任务
            string sql2 = $"SELECT* FROM 任务分配0{group} INNER JOIN 员工信息 ON 任务分配0{group}.工号 = 员工信息.工号 WHERE 发布时间 = {time} AND (工作类型 = '（分配标记）' OR 工作类型 = '废弃属性')";
            DataSet ds2 = MySQL_Method.SQLite_search(sql2);//抓出安排人员和结果，在一张表中
            
            foreach (DataRow row in ds.Tables[0].Rows) {
                string people = "";
                string result = "";

                int NumberOfWorker = 0;
                foreach (DataRow row2 in ds2.Tables[0].Rows) {
                    if (row2["工作类型"].ToString() == "（分配标记）" && row2["统一编号"].ToString() == row["统一编号"].ToString()) {
                        NumberOfWorker++;
                    }
                }

                if (NumberOfWorker == 0) {
                    people = "(无)";
                    result = "(请先分配人员)";
                }else {
                    foreach (DataRow row2 in ds2.Tables[0].Rows) {
                        if (row2["工作类型"].ToString() == "（分配标记）" && row2["统一编号"].ToString() == row["统一编号"].ToString()) {
                            people = people + "\r\n" + row2["姓名"].ToString();
                        }
                        if (row2["工作类型"].ToString() == "废弃属性" && row2["统一编号"].ToString() == row["统一编号"].ToString()) {
                            result = result + "\r\n" + row2["姓名"].ToString() + "-" + row2["工时系数"].ToString() + "-" + row2["工作小时"].ToString() + "h；";
                        }
                    }

                    if (result == "") {
                        result = "（未填报）";
                    }
                    else {
                        result = result.Substring(2);
                    }
                    if (people == "") {

                    }
                    else {
                        people = people.Substring(2);
                    }
                }               


                F1_Main.dataGridView2.Rows.Add(row["统一编号"].ToString(), row["项目名"].ToString(), people, result, row["当日备注"].ToString(), row["项目状态"].ToString(), row["项目等级"].ToString());
            }


        }

        //每日流程-审核
        public static void Change_JudingToJudged(string time, string group)
        {
            string sql = $"UPDATE 每日流程0{group} SET 普通流程 = '已审核', 台架流程 = '已审核' WHERE 发布时间 = {time}";
            MySQL_Method.SQLite_update(sql);
        }

        //读取历史记录中“已审核”的事件列表并显示（分试验班和试制班和管理员）
        public static void Read_JudgedList(F1_Main F1_Main, string year, string month)
        {
            F1_Main.listBox4.Items.Clear();

            //通过年月组合出当月的上下限
            string min = year + month + "00";
            string max = year + month + "99";

            if (MyConstant_1.now_group == "管理员" || MyConstant_1.now_group == "技术组") {
                string sql = $"SELECT* FROM 每日流程0试验班 WHERE 普通流程 = '已审核' AND 台架流程 = '已审核' AND 发布时间 > {min} AND 发布时间 < {max}";
                DataSet ds = MySQL_Method.SQLite_search(sql);
                foreach (DataRow row in ds.Tables[0].Rows) {
                    string time = MyTools_Method.Num_ToDate(Convert.ToInt32(row["发布时间"].ToString()));
                    if (row["是否假期"].ToString() == "是") {
                        time = time + "（休）";
                    }
                    F1_Main.listBox4.Items.Add(time + "-" + "试验班");
                }

                F1_Main.listBox4.Items.Add("###############");

                string sql2 = $"SELECT* FROM 每日流程0试制班 WHERE 普通流程 = '已审核' AND 台架流程 = '已审核' AND 发布时间 > {min} AND 发布时间 < {max}";
                DataSet ds2 = MySQL_Method.SQLite_search(sql2);
                foreach (DataRow row in ds2.Tables[0].Rows) {
                    string time = MyTools_Method.Num_ToDate(Convert.ToInt32(row["发布时间"].ToString()));
                    if (row["是否假期"].ToString() == "是") {
                        time = time + "（休）";
                    }
                    F1_Main.listBox4.Items.Add(time + "-" + "试制班");
                }
            }
            else if (MyConstant_1.now_group == "试制班") {
                string sql = $"SELECT* FROM 每日流程0试制班 WHERE 普通流程 = '已审核' AND 台架流程 = '已审核' AND 发布时间 > {min} AND 发布时间 < {max}";
                DataSet ds = MySQL_Method.SQLite_search(sql);
                foreach (DataRow row in ds.Tables[0].Rows) {
                    string time = MyTools_Method.Num_ToDate(Convert.ToInt32(row["发布时间"].ToString()));
                    if (row["是否假期"].ToString() == "是") {
                        time = time + "（休）";
                    }
                    F1_Main.listBox4.Items.Add(time);
                }
            }
            else {
                string sql = $"SELECT* FROM 每日流程0试验班 WHERE 普通流程 = '已审核' AND 台架流程 = '已审核' AND 发布时间 > {min} AND 发布时间 < {max}";
                DataSet ds = MySQL_Method.SQLite_search(sql);
                foreach (DataRow row in ds.Tables[0].Rows) {
                    string time = MyTools_Method.Num_ToDate(Convert.ToInt32(row["发布时间"].ToString()));
                    if (row["是否假期"].ToString() == "是") {
                        time = time + "（休）";
                    }
                    F1_Main.listBox4.Items.Add(time);
                }
            }
        }

        //确定数据库记录范围，并填写到历史记录和数据分析的部分
        public static void Search_DataExtent(F1_Main F1_Main)
        {
            string oldest = "";
            string newest = "";

            if (MyConstant_1.now_group == "管理员") {
                string oldest_1 = "";
                string newest_1 = "";
                string oldest_2 = "";
                string newest_2 = "";

                //实验班部分
                string sql = $"SELECT DISTINCT 发布时间 FROM 每日流程0试验班 WHERE 普通流程 = '已审核' ORDER BY 发布时间";
                DataSet ds = MySQL_Method.SQLite_search(sql);

                int count = ds.Tables[0].Rows.Count;
                if (count >= 1) {
                    oldest_1 = ds.Tables[0].Rows[0]["发布时间"].ToString();
                    newest_1 = ds.Tables[0].Rows[count - 1]["发布时间"].ToString();
                }
                else {
                    oldest_1 = "99999999";
                    newest_1 = "0";
                }


                //试制班部分
                string sql2 = $"SELECT DISTINCT 发布时间 FROM 每日流程0试制班 WHERE 普通流程 = '已审核' ORDER BY 发布时间";
                DataSet ds2 = MySQL_Method.SQLite_search(sql2);

                int count_2 = ds2.Tables[0].Rows.Count;
                if (count_2 >= 1) {
                    oldest_2 = ds2.Tables[0].Rows[0]["发布时间"].ToString();
                    newest_2 = ds2.Tables[0].Rows[count_2 - 1]["发布时间"].ToString();
                }
                else {
                    oldest_2 = "99999999";
                    newest_2 = "0";
                }

                //比较部分
                if (Convert.ToInt32(oldest_1) <= Convert.ToInt32(oldest_2)) {
                    oldest = oldest_1;
                }
                else {
                    oldest = oldest_2;
                }

                if (Convert.ToInt32(newest_1) >= Convert.ToInt32(newest_2)) {
                    newest = newest_1;
                }
                else {
                    newest = newest_2;
                }

            }
            else if (MyConstant_1.now_group == "试制班") {
                string sql = $"SELECT DISTINCT 发布时间 FROM 每日流程0试制班 WHERE 普通流程 = '已审核' ORDER BY 发布时间";
                DataSet ds = MySQL_Method.SQLite_search(sql);

                int count = ds.Tables[0].Rows.Count;
                if (count >= 1) {
                    oldest = ds.Tables[0].Rows[0]["发布时间"].ToString();
                    newest = ds.Tables[0].Rows[count - 1]["发布时间"].ToString();
                }
                else {
                    oldest = "99999999";
                    newest = "0";
                }

            }
            else {
                string sql = $"SELECT DISTINCT 发布时间 FROM 每日流程0试验班 WHERE 普通流程 = '已审核' ORDER BY 发布时间";
                DataSet ds = MySQL_Method.SQLite_search(sql);

                int count = ds.Tables[0].Rows.Count;
                if (count >= 1) {
                    oldest = ds.Tables[0].Rows[0]["发布时间"].ToString();
                    newest = ds.Tables[0].Rows[count - 1]["发布时间"].ToString();
                }
                else {
                    oldest = "99999999";
                    newest = "0";
                }

            }
            //处理特殊情况：数据库已审核的内容为空
            if (oldest == "99999999" && newest == "0") {
                oldest = "无数据";
                newest = "无数据";
            }

            //历史记录界面
            F1_Main.label15.Text = oldest;
            F1_Main.label13.Text = newest;
            //数据分析界面
            F1_Main.label6.Text = oldest;
            F1_Main.label11.Text = newest;
            //已完成任务部分
            F1_Main.label28.Text = oldest;
            F1_Main.label26.Text = newest;
            //复制框加入
            F1_Main.textBox12.Text = oldest;
            F1_Main.textBox13.Text = newest;
        }

        //在历史记录那里填入今天的年、月
        public static void WriteIn_TodayYearAndMonth(F1_Main F1_Main)
        {
            string time_now = DateTime.Now.ToString("yyyyMMdd");
            F1_Main.textBox3.Text = time_now.Substring(0, 4);
            F1_Main.textBox4.Text = time_now.Substring(4, 2);

            F1_Main.textBox9.Text = time_now.Substring(0, 4);
            F1_Main.textBox8.Text = time_now.Substring(4, 2);
        }

        //读取-列表-已审核
        public static void Read_ResultOf_JudgedQuest(F1_Main F1_Main, string time, string group)
        {
            F1_Main.dataGridView3.Rows.Clear();

            string sql = $"SELECT* FROM 任务发布0{group} INNER JOIN 任务信息 ON 任务信息.统一编号 = 任务发布0{group}.统一编号 WHERE 发布时间 = {time}";
            DataSet ds = MySQL_Method.SQLite_search(sql);//抓出当日所有任务
            string sql2 = $"SELECT* FROM 任务分配0{group} INNER JOIN 员工信息 ON 任务分配0{group}.工号 = 员工信息.工号 WHERE 发布时间 = {time} AND (工作类型 = '（分配标记）' OR 工作类型 = '废弃属性')";
            DataSet ds2 = MySQL_Method.SQLite_search(sql2);//抓出安排人员和结果，在一张表中

            foreach (DataRow row in ds.Tables[0].Rows) {
                string people = "";
                string result = "";

                int NumberOfWorker = 0;
                foreach (DataRow row2 in ds2.Tables[0].Rows) {
                    if (row2["工作类型"].ToString() == "（分配标记）" && row2["统一编号"].ToString() == row["统一编号"].ToString()) {
                        NumberOfWorker++;
                    }
                }

                if (NumberOfWorker == 0) {
                    people = "(无)";
                    result = "(请先分配人员)";
                }
                else {
                    foreach (DataRow row2 in ds2.Tables[0].Rows) {
                        if (row2["工作类型"].ToString() == "（分配标记）" && row2["统一编号"].ToString() == row["统一编号"].ToString()) {
                            people = people + "\r\n" + row2["姓名"].ToString();
                        }
                        if (row2["工作类型"].ToString() == "废弃属性" && row2["统一编号"].ToString() == row["统一编号"].ToString()) {
                            result = result + "\r\n" + row2["姓名"].ToString() + "-" + row2["工时系数"].ToString() + "-" + row2["工作小时"].ToString() + "h；";
                        }
                    }

                    if (result == "") {
                        result = "（未填报）";
                    }
                    else {
                        result = result.Substring(2);
                    }
                    people = people.Substring(2);
                }

                

                F1_Main.dataGridView3.Rows.Add(row["统一编号"].ToString(), row["项目名"].ToString(), people, result, row["当日备注"].ToString(), row["项目状态"].ToString());
           

        }

            

        }

        //读取已经起草的日期列表，因为是管理员，所以不用考虑班组
        public static void Read_DraftList(F1_Main F1_Main)
        {
            F1_Main.listBox6.Items.Clear();

            //随便查一个流程表就行，不用考虑是哪一个，在这阶段是同步的
            string sql = $"SELECT* FROM 每日流程0试验班 WHERE 普通流程 = '已起草' ORDER BY 发布时间 DESC";
            DataSet ds = MySQL_Method.SQLite_search(sql);

            if (ds.Tables[0].Rows.Count >= 1) {
                foreach (DataRow row in ds.Tables[0].Rows) {
                    string time = MyTools_Method.Num_ToDate(Convert.ToInt32(row["发布时间"].ToString()));
                    if (row["是否假期"].ToString() == "是") {
                        time = time + "（休）";
                    }
                    F1_Main.listBox6.Items.Add(time);
                }
            }

        }

        //任务发布界面，读取当前时间的起草内容——试验部分
        public static void Read_DraftQuest_SY(F1_Main F1_Main, string time)
        {
            F1_Main.listView5.Items.Clear();

            string sql = $"SELECT* FROM 任务发布0试验班 INNER JOIN 任务信息 ON 任务发布0试验班.统一编号 = 任务信息.统一编号 WHERE 发布时间 = {time}";
            DataSet ds = MySQL_Method.SQLite_search(sql);

            if (ds.Tables[0].Rows.Count >= 1) {
                foreach (DataRow row in ds.Tables[0].Rows) {
                    ListViewItem first = new ListViewItem(row["统一编号"].ToString());
                    first.SubItems.Add(row["项目名"].ToString());
                    string sql2 = $"SELECT* FROM 任务说明0试验班 WHERE 发布时间 = {time} AND 统一编号 = '{row["统一编号"].ToString()}'";
                    DataSet ds2 = MySQL_Method.SQLite_search(sql2);
                    if (ds2.Tables[0].Rows.Count >= 1) {
                        first.SubItems.Add(ds2.Tables[0].Rows[0]["当日说明"].ToString());
                    }
                    F1_Main.listView5.Items.Add(first);
                }
            }
        }

        //任务发布界面，读取当前时间的起草内容——试制部分
        public static void Read_DraftQuest_SZ(F1_Main F1_Main, string time)
        {
            F1_Main.listView6.Items.Clear();

            string sql = $"SELECT* FROM 任务发布0试制班 INNER JOIN 任务信息 ON 任务发布0试制班.统一编号 = 任务信息.统一编号 WHERE 发布时间 = {time}";
            DataSet ds = MySQL_Method.SQLite_search(sql);

            if (ds.Tables[0].Rows.Count >= 1) {
                foreach (DataRow row in ds.Tables[0].Rows) {
                    ListViewItem first = new ListViewItem(row["统一编号"].ToString());
                    first.SubItems.Add(row["项目名"].ToString());
                    string sql2 = $"SELECT* FROM 任务说明0试制班 WHERE 发布时间 = {time} AND 统一编号 = '{row["统一编号"].ToString()}'";
                    DataSet ds2 = MySQL_Method.SQLite_search(sql2);
                    if (ds2.Tables[0].Rows.Count >= 1) {
                        first.SubItems.Add(ds2.Tables[0].Rows[0]["当日说明"].ToString());
                    }
                    F1_Main.listView6.Items.Add(first);
                }
            }
        }

        //任务发布界面，读取当前时间的起草内容——台架部分
        public static void Read_DraftQuest_TJ(F1_Main F1_Main, string time)
        {
            F1_Main.listView7.Items.Clear();

            string sql = $"SELECT* FROM 台架发布 INNER JOIN 任务信息 ON 台架发布.统一编号 = 任务信息.统一编号 WHERE 发布时间 = {time}";
            DataSet ds = MySQL_Method.SQLite_search(sql);

            if (ds.Tables[0].Rows.Count >= 1) {
                foreach (DataRow row in ds.Tables[0].Rows) {
                    ListViewItem first = new ListViewItem(row["统一编号"].ToString());
                    first.SubItems.Add(row["项目名"].ToString());
                    string sql2 = $"SELECT* FROM 台架说明 WHERE 发布时间 = {time} AND 统一编号 = '{row["统一编号"].ToString()}'";
                    DataSet ds2 = MySQL_Method.SQLite_search(sql2);
                    if (ds2.Tables[0].Rows.Count >= 1) {
                        first.SubItems.Add(ds2.Tables[0].Rows[0]["当日说明"].ToString());
                    }
                    F1_Main.listView7.Items.Add(first);
                }
            }
        }

        //在发布页面，2个listview点击右下角显示相关的任务信息
        public static void Read_QuestInfo_WhenPublish(F1_Main F1_Main,string time, string num, string group)
        {
            F1_Main.textBox10.Text = "";

            string sql = $"SELECT* FROM 任务信息 WHERE 统一编号 = '{num}'";

            DataSet ds = MySQL_Method.SQLite_search(sql);

            string text_num = ds.Tables[0].Rows[0]["统一编号"].ToString();
            string text_name = ds.Tables[0].Rows[0]["项目名"].ToString();
            string text_numin = ds.Tables[0].Rows[0]["内部编号"].ToString();
            string text_nummake = ds.Tables[0].Rows[0]["生产订单号"].ToString();
            string text_questask = ds.Tables[0].Rows[0]["项目要求"].ToString();
            string text_timeadd = ds.Tables[0].Rows[0]["录入时间"].ToString();
            string text_whogive = ds.Tables[0].Rows[0]["编制部门"].ToString();

            string text_today_ask = "";

            string sql2 = $"SELECT* FROM 任务说明0{group} WHERE 统一编号 = '{num}' AND 发布时间 = {time}";
            DataSet ds2 = MySQL_Method.SQLite_search(sql2);
            try {
                text_today_ask = ds2.Tables[0].Rows[0]["当日说明"].ToString();
            }
            catch { }

            string all_text = $"统一编号：{text_num}\r\n \r\n任务名：{text_name}\r\n \r\n内部编号：{text_numin}\r\n生产订单号：{text_nummake}\r\n任务要求：{text_questask}\r\n录入时间：{text_timeadd}\r\n下发人:{text_whogive}\r\n \r\n当日说明：{text_today_ask}";

            F1_Main.textBox10.Text = all_text;



        }

        //在发布页面，2个listview点击右下角显示相关的任务信息
        public static void Read_QuestInfo_WhenPublish_Bench(F1_Main F1_Main, string time, string num)
        {
            F1_Main.textBox10.Text = "";

            string sql = $"SELECT* FROM 任务信息 WHERE 统一编号 = '{num}'";

            DataSet ds = MySQL_Method.SQLite_search(sql);

            string text_num = ds.Tables[0].Rows[0]["统一编号"].ToString();
            string text_name = ds.Tables[0].Rows[0]["项目名"].ToString();
            string text_numin = ds.Tables[0].Rows[0]["内部编号"].ToString();
            string text_nummake = ds.Tables[0].Rows[0]["生产订单号"].ToString();
            string text_questask = ds.Tables[0].Rows[0]["项目要求"].ToString();
            string text_timeadd = ds.Tables[0].Rows[0]["录入时间"].ToString();
            string text_whogive = ds.Tables[0].Rows[0]["编制部门"].ToString();

            string text_today_ask = "";

            string sql2 = $"SELECT* FROM 台架说明 WHERE 统一编号 = '{num}' AND 发布时间 = {time}";
            DataSet ds2 = MySQL_Method.SQLite_search(sql2);
            try {
                text_today_ask = ds2.Tables[0].Rows[0]["当日说明"].ToString();
            }
            catch { }

            string all_text = $"统一编号：{text_num}\r\n \r\n任务名：{text_name}\r\n \r\n内部编号：{text_numin}\r\n生产订单号：{text_nummake}\r\n任务要求：{text_questask}\r\n录入时间：{text_timeadd}\r\n下发人:{text_whogive}\r\n \r\n当日说明：{text_today_ask}";

            F1_Main.textBox10.Text = all_text;



        }

        //任务发布界面，读取值班人员
        public static void Read_BenchWorker_InPublish(F1_Main F1_Main, string time)
        {
            string sy = "";
            string sz = "";

            string sql = $"SELECT* FROM 台架发布 INNER JOIN 员工信息 ON 台架发布.工号 = 员工信息.工号 WHERE 数据类型 = '人员' AND 发布时间 <= {time}";
            DataSet ds = MySQL_Method.SQLite_search(sql);
            if(ds.Tables[0].Rows.Count >= 1) {
                foreach (DataRow row in ds.Tables[0].Rows) {
                    if (row["所属班组"].ToString() == "试验班") {
                        sy = sy + "，" + row["姓名"].ToString();
                    }
                    else {
                        sz = sz + "，" + row["姓名"].ToString();
                    }
                }
                if (sy.Length >= 1) {
                    sy = sy.Substring(1);
                }
                if (sz.Length >= 1) {
                    sz = sz.Substring(1);
                }
            }
            

            F1_Main.label32.Text = sy;
            F1_Main.label31.Text = sz;
        }

        //任务发布，修改每日流程，试验和试制
        public static void ChangeProcess_WhenPubished(F1_Main F1_Main, string time, string group)
        {
            string sql = $"UPDATE 每日流程0{group} SET 普通流程 = '已发布' WHERE 发布时间 = {time}";
            MySQL_Method.SQLite_update(sql);
        }

        //任务发布，修改每日流程，台架版本
        public static void ChangeProcess_Bench_WhenPubished(F1_Main F1_Main, string time)
        {
            //要在试验班和试制班两个地方修改
            string sql = $"UPDATE 每日流程0试验班 SET 台架流程 = '已分配' WHERE 发布时间 = {time}";
            MySQL_Method.SQLite_update(sql);
            sql = $"UPDATE 每日流程0试制班 SET 台架流程 = '已分配' WHERE 发布时间 = {time}";
            MySQL_Method.SQLite_update(sql);
        }

        //任务发布，修改每日流程，试验和试制——但是却没有相应的任务的情况
        public static void ChangeProcess_WhenPubished_ButNoQuest(F1_Main F1_Main, string time, string group)
        {
            string sql = $"UPDATE 每日流程0{group} SET 普通流程 = '无' WHERE 发布时间 = {time}";
            MySQL_Method.SQLite_update(sql);
        }

        //任务发布，修改每日流程，台架版本——但是却没有相应的任务的情况
        public static void ChangeProcess_Bench_WhenPubished_ButNoQuest(F1_Main F1_Main, string time)
        {
            string sql = $"UPDATE 每日流程0试验班 SET 台架流程 = '无' WHERE 发布时间 = {time}";
            MySQL_Method.SQLite_update(sql);
            sql = $"UPDATE 每日流程0试制班 SET 台架流程 = '无' WHERE 发布时间 = {time}";
            MySQL_Method.SQLite_update(sql);
        }

        //读取当日任务的日期列表并显示在列表（分试验班和试制班和管理员）
        public static void Read_TodayQuestList_Bench(F1_Main F1_Main)
        {
            F1_Main.listBox5.Items.Clear();
            //台架，此时也为已分配

            //分三种情况来更新
            if (MyConstant_1.now_group == "管理员" || MyConstant_1.now_group == "技术组") {
                //查询所有试验班的当日任务时间列表
                string sql = $"SELECT* FROM 每日流程0试验班 WHERE 台架流程 = '已分配' ORDER BY 发布时间 DESC";
                DataSet ds = MySQL_Method.SQLite_search(sql);
                foreach (DataRow row in ds.Tables[0].Rows) {
                    string time = MyTools_Method.Num_ToDate(Convert.ToInt32(row["发布时间"].ToString()));
                    F1_Main.listBox5.Items.Add(time);
                }

            }
            else if (MyConstant_1.now_group == "试制班") {
                //查询所有试制班的当日任务时间列表
                string sql = $"SELECT* FROM 每日流程0试制班 WHERE 台架流程 = '已分配'";
                DataSet ds = MySQL_Method.SQLite_search(sql);
                foreach (DataRow row in ds.Tables[0].Rows) {
                    string time = MyTools_Method.Num_ToDate(Convert.ToInt32(row["发布时间"].ToString()));
                    F1_Main.listBox5.Items.Add(time);
                }
            }
            else {
                //查询所有试验班的当日任务时间列表
                string sql = $"SELECT* FROM 每日流程0试验班 WHERE 台架流程 = '已分配'";
                DataSet ds = MySQL_Method.SQLite_search(sql);
                foreach (DataRow row in ds.Tables[0].Rows) {
                    string time = MyTools_Method.Num_ToDate(Convert.ToInt32(row["发布时间"].ToString()));
                    F1_Main.listBox5.Items.Add(time);
                }
            }
        }


        //更新今日需要做的任务以及相应的完成情况
        public static void Read_TodayQuest_Bench(F1_Main F1_Main, string time)
        {
            //由于这里统一由管理员填写了，所以group实际上并没有什么用了
            
            F1_Main.dataGridView4.Rows.Clear();
            //第一个sql是把当天所有项目抓出来
            string sql = $"SELECT* FROM 台架发布 INNER JOIN 任务信息 ON 台架发布.统一编号 = 任务信息.统一编号 WHERE 发布时间 = {time} AND 数据类型 = '项目'";
            DataSet ds = MySQL_Method.SQLite_search(sql);
            //第二个sql是把当天所有人抓出来
            string sql2 = $"SELECT* FROM 台架发布 INNER JOIN 员工信息 ON 台架发布.工号 = 员工信息.工号 WHERE 发布时间 = {time} AND 数据类型 = '人员'";
            DataSet ds2 = MySQL_Method.SQLite_search(sql2);
            //第三个sql是把当天的所有工时情况抓出来
            string sql3 = $"SELECT* FROM 台架分配 INNER JOIN 员工信息 ON 台架分配.工号 = 员工信息.工号 INNER JOIN 任务信息 ON 台架分配.统一编号 = 任务信息.统一编号 WHERE 发布时间 = {time} ORDER BY 员工信息.工号";
            DataSet ds3 = MySQL_Method.SQLite_search(sql3);


            //首先用sql把统一编号和任务名写上
            //然后用sql2把安排人员写上
            //最后用sql3把完成结果
            
            foreach (DataRow row in ds.Tables[0].Rows) {
                string people = "";
                string result = "";

                foreach(DataRow row2 in ds2.Tables[0].Rows) {
                    people = people + "\r\n" + row2["姓名"].ToString();
                }
                people = people.Substring(2);

                foreach (DataRow row3 in ds3.Tables[0].Rows) {
                    if (row3["统一编号"].ToString() == row["统一编号"].ToString()) {
                        result = result + "\r\n" + row3["姓名"].ToString() + "-" + row3["工时系数"].ToString() + "-" + row3["工作小时"].ToString() + "h；";
                    }
                }

                if(result == "") {
                    result = "（未填报）";
                }
                else {
                    result = result.Substring(2);
                }
                
                F1_Main.dataGridView4.Rows.Add(row["统一编号"].ToString(), row["项目名"].ToString(), people, result);
            }

            
        }

        //刷新值班人员选择,实际上是最近的，显示在任务编排页面
        public static void Read_BenchWorker_Today_WhenpublishList(F1_Main F1_Main, string time)
        {
            string time_near = "20200230";
            string sql2 = $"SELECT* FROM 台架发布 INNER JOIN 员工信息 ON 台架发布.工号 = 员工信息.工号 WHERE 数据类型 = '人员' AND 发布时间 <= {time} ORDER BY 发布时间 DESC";
            DataSet ds2 = MySQL_Method.SQLite_search(sql2);
            if (ds2.Tables[0].Rows.Count >= 1) {
                time_near = ds2.Tables[0].Rows[0]["发布时间"].ToString();
            }

            string sql = $"SELECT* FROM 台架发布 INNER JOIN 员工信息 ON 台架发布.工号 = 员工信息.工号 WHERE 数据类型 = '人员' AND 发布时间 = {time_near}";
            DataSet ds = MySQL_Method.SQLite_search(sql);
            string sy = "";
            string sz = "";

            foreach (DataRow row in ds.Tables[0].Rows) {
                if (row["所属班组"].ToString() == "试验班") {
                    sy = sy + "，" + row["姓名"].ToString();
                }
                else {
                    sz = sz + "，" + row["姓名"].ToString();
                }
            }
            if (sy.Length >= 1) {
                sy = sy.Substring(1);
            }
            if (sz.Length >= 1) {
                sz = sz.Substring(1);
            }

            F1_Main.label32.Text = sy;
            F1_Main.label31.Text = sz;

        }

        //刷新值班人员选择,实际上是最近的，显示在台架页面
        public static void Read_BenchWorker_Today_WhenBenchList(F1_Main F1_Main, string time)
        {
            string sql = $"SELECT* FROM 台架发布 INNER JOIN 员工信息 ON 台架发布.工号 = 员工信息.工号 WHERE 数据类型 = '人员' AND 发布时间 = {time}";
            DataSet ds = MySQL_Method.SQLite_search(sql);
            string sy = "";
            string sz = "";

            foreach (DataRow row in ds.Tables[0].Rows) {
                if (row["所属班组"].ToString() == "试验班") {
                    sy = sy + "，" + row["姓名"].ToString();
                }
                else {
                    sz = sz + "，" + row["姓名"].ToString();
                }
            }
            if (sy.Length >= 1) {
                sy = sy.Substring(1);
            }
            if (sz.Length >= 1) {
                sz = sz.Substring(1);
            }

            F1_Main.label37.Text = sy;
            F1_Main.label36.Text = sz;

        }

        //在审核页面将当日退回
        public static void Change_JudingToBack(string time, string group)
        {
            string sql = $"UPDATE 每日流程0{group} SET 普通流程 = '已分配' WHERE 发布时间 = {time}";
            MySQL_Method.SQLite_update(sql);
        }

        //读取-列表-未审核——台架版本
        public static void Read_JudgingQuestInfo_ByBench(F1_Main F1_Main, string time, string group)
        {
            //第一个sql是把当天所有项目抓出来
            string sql = $"SELECT* FROM 台架发布 INNER JOIN 任务信息 ON 台架发布.统一编号 = 任务信息.统一编号 WHERE 发布时间 = {time} AND 数据类型 = '项目'";
            DataSet ds = MySQL_Method.SQLite_search(sql);
            //第二个sql是把当天所有人抓出来
            string sql2 = $"SELECT* FROM 台架发布 INNER JOIN 员工信息 ON 台架发布.工号 = 员工信息.工号 WHERE 发布时间 = {time} AND 数据类型 = '人员'";
            DataSet ds2 = MySQL_Method.SQLite_search(sql2);
            //第三个sql是把当天的所有工时情况抓出来
            string sql3 = $"SELECT* FROM 台架分配 INNER JOIN 员工信息 ON 台架分配.工号 = 员工信息.工号 INNER JOIN 任务信息 ON 台架分配.统一编号 = 任务信息.统一编号 WHERE 发布时间 = {time} ORDER BY 员工信息.工号";
            DataSet ds3 = MySQL_Method.SQLite_search(sql3);


            //首先用sql把统一编号和任务名写上
            //然后用sql2把安排人员写上
            //最后用sql3把完成结果

            foreach (DataRow row in ds.Tables[0].Rows) {
                string people = "";
                string result = "";

                foreach (DataRow row2 in ds2.Tables[0].Rows) {
                    people = people + "\r\n" + row2["姓名"].ToString();
                }
                people = people.Substring(2);

                foreach (DataRow row3 in ds3.Tables[0].Rows) {
                    if (row3["统一编号"].ToString() == row["统一编号"].ToString()) {
                        result = result + "\r\n" + row3["姓名"].ToString() + "-" + row3["工时系数"].ToString() + "-" + row3["工作小时"].ToString() + "h；";
                    }
                }

                if (result == "") {
                    result = "（未填报）";
                }
                else {
                    result = result.Substring(2);
                }

                F1_Main.dataGridView2.Rows.Add(row["统一编号"].ToString(), "(台架)" + row["项目名"].ToString(), people, result, row["当日备注"].ToString(), row["项目状态"].ToString(), row["项目等级"].ToString());
            
            }

        }

        //读取-列表-已审核——台架版本
        public static void Read_ResultOf_JudgedQuest_ByBench(F1_Main F1_Main, string time, string group)
        {
            //第一个sql是把当天所有项目抓出来
            string sql = $"SELECT* FROM 台架发布 INNER JOIN 任务信息 ON 台架发布.统一编号 = 任务信息.统一编号 WHERE 发布时间 = {time} AND 数据类型 = '项目'";
            DataSet ds = MySQL_Method.SQLite_search(sql);
            //第二个sql是把当天所有人抓出来
            string sql2 = $"SELECT* FROM 台架发布 INNER JOIN 员工信息 ON 台架发布.工号 = 员工信息.工号 WHERE 发布时间 = {time} AND 数据类型 = '人员'";
            DataSet ds2 = MySQL_Method.SQLite_search(sql2);
            //第三个sql是把当天的所有工时情况抓出来
            string sql3 = $"SELECT* FROM 台架分配 INNER JOIN 员工信息 ON 台架分配.工号 = 员工信息.工号 INNER JOIN 任务信息 ON 台架分配.统一编号 = 任务信息.统一编号 WHERE 发布时间 = {time} ORDER BY 员工信息.工号";
            DataSet ds3 = MySQL_Method.SQLite_search(sql3);


            //首先用sql把统一编号和任务名写上
            //然后用sql2把安排人员写上
            //最后用sql3把完成结果

            foreach (DataRow row in ds.Tables[0].Rows) {
                string people = "";
                string result = "";

                foreach (DataRow row2 in ds2.Tables[0].Rows) {
                    people = people + "\r\n" + row2["姓名"].ToString();
                }
                people = people.Substring(2);

                foreach (DataRow row3 in ds3.Tables[0].Rows) {
                    if (row3["统一编号"].ToString() == row["统一编号"].ToString()) {
                        result = result + "\r\n" + row3["姓名"].ToString() + "-" + row3["工时系数"].ToString() + "-" + row3["工作小时"].ToString() + "h；";
                    }
                }

                if (result == "") {
                    result = "（未填报）";
                }
                else {
                    result = result.Substring(2);
                }

                F1_Main.dataGridView3.Rows.Add("(台架)" + row["统一编号"].ToString(), row["项目名"].ToString(), people, result, row["当日备注"].ToString(), row["项目状态"].ToString());

            }

        }


        //整体的大刷新，软件开始时的初始化刷新，数据库更变时的刷新
        public static void Refrash_WhenSoftStart(F1_Main F1_Main)
        {

            F1_Main.comboBox1.SelectedIndex = F1_Main.comboBox1.Items.IndexOf("TDM");//项目分类默认TDM

            MyMain_Method.Read_WorkerList(F1_Main);//读取人员信息
            MyMain_Method.Read_Quest_ByLimit(F1_Main);//读取任务信息（根据限制条件，初始当然是TDM）

            MyMain_Method.Read_DraftList(F1_Main);//读取“已起草”的日期列表
            MyMain_Method.Read_Distribute_DateList(F1_Main);//（班组功能）读取“任务分配”日期列表（分试验班和试制班和管理员）
            MyMain_Method.Read_TodayQuestList(F1_Main);//（班组功能）读取“当日任务”的日期列表（分试验班和试制班和管理员）
            MyMain_Method.Read_TodayQuestList_Bench(F1_Main);//（班组功能）读取“台架试验”列表
            MyMain_Method.Read_ListOfJudging(F1_Main);//（班组功能）读取“历史记录”中“未审核”的日期列表（分试验班和试制班和管理员）

            MyMain_Method.Search_DataExtent(F1_Main);//确定数据库记录范围，并填写到历史记录和数据分析的部分
            MyMain_Method.WriteIn_TodayYearAndMonth(F1_Main); //在历史记录的“已审核”页面预先填入今天的年、月-也把已完成任务部分一起初始化一下
            MyMain_Method.Read_JudgedList(F1_Main, F1_Main.textBox3.Text, F1_Main.textBox4.Text);//读取历史记录中“已审核”的事件列表并显示（只有管理员）
            MyMain_Method.Read_Quest_HasDone(F1_Main, F1_Main.textBox9.Text, F1_Main.textBox8.Text);//读取已经完成的任务,由于需要使用到时间参数，所以最后读取

        }

        //在审核页面点击日期后查看流程，看看是否提交完成
        public static void Look_PocessWhenJudge(F1_Main F1_Main, string group, string time)
        {
            string sql = $"SELECT* FROM 每日流程0{group} WHERE 发布时间 = {time}";
            DataSet ds = MySQL_Method.SQLite_search(sql);

            F1_Main.label43.Text = ds.Tables[0].Rows[0]["普通流程"].ToString();
            F1_Main.label42.Text = ds.Tables[0].Rows[0]["台架流程"].ToString();
            if ((F1_Main.label43.Text == "已提交" || F1_Main.label43.Text == "无") && (F1_Main.label42.Text == "已提交" || F1_Main.label42.Text == "无" || F1_Main.label42.Text == "已审核")) {
                F1_Main.button8.Enabled = true;
            }
            else {
                F1_Main.button8.Enabled = false;
            }

        }

        //直接在主界面显示分配结果
        public static void Read_Distribute_Reslt(F1_Main F1_Main, string num, string time, string group)
        {
            F1_Main.dataGridView5.Rows.Clear();
            F1_Main.dataGridView5.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            F1_Main.dataGridView5.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;

            string sql = $"SELECT* FROM 员工信息 WHERE 所属班组 = '{group}' AND 是否隐藏 = '否'";
            DataSet ds = MySQL_Method.SQLite_search(sql);//把所有人抓出来

            string sql2 = $"SELECT* FROM 台架发布 INNER JOIN 员工信息 ON 台架发布.工号 = 员工信息.工号 WHERE 发布时间 = {time} AND 数据类型 = '人员'";
            DataSet ds2 = MySQL_Method.SQLite_search(sql2);//把值班的人抓出来

            foreach (DataRow row in ds.Tables[0].Rows) {
                string quest_num = row["工号"].ToString();
                string name = row["姓名"].ToString();
                string bench = "";

                foreach (DataRow row2 in ds2.Tables[0].Rows) {
                    if (row2["工号"].ToString() == row["工号"].ToString()) {
                        bench = "●值班";
                    }
                }
                F1_Main.dataGridView5.Rows.Add(false, quest_num, name, bench);
            }

            sql = $"SELECT* FROM 任务分配0{group} WHERE 工作类型 = '（分配标记）' AND 统一编号 = '{num}' AND 发布时间 = {time}";
            DataSet ds3 = MySQL_Method.SQLite_search(sql);//把分配的情况抓出来
            foreach (DataRow row3 in ds3.Tables[0].Rows) {
                string worker_num = "";
                for (int i = 0; i < F1_Main.dataGridView5.Rows.Count; i++) {
                    worker_num = F1_Main.dataGridView5.Rows[i].Cells[1].Value.ToString();
                    if (row3["工号"].ToString() == worker_num) {
                        F1_Main.dataGridView5.Rows[i].Cells[0].Value = true;
                    }
                }
            }
        }

        //单击分配列表中的某个项目，显示任务信息和分配情况
        public static void Read_DistributeResltAnd_QuestInfo(F1_Main F1_Main, string num, string time, string group)
        {
            //事务读取开始              
            DataSet ds = new DataSet();
            DataSet ds2 = new DataSet();
            DataSet ds3 = new DataSet();
            DataSet ds4 = new DataSet();
            DataSet ds5 = new DataSet();
            SQLiteConnection connect = new SQLiteConnection(MyConstant_1.conStr);

            string sql = $"SELECT* FROM 任务信息 WHERE 统一编号 = '{num}'";
            string sql2 = $"SELECT* FROM 任务说明0{group} WHERE 发布时间 = {time} AND 统一编号 = '{num}'";
            string sql3 = $"SELECT* FROM 员工信息 WHERE 所属班组 = '{group}' AND 是否隐藏 = '否'";
            string sql4 = $"SELECT* FROM 台架发布 INNER JOIN 员工信息 ON 台架发布.工号 = 员工信息.工号 WHERE 发布时间 = {time} AND 数据类型 = '人员'";
            string sql5 = $"SELECT* FROM 任务分配0{group} WHERE 工作类型 = '（分配标记）' AND 统一编号 = '{num}' AND 发布时间 = {time}";

            connect.Open();
            DbTransaction trans = connect.BeginTransaction();

            SQLiteDataAdapter oleDapAdapter = new SQLiteDataAdapter(sql, MyConstant_1.conStr);
            oleDapAdapter.Fill(ds);
            SQLiteDataAdapter oleDapAdapter2 = new SQLiteDataAdapter(sql2, MyConstant_1.conStr);
            oleDapAdapter2.Fill(ds2);
            SQLiteDataAdapter oleDapAdapter3 = new SQLiteDataAdapter(sql3, MyConstant_1.conStr);
            oleDapAdapter3.Fill(ds3);
            SQLiteDataAdapter oleDapAdapter4 = new SQLiteDataAdapter(sql4, MyConstant_1.conStr);
            oleDapAdapter4.Fill(ds4);
            SQLiteDataAdapter oleDapAdapter5 = new SQLiteDataAdapter(sql5, MyConstant_1.conStr);
            oleDapAdapter5.Fill(ds5);

            trans.Commit();
            connect.Close();
            //事务读取结束  











            //任务数据
            F1_Main.richTextBox2.Text = "";

            //string sql = $"SELECT* FROM 任务信息 WHERE 统一编号 = '{num}'";
            //DataSet ds = MySQL_Method.SQLite_search(sql);

            string text_num = ds.Tables[0].Rows[0]["统一编号"].ToString();
            string text_name = ds.Tables[0].Rows[0]["项目名"].ToString();
            string text_numin = ds.Tables[0].Rows[0]["内部编号"].ToString();
            string text_nummake = ds.Tables[0].Rows[0]["生产订单号"].ToString();
            string text_questask = ds.Tables[0].Rows[0]["项目要求"].ToString();
            string text_timeadd = ds.Tables[0].Rows[0]["录入时间"].ToString();
            string text_whogive = ds.Tables[0].Rows[0]["编制部门"].ToString();

            string text_today_ask = "";

            //string sql2 = $"SELECT* FROM 任务说明0{group} WHERE 发布时间 = {time} AND 统一编号 = '{num}'";
            //DataSet ds2 = MySQL_Method.SQLite_search(sql2);
            try {
                text_today_ask = ds2.Tables[0].Rows[0]["当日说明"].ToString();
            }
            catch { }

            string all_text = $"统一编号：{text_num}\r\n \r\n任务名：{text_name}\r\n \r\n当日说明：\r\n{text_today_ask}\r\n \r\n内部编号：{text_numin}\r\n生产订单号：{text_nummake}\r\n任务要求：{text_questask}\r\n录入时间：{text_timeadd}\r\n下发人:{text_whogive}";

            F1_Main.richTextBox2.Text = all_text;

            F1_Main.richTextBox2.SelectionStart = text_num.Length + text_name.Length + 15;
            F1_Main.richTextBox2.SelectionLength = text_today_ask.Length + 6;
            F1_Main.richTextBox2.SelectionFont = new System.Drawing.Font("黑体", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
            F1_Main.richTextBox2.SelectionColor = System.Drawing.Color.Blue;



            //分配状况
            F1_Main.dataGridView5.Rows.Clear();
            F1_Main.dataGridView5.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            F1_Main.dataGridView5.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;

            //string sql3 = $"SELECT* FROM 员工信息 WHERE 所属班组 = '{group}' AND 是否隐藏 = '否'";
            //DataSet ds3 = MySQL_Method.SQLite_search(sql3);//把所有人抓出来

            //string sql4 = $"SELECT* FROM 台架发布 INNER JOIN 员工信息 ON 台架发布.工号 = 员工信息.工号 WHERE 发布时间 = {time} AND 数据类型 = '人员'";
            //DataSet ds4 = MySQL_Method.SQLite_search(sql4);//把值班的人抓出来

            foreach (DataRow row3 in ds3.Tables[0].Rows) {
                string quest_num = row3["工号"].ToString();
                string name = row3["姓名"].ToString();
                string bench = "";

                foreach (DataRow row4 in ds4.Tables[0].Rows) {
                    if (row4["工号"].ToString() == row3["工号"].ToString()) {
                        bench = "●值班";
                    }
                }
                F1_Main.dataGridView5.Rows.Add(false, quest_num, name, bench);
            }

            //string sql5 = $"SELECT* FROM 任务分配0{group} WHERE 工作类型 = '（分配标记）' AND 统一编号 = '{num}' AND 发布时间 = {time}";
            //DataSet ds5 = MySQL_Method.SQLite_search(sql5);//把分配的情况抓出来
            foreach (DataRow row5 in ds5.Tables[0].Rows) {
                string worker_num = "";
                for (int i = 0; i < F1_Main.dataGridView5.Rows.Count; i++) {
                    worker_num = F1_Main.dataGridView5.Rows[i].Cells[1].Value.ToString();
                    if (row5["工号"].ToString() == worker_num) {
                        F1_Main.dataGridView5.Rows[i].Cells[0].Value = true;
                    }
                }
            }


        }




        //按项目来进行每个人的工时汇报
        public static void Read_WorkTime_ForThisQuest(F1_Main F1_Main, string time, string num, string group)
        {
            F1_Main.dataGridView8.Rows.Clear();

            string sql = $"SELECT* FROM 任务分配0{group} INNER JOIN 员工信息 ON 任务分配0{group}.工号 = 员工信息.工号 WHERE 发布时间 = {time} AND 工作类型 = '（分配标记）' AND 统一编号 = '{num}'";
            DataSet ds = MySQL_Method.SQLite_search(sql);//抓出当前任务所需的所有人
            string sql2 = $"SELECT* FROM 任务分配0{group} WHERE 工作类型 = '废弃属性' AND 统一编号 = '{num}' AND 发布时间 = {time}";
            DataSet ds2 = MySQL_Method.SQLite_search(sql2);//抓出所有的任务

            foreach (DataRow row in ds.Tables[0].Rows) {

                string WorkTimeComputation = "";


                foreach (DataRow row2 in ds2.Tables[0].Rows) {
                    if (row2["工作类型"].ToString() == "废弃属性" && row2["工号"].ToString() == row["工号"].ToString()) {
                        WorkTimeComputation = WorkTimeComputation + "+" + row2["工作小时"].ToString() + "*" + row2["工时系数"].ToString();
                    }
                }
                if(WorkTimeComputation != "") {
                    WorkTimeComputation = WorkTimeComputation.Substring(1);
                }

                F1_Main.dataGridView8.Rows.Add(row["工号"].ToString(), row["姓名"].ToString(), WorkTimeComputation);
            }

        }



        //按项目来进行每个项目的工时汇报
        public static void Read_WorkTime_ForThisPeople(F1_Main F1_Main, string time, string num_worker, string group)
        {
            F1_Main.dataGridView7.Rows.Clear();

            string sql = $"SELECT* FROM 任务分配0{group} INNER JOIN 任务信息 ON 任务分配0{group}.统一编号 = 任务信息.统一编号 WHERE 发布时间 = {time} AND 工作类型 = '（分配标记）' AND 工号 = '{num_worker}'";
            DataSet ds = MySQL_Method.SQLite_search(sql);//抓出人所拥有的所有任务
            string sql2 = $"SELECT* FROM 任务分配0{group} WHERE 工作类型 = '废弃属性' AND 工号 = {num_worker} AND 发布时间 = {time}";
            DataSet ds2 = MySQL_Method.SQLite_search(sql2);//抓出所有的任务

            foreach (DataRow row in ds.Tables[0].Rows) {

                string WorkTimeComputation = "";


                foreach (DataRow row2 in ds2.Tables[0].Rows) {
                    if (row2["工作类型"].ToString() == "废弃属性" && row2["统一编号"].ToString() == row["统一编号"].ToString()) {
                        WorkTimeComputation = WorkTimeComputation + "+" + row2["工作小时"].ToString() + "*" + row2["工时系数"].ToString();
                    }
                }
                if (WorkTimeComputation != "") {
                    WorkTimeComputation = WorkTimeComputation.Substring(1);
                }

                F1_Main.dataGridView7.Rows.Add(row["统一编号"].ToString(), row["项目名"].ToString(), WorkTimeComputation);
            }

        }





    }
}


    

