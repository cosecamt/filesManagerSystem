﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace worktime
{
    public partial class F20_New_Report : Form
    {
        public F20_New_Report()
        {
            InitializeComponent();
        }

        public F20_New_Report(string time, string name, string num_quest, string group)
        {
            InitializeComponent();

            label6.Text = time;
            label7.Text = group;
            label8.Text = num_quest;
            label9.Text = name;

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void F20_New_Report_Load(object sender, EventArgs e)
        {
            dataGridView5.Columns[3].ReadOnly = false;

            string time = label6.Text;
            string group = label7.Text;
            string num_quest = label8.Text;
            //读取当日备注
            MyOtherWin_Method.WriteTodayNotes_WhenNewReport(this, time, num_quest, group);

            //读取可以填报工时的人员
            MyOtherWin_Method.SearchWorkerInThisQuest_WhenNewReport(this, time, num_quest, group);

            //读取已有的工时情况
            MyOtherWin_Method.SearchNowWorkTime_WhenNewReport(this, time, num_quest, group);







        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string time = label6.Text;
            string group = label7.Text;
            string num_quest = label8.Text;
            string name = label9.Text;
            F6_4_Change_WhenWork_Another F6_4_Change_WhenWork_Another = new F6_4_Change_WhenWork_Another(num_quest, time, name, MyConstant_1.now_group);
            F6_4_Change_WhenWork_Another.ShowDialog();

            //读取可以填报工时的人员
            MyOtherWin_Method.SearchWorkerInThisQuest_WhenNewReport(this, time, num_quest, group);

            //读取已有的工时情况
            MyOtherWin_Method.SearchNowWorkTime_WhenNewReport(this, time, num_quest, group);

        }

        private void listView8_MouseClick(object sender, MouseEventArgs e)
        {
            string num_worker = listView8.FocusedItem.Text;
            string name_worker = listView8.FocusedItem.SubItems[1].Text;

            dataGridView5.Rows.Add(num_worker, name_worker, MyConstant_1.DefaultWorkRadio, "");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //dataGridView1.CurrentRow.Cells[0].Value.ToString();
            if (dataGridView5.CurrentRow != null) {
                dataGridView5.Rows.Remove(dataGridView5.CurrentRow);
            }
        }

        private void dataGridView5_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {


        }

        private void button2_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < listView8.Items.Count; i++) {
                string num_worker = listView8.Items[i].SubItems[0].Text;
                string name_worker = listView8.Items[i].SubItems[1].Text;
                dataGridView5.Rows.Add(num_worker, name_worker, MyConstant_1.DefaultWorkRadio, "");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //保证有至少2行
            if (dataGridView5.Rows.Count <= 1) {
                return;
            }

            /*
            for (int i = 0; i < dataGridView5.Rows.Count; i++) {
                if (dataGridView5.Rows[i].Cells[0].Value.ToString() == "True") {
                    string worker_num = dataGridView5.Rows[i].Cells[1].Value.ToString();
                    MyOtherWin_Method.Add_NewDistributePlan(time, num, worker_num, group);
                }
            }
            */

            string Hours = dataGridView5.Rows[0].Cells[3].Value.ToString();
            string Radio = dataGridView5.Rows[0].Cells[2].Value.ToString();

            for (int i = 1; i < dataGridView5.Rows.Count; i++) {
                dataGridView5.Rows[i].Cells[3].Value = Hours;
                dataGridView5.Rows[i].Cells[2].Value = Radio;
            }


        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            string time = label6.Text;
            string group = label7.Text;
            string num_quest = label8.Text;

            //还是应该先检查一下所有的小时信息，以免删除
            for (int i = 0; i < dataGridView5.Rows.Count; i++) {
                if (dataGridView5.Rows[i].Cells[3].Value.ToString() == "" || MyRegular_Method.HoursString(dataGridView5.Rows[i].Cells[3].Value.ToString()) == false) {
                    MessageBox.Show($"第{i+1}行的小时数填写不规范");
                    return;
                    }
                }

                //先删除所有的的
                MyOtherWin_Method.DeleteAllInfoInThisQuest_WhenNewReport(this, time, num_quest, group);


            //如果没有就删除
            if (dataGridView5.Rows.Count == 0) {
                this.Close();
            }


            //循环增加新的工时信息
            for (int i = 0; i < dataGridView5.Rows.Count; i++) {
                string Hours = dataGridView5.Rows[i].Cells[3].Value.ToString();
                string Radio = dataGridView5.Rows[i].Cells[2].Value.ToString();
                string num_worker = dataGridView5.Rows[i].Cells[0].Value.ToString();

                string sql = $"insert into [任务分配0{group}](发布时间,统一编号,工号,工作类型,工时系数,工作小时)values({time},'{num_quest}',{num_worker} ,'废弃属性',{Radio},{Hours})";
                MySQL_Method.SQLite_add(sql);
            }

            //备注写进来
            string TodayNote = textBox8.Text;
            string sql2 = $"UPDATE 任务发布0{group} SET 当日备注 = '{TodayNote}' WHERE 发布时间 = {time} AND 统一编号 = '{num_quest}' ";
            MySQL_Method.SQLite_update(sql2);

            this.Close();
        }

        private void dataGridView5_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 0 || e.ColumnIndex == 1) {
                dataGridView5.Rows.Remove(dataGridView5.CurrentRow);
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            textBox8.Text = "";
            textBox8.Text = "已完成";
        }

        private void button8_Click(object sender, EventArgs e)
        {
            textBox8.Text = "";
            textBox8.Text = "未完成";
        }
    }
    }

        

