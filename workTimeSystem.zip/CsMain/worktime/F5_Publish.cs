﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace worktime
{
    public partial class F5_Publish : Form
    {
        public F5_Publish()
        {
            InitializeComponent();
        }
        public F5_Publish(string group_style, string Publish_Time)
        {
            InitializeComponent();
            label8.Text = group_style;
            label9.Text = Publish_Time;
            //在这里写函数一定要注意，有两个时间很容易弄混
            //一个是所选发布日期的时间，我建议用变量名：publish_time
            //一个是历史列表中的时间，我建议用变量名：history_time
            //千万不要弄混了！！！！！！



        }



        private void F5_Publish_Load(object sender, EventArgs e)
        {


            /*
            //先把今天的时间填上
            string time_now = DateTime.Now.ToString("yyyyMMdd");
            textBox1.Text = time_now;
            */


            comboBox1.SelectedIndex = comboBox1.Items.IndexOf("TDM");//默认TDM
            MyOtherWin_Method.Read_Quest_WhenPublish(this);//把所有未完成的任务按要求都列出来
            MyOtherWin_Method.Search_NearFiveDays(this, label9.Text, label8.Text);//把最近5天的历史记录填进去
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            MyOtherWin_Method.Read_Quest_WhenPublish(this);//把所有未完成的任务按要求都列出来
            MyTools_Method.Find_HasChoose_ToRed(this);
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            if (textBox5.Text != "") {
                MyConstant_1.Swicth_SearchBox_NotUse = 1;
            }

            if (MyConstant_1.Swicth_SearchBox_NotUse == 0) {
                return;
            }

            MyOtherWin_Method.Read_Quest_WhenPublish(this);//把所有未完成的任务按要求都列出来
            MyTools_Method.Find_HasChoose_ToRed(this);
        }

        private void button14_Click(object sender, EventArgs e)
        {
            MyConstant_1.Swicth_SearchBox_NotUse = 1;
            textBox5.Text = "1";
            textBox5.Text = "";
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox2.Text != "") {
                string time = comboBox2.Text;
                MyOtherWin_Method.Search_HistoryQuest(this, time, label8.Text);
                MyTools_Method.Find_HasChoose_ToRed(this);
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            //干脆抄到右边去
            string num = listView1.FocusedItem.SubItems[0].Text;
            string name = listView1.FocusedItem.SubItems[1].Text;
            //string type = listView1.FocusedItem.SubItems[2].Text;

            //已被标红则不能进行
            if (listView1.FocusedItem.SubItems[0].ForeColor == Color.Red) {
                MessageBox.Show("该任务已经被选择了！");
            }
            else {
                //先抄写，当日说明另说
                ListViewItem first = new ListViewItem(num);
                first.SubItems.Add(name);
                //first.SubItems.Add(type);

                //来读取当日说明

                string sql = $"SELECT* FROM 任务说明0{label8.Text} WHERE 发布时间 = {label9.Text} AND 统一编号 = '{num}'";
                DataSet ds = MySQL_Method.SQLite_search(sql);
                if (ds.Tables[0].Rows.Count >= 1) {
                    first.SubItems.Add(ds.Tables[0].Rows[0]["当日说明"].ToString());
                }
                else {
                    //如果没有要查找最近的带进来
                    string sql3 = $"SELECT* FROM 任务说明0{label8.Text} WHERE 发布时间 < {label9.Text} AND 统一编号 = '{num}' AND 当日说明 <> '' ORDER BY 发布时间 DESC";
                    DataSet ds3 = MySQL_Method.SQLite_search(sql3);
                    if (ds3.Tables[0].Rows.Count >= 1) {
                        first.SubItems.Add(ds3.Tables[0].Rows[0]["当日说明"].ToString());
                        string sql4 = $"insert into [任务说明0{label8.Text}](发布时间,统一编号,当日说明)values({label9.Text},'{num}','{ds3.Tables[0].Rows[0]["当日说明"].ToString()}')";
                        MySQL_Method.SQLite_update(sql4);
                    }
                    else {
                        first.SubItems.Add("");
                    }
                }

                //录完了，绘制
                listView2.Items.Add(first);
                MyTools_Method.Find_HasChoose_ToRed(this);

            }

            MyConstant_1.Swicth_SearchBox_NotUse = 0;
            textBox5.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (listView2.FocusedItem != null) {
                listView2.Items.Remove(listView2.SelectedItems[0]);
                MyTools_Method.Find_HasChoose_ToRed(this);
            }

        }

        private void listView2_MouseClick(object sender, MouseEventArgs e)
        {
            try {
                string publish_time = label9.Text;
                string num = listView2.FocusedItem.Text;
                MyOtherWin_Method.Show_QuestInfo_AndNearAsk(this, publish_time, num, label8.Text);
                MyOtherWin_Method.Read_TodayAsk(this, publish_time, num, label8.Text);

            }
            catch { }
        }

        private void button5_Click(object sender, EventArgs e)
        {

            if (listView2.FocusedItem != null) {
                string publish_time = label9.Text;
                string num = listView2.FocusedItem.Text;
                string ask = textBox2.Text;
                string sql = $"SELECT* FROM 任务说明0{label8.Text} WHERE 发布时间 = {publish_time} AND 统一编号 = '{num}'";
                DataSet ds = MySQL_Method.SQLite_search(sql);
                if (ds.Tables[0].Rows.Count != 0) {
                    MyOtherWin_Method.Change_TodayAsk(publish_time, num, ask, label8.Text);
                    listView2.FocusedItem.SubItems[2].Text = ask;
                }
                else {
                    MyOtherWin_Method.Add_TodayAsk(publish_time, num, ask, label8.Text);
                    listView2.FocusedItem.SubItems[2].Text = ask;
                }
            }
            else {
                MessageBox.Show("请先选择一项");
            }








        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (listView2.Items.Count >= 1) {

                if (MessageBox.Show($"确定要发布{label9.Text}的工作么？", "Confirm Message", MessageBoxButtons.OKCancel) == DialogResult.OK) {
                    //先录入“每日流程”，保证不会重复排班，时间相同触发key值相同而跳出
                    try {

                        //MyOtherWin_Method.Add_DailyProcess(label9.Text, label8.Text);
                        //不需要改变流程了，依然是“已起草”

                        //再录入任务发布
                        //应该先删后加
                        MyOtherWin_Method.DeleteQuest_BeforeAdd_Publish(label9.Text, label8.Text);
                        for (int i = 0; i < listView2.Items.Count; i++) {
                            string num = listView2.Items[i].SubItems[0].Text;
                            string name = listView2.Items[i].SubItems[1].Text;
                            MyOtherWin_Method.Add_Publish(label9.Text, num, name, label8.Text);
                        }

                        this.Close();
                    }
                    catch {
                        MessageBox.Show("在当日已经提交过了");
                    }
                }
            }

            else {
                MessageBox.Show("请至少选择一项任务");
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            //MyOtherWin_Method.Search_NearFiveDays(this, textBox1.Text, label8.Text);//把最近5天的历史记录填进去
        }

        private void label8_MouseClick(object sender, MouseEventArgs e)
        {

        }

        private void listView1_MouseClick(object sender, MouseEventArgs e)
        {
            string time = label9.Text;
            string num = listView1.FocusedItem.Text;
            MyOtherWin_Method.Show_QuestInfo_AndNearAsk(this, time, num, label8.Text);
        }

        private void listView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            //干脆抄到右边去
            string num = listView1.FocusedItem.SubItems[0].Text;
            string name = listView1.FocusedItem.SubItems[1].Text;
            //string type = listView1.FocusedItem.SubItems[2].Text;

            //已被标红则不能进行
            if (listView1.FocusedItem.SubItems[0].ForeColor == Color.Red) {
                MessageBox.Show("该任务已经被选择了！");
            }
            else {
                //先抄写，当日说明另说
                ListViewItem first = new ListViewItem(num);
                first.SubItems.Add(name);
                //first.SubItems.Add(type);

                //来读取当日说明

                string sql = $"SELECT* FROM 任务说明0{label8.Text} WHERE 发布时间 = {label9.Text} AND 统一编号 = '{num}'";
                DataSet ds = MySQL_Method.SQLite_search(sql);
                if (ds.Tables[0].Rows.Count >= 1) {
                    first.SubItems.Add(ds.Tables[0].Rows[0]["当日说明"].ToString());
                }
                else {
                    //如果没有要查找最近的带进来
                    string sql3 = $"SELECT* FROM 任务说明0{label8.Text} WHERE 发布时间 < {label9.Text} AND 统一编号 = '{num}' AND 当日说明 <> '' ORDER BY 发布时间 DESC";
                    DataSet ds3 = MySQL_Method.SQLite_search(sql3);
                    if (ds3.Tables[0].Rows.Count >= 1) {
                        first.SubItems.Add(ds3.Tables[0].Rows[0]["当日说明"].ToString());
                        string sql4 = $"insert into [任务说明0{label8.Text}](发布时间,统一编号,当日说明)values({label9.Text},'{num}','{ds3.Tables[0].Rows[0]["当日说明"].ToString()}')";
                        MySQL_Method.SQLite_update(sql4);
                    }
                    else {
                        first.SubItems.Add("");
                    }
                }

                //录完了，绘制
                listView2.Items.Add(first);
                MyTools_Method.Find_HasChoose_ToRed(this);

            }

            MyConstant_1.Swicth_SearchBox_NotUse = 0;
            textBox5.Text = "";


        }

        private void listView2_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (listView2.FocusedItem != null) {
                listView2.Items.Remove(listView2.SelectedItems[0]);
                MyTools_Method.Find_HasChoose_ToRed(this);
            }
        }

        private void F5_Publish_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void F5_Publish_Activated(object sender, EventArgs e)
        {
            // 动点真格的
            HotKey.RegisterHotKey(Handle, 100, HotKey.KeyModifiers.Ctrl, Keys.D);
        }

        private void F5_Publish_Leave(object sender, EventArgs e)
        {
            HotKey.UnregisterHotKey(Handle, 100);
        }

        protected override void WndProc(ref Message m)
        {
            const int WM_HOTKEY = 0x0312;
            // 按快捷键
            switch (m.Msg) {
                case WM_HOTKEY:
                    switch (m.WParam.ToInt32()) {

                        case 100:    // 按下的是Ctrl+D
                            IDataObject data = Clipboard.GetDataObject();
                            if (data.GetDataPresent(DataFormats.Text)) {
                                string keywords = (string)data.GetData(DataFormats.Text);
                                keywords = keywords.Trim();

                                string sql = $"SELECT* FROM 任务信息 WHERE 项目状态 = '未完成' AND 项目分类 = '{comboBox1.Text}' AND ( 项目名 LIKE '%{keywords}%' OR 统一编号 LIKE '%{keywords}%' ) AND 是否隐藏 = '否'";
                                DataSet ds = MySQL_Method.SQLite_search(sql);
                                label10.Text = keywords;
                                if (ds.Tables[0].Rows.Count == 1) {
                                    string num = ds.Tables[0].Rows[0]["统一编号"].ToString();
                                    string name = ds.Tables[0].Rows[0]["项目名"].ToString();
                                    F18_Auto_PUB F18_Auto_PUB = new F18_Auto_PUB(num, name);
                                    F18_Auto_PUB.ShowDialog();
                                    if (MyConstant_1.Auto_Publish_OK == "确定") {
                                        //先抄写，当日说明另说
                                        ListViewItem first = new ListViewItem(num);
                                        first.SubItems.Add(name);
                                        //first.SubItems.Add(type);

                                        //来读取当日说明

                                        string sql2 = $"SELECT* FROM 任务说明0{label8.Text} WHERE 发布时间 = {label9.Text} AND 统一编号 = '{num}'";
                                        DataSet ds2 = MySQL_Method.SQLite_search(sql2);
                                        if (ds2.Tables[0].Rows.Count >= 1) {
                                            first.SubItems.Add(ds.Tables[0].Rows[0]["当日说明"].ToString());
                                        }
                                        else {
                                            first.SubItems.Add("（无）");
                                        }

                                        //录完了，绘制
                                        listView2.Items.Add(first);
                                        MyTools_Method.Find_HasChoose_ToRed(this);
                                    }
                                }
                                }
                                break;


                            }
                            break;
                    }
                    base.WndProc(ref m);
            }

        private void button6_Click(object sender, EventArgs e)
        {
            F4_Add_Quest F4_Add_Quest = new F4_Add_Quest();
            F4_Add_Quest.ShowDialog();
            MyOtherWin_Method.Read_Quest_WhenPublish(this);//把所有未完成的任务按要求都列出来
            MyTools_Method.Find_HasChoose_ToRed(this);

        }
    }
    }


    

