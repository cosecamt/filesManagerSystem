﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace worktime
{
    public partial class F16_password : Form
    {
        public F16_password()
        {
            InitializeComponent();
        }
        public F16_password(string group)
        {
            InitializeComponent();
            label3.Text = group;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void F16_password_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "2") {
                F14_AddPlanQuest F14_AddPlanQuest = new F14_AddPlanQuest(MyConstant_1.now_group);
                F14_AddPlanQuest.ShowDialog();
                this.Close();
            }
            else {
                MessageBox.Show("密码错误");
            }
        }
    }
}
