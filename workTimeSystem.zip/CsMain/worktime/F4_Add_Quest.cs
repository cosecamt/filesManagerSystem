﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace worktime
{
    public partial class F4_Add_Quest : Form
    {
        public F4_Add_Quest()
        {
            InitializeComponent();
        }

        private void F4_Add_Quest_Load(object sender, EventArgs e)
        {
            //读取今日的时间
            textBox7.Text = DateTime.Now.ToString("yyyyMMdd");
            comboBox1.SelectedIndex = comboBox1.Items.IndexOf("TDM");//默认TDM
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //把所有需要的数据先取出来
            string num_in = textBox1.Text;
            string num_order = textBox2.Text;
            string num_unify = textBox3.Text;
            string part = textBox4.Text;
            string name = textBox5.Text;
            string ask = textBox6.Text;
            string time = textBox7.Text;
            string type = comboBox1.Text;

            //加一个难度
            string difficult = textBox9.Text;

            //正则来测试时间

            if (MyRegular_Method.Eight_Number(time) == true && num_unify != "") {
                if (MyOtherWin_Method.Judge_Whether_HidedQuest(num_unify) == true) {
                    if (MessageBox.Show("查找到该任务编号曾被删除，是否恢复该任务相关信息\r\n由于工号具有唯一性，建议恢复，若工号错误可以重新删除；若名称改变可以双击修改。", "Confirm Message", MessageBoxButtons.OKCancel) == DialogResult.OK) {
                        MyOtherWin_Method.Recovery_HidedQuest(num_unify);//恢复隐藏任务
                        this.Close();
                    }
                }
                else {
                    try {
                        MyOtherWin_Method.Add_NewQuest(num_in, num_order, num_unify, part, name, ask, time, type, difficult);
                        this.Close();
                    }
                    catch {
                        MessageBox.Show("统一编号重复");
                    }
                }
            }
            else {
                MessageBox.Show("日期不符合格式，请输入8位数字 \r\n也有可能是统一编号为空");
            }
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            string num_in, num_order, num_unify, part, name, ask ,Quest_Kind = "";



            try {
            MyOtherWin_Method.Auto_WriteIn(textBox8.Text, out num_in, out num_order, out num_unify, out part, out name, out ask, out Quest_Kind);
            textBox1.Text = num_in;
            textBox2.Text = num_order;
            textBox3.Text = num_unify;
            textBox4.Text = part;
            textBox5.Text = name;
            textBox6.Text = ask;
            if(Quest_Kind.Contains("台架试验")) {
                    comboBox1.SelectedIndex = comboBox1.Items.IndexOf("台架试验");
                }
            else {
                    //comboBox1.SelectedIndex = comboBox1.Items.IndexOf("TDM");
                }
            }
            catch {
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";
                textBox6.Text = "";
            }
            


        }

        private void button4_Click(object sender, EventArgs e)
        {
            //默认为:SY-LS-1
            comboBox1.SelectedIndex = comboBox1.Items.IndexOf("其他");
            string keyword = "试验-其他-";
            string sql = $"SELECT * FROM 任务信息 WHERE 统一编号 LIKE '%{keyword}%'";
            DataSet ds = MySQL_Method.SQLite_search(sql);
            int Number_OfQuest = ds.Tables[0].Rows.Count + 1;

            textBox3.Text = keyword + Number_OfQuest.ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            //默认为:SZ-LS-1
            comboBox1.SelectedIndex = comboBox1.Items.IndexOf("其他");
            string keyword = "试制-其他-";
            string sql = $"SELECT * FROM 任务信息 WHERE 统一编号 LIKE '%{keyword}%'";
            DataSet ds = MySQL_Method.SQLite_search(sql);
            int Number_OfQuest = ds.Tables[0].Rows.Count + 1;

            textBox3.Text = keyword + Number_OfQuest.ToString();
        }
    }
}
