﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace worktime
{
    public partial class F16_password_whendelete : Form
    {
        public F16_password_whendelete()
        {
            InitializeComponent();
        }

        public F16_password_whendelete(string time)
        {
            InitializeComponent();
            label3.Text = time;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string time = label3.Text;

            if (textBox1.Text == "yes") {
                //全都删掉
                List<string> DataTableName = new List<string>();
                DataTableName.Add("每日流程0试验班");
                DataTableName.Add("每日流程0试制班");
                DataTableName.Add("台架说明");
                DataTableName.Add("台架分配");
                DataTableName.Add("台架发布");
                DataTableName.Add("任务说明0试验班");
                DataTableName.Add("任务说明0试制班");
                DataTableName.Add("任务发布0试验班");
                DataTableName.Add("任务发布0试制班");
                DataTableName.Add("任务分配0试验班");
                DataTableName.Add("任务分配0试制班");

                foreach (string NowTable in DataTableName) {
                    string sql = $"DELETE FROM {NowTable} WHERE 发布时间 = '{time}'";
                    MySQL_Method.SQLite_delete(sql);
                    this.Close();
                }

            }
            else {
                MessageBox.Show("验证码不对,关闭");
                this.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void F16_password_whendelete_Load(object sender, EventArgs e)
        {

        }
    }
}
