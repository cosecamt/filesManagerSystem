﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace worktime
{
    public partial class F8_holiday : Form
    {
        public F8_holiday()
        {
            InitializeComponent();
        }

        public F8_holiday(string time)
        {
            InitializeComponent();
            time = MyTools_Method.Num_ToDate(Convert.ToInt32(time));
            label2.Text = time;
        }

        private void F8_holiday_Load(object sender, EventArgs e)
        {
            MyOtherWin_Method.Read_AskForLeave_History(label2.Text, this);

            if (MyConstant_1.now_group == "管理员") {
                string sql = $"SELECT* FROM 员工信息";
                DataSet ds = MySQL_Method.SQLite_search(sql);
                foreach (DataRow row in ds.Tables[0].Rows) {
                    comboBox1.Items.Add(row["姓名"].ToString() + "-" + row["工号"].ToString());
                }
            }
            else {
                string sql = $"SELECT* FROM 员工信息 WHERE 所属班组 = '{MyConstant_1.now_group}'";
                DataSet ds = MySQL_Method.SQLite_search(sql);
                foreach (DataRow row in ds.Tables[0].Rows) {
                    comboBox1.Items.Add(row["姓名"].ToString() + "-" + row["工号"].ToString());
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] worker_num_and_name = comboBox1.Text.Split('-');
            string worker_num = worker_num_and_name[1];

            int j = 0;
            for (int i = 0; i < listView1.Items.Count; i++) {
                if (listView1.Items[i].SubItems[0].Text == worker_num) {
                    j = 1;
                }
            }

            if (j == 1) {
                MyOtherWin_Method.Change_AskForLeave(label2.Text, worker_num, textBox1.Text);
                MyOtherWin_Method.Read_AskForLeave_History(label2.Text, this);
            }
            else if (j == 0) {
                MyOtherWin_Method.Add_AskForLeave(label2.Text, worker_num, textBox1.Text);
                MyOtherWin_Method.Read_AskForLeave_History(label2.Text, this);
            }
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void listView1_MouseClick(object sender, MouseEventArgs e)
        {
            string num = listView1.FocusedItem.Text;

            string sql = $"SELECT* FROM 任务分配0{MyConstant_1.now_group} INNER JOIN 员工信息 ON 任务分配0{MyConstant_1.now_group}.工号 = 员工信息.工号 WHERE 任务分配0{MyConstant_1.now_group}.工号 = {num} AND 工作类型 = '（请假）'";
            DataSet ds = MySQL_Method.SQLite_search(sql);

            string choose_name = ds.Tables[0].Rows[0]["姓名"].ToString() + "-" + ds.Tables[0].Rows[0]["工号"].ToString();
            string choose_hours = ds.Tables[0].Rows[0]["工作小时"].ToString();

            comboBox1.SelectedIndex = comboBox1.Items.IndexOf(choose_name);
            textBox1.Text = choose_hours;
        }
    }
}
