﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace worktime
{
    public partial class F19_3_Change_Power : Form
    {
        public F19_3_Change_Power()
        {
            InitializeComponent();
        }

        public F19_3_Change_Power(string user)
        {
            InitializeComponent();
            label4.Text = user;
        }

        private void F19_3_Change_Power_Load(object sender, EventArgs e)
        {
            string sql = $"SELECT* FROM 权限 WHERE 账号 = '{label4.Text}'" ;
            DataSet ds = MySQL_Method.SQLite_search(sql);

            foreach (DataRow row in ds.Tables[0].Rows) {
                textBox2.Text = row["密码"].ToString();
                comboBox1.SelectedIndex = comboBox1.Items.IndexOf(row["用户类型"].ToString());
            }

        }
    

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string user = label4.Text;
            string password = textBox2.Text;
            string power_kind = comboBox1.Text;
            string sql = $"UPDATE 权限 SET 密码 = '{password}', 用户类型 = '{power_kind}' WHERE 账号 = '{user}'";
            MySQL_Method.SQLite_update(sql);

            this.Close();
        }
    }
}
