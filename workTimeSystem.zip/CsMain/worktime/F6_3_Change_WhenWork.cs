﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace worktime
{
    public partial class F6_3_Change_WhenWork : Form
    {
        public F6_3_Change_WhenWork()
        {
            InitializeComponent();
        }

        public F6_3_Change_WhenWork(string time, string num, string group)
        {
            InitializeComponent();
            label6.Text = time;
            label7.Text = num;
            label8.Text = group;
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void F6_3_Change_WhenWork_Load(object sender, EventArgs e)
        {
            string time = label6.Text;
            string num = label7.Text;
            string group = label8.Text;


            string sql = $"SELECT* FROM 员工信息 WHERE 所属班组 = '{group}'";
            DataSet ds = MySQL_Method.SQLite_search(sql);
            string sql2 = $"SELECT* FROM 任务分配0{group} INNER JOIN 员工信息 ON 任务分配0{group}.工号 = 员工信息.工号 WHERE 统一编号 = '{num}' AND 发布时间 = {time} AND 工作类型 = '（分配标记）'";
            DataSet ds2 = MySQL_Method.SQLite_search(sql2);

            foreach (DataRow row in ds2.Tables[0].Rows) {
                comboBox2.Items.Add(row["姓名"].ToString() + "-" + row["工号"].ToString());
            }

            foreach (DataRow row in ds.Tables[0].Rows) {
                int t = 0;
                foreach (DataRow row2 in ds2.Tables[0].Rows) {
                    if (row2["工号"].ToString() == row["工号"].ToString()) {
                        t = 1;
                    }
                }
                if (t == 0) {
                    comboBox1.Items.Add(row["姓名"].ToString() + "-" + row["工号"].ToString());
                }

            }


        }

        private void button1_Click(object sender, EventArgs e)
        {
            string time = label6.Text;
            string num = label7.Text;
            string group = label8.Text;
            string worker_num = "";

            if (comboBox1.Text != "") {
                string worker = comboBox1.Text;
                worker_num = worker.Split('-')[1];
                string sql = $"insert into [任务分配0{group}](发布时间,统一编号,工号,工作类型,工时系数,工作小时)values({time},'{num}',{worker_num},'（分配标记）',0,0)";
                MySQL_Method.SQLite_add(sql);
                this.Close();
            }
            else {
                MessageBox.Show("请先选择一个人员");
            }




        }

        private void button2_Click(object sender, EventArgs e)
        {
            string time = label6.Text;
            string num = label7.Text;
            string group = label8.Text;
            string worker_num = "";

            if (comboBox2.Text != "") {
                string worker = comboBox2.Text;
                worker_num = worker.Split('-')[1];
                string sql = $"DELETE FROM 任务分配0{group} WHERE 统一编号 = '{num}' AND 发布时间 = {time} AND 工号 = {worker_num}";
                MySQL_Method.SQLite_delete(sql);
                this.Close();
            }
            else {
                MessageBox.Show("请先选择一个人员");
            }
        }
    }
}