﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace worktime
{
    public partial class F13_NewDaily : Form
    {
        public F13_NewDaily()
        {
            InitializeComponent();
        }

        private void F13_NewDaily_Load(object sender, EventArgs e)
        {
            //先把今天的时间填上
            string time_today = DateTime.Now.ToString("yyyyMMdd");
            textBox1.Text = time_today;


        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string time_today = textBox1.Text;
            string todayweek = "日期不符合8位格式";
            if (MyRegular_Method.Eight_Number(time_today) == true) {
                time_today = time_today.Substring(0, 4) + "-" + time_today.Substring(4, 2) + "-" + time_today.Substring(6, 2);
                try {
                    //有可能比如一个月没有第32天之类的，就会报错
                    string dayofweek = (DateTime.Parse(time_today).DayOfWeek).ToString();

                    switch (dayofweek) {
                        case "Monday":
                            todayweek = "本日为星期一";
                            break;
                        case "Tuesday":
                            todayweek = "本日为星期二";
                            break;
                        case "Wednesday":
                            todayweek = "本日为星期三";
                            break;
                        case "Thursday":
                            todayweek = "本日为星期四";
                            break;
                        case "Friday":
                            todayweek = "本日为星期五";
                            break;
                        case "Saturday":
                            todayweek = "本日为星期六，大概率是节假日";
                            break;
                        case "Sunday":
                            todayweek = "本日为星期日，大概率是节假日";
                            break;
                    }
                }
                catch { }
            }            
            label2.Text = todayweek;
            if (label2.Text == "本日为星期六，大概率是节假日" || label2.Text == "本日为星期日，大概率是节假日") {
                label2.ForeColor = Color.Red;
            }else {
                label2.ForeColor = Color.Black;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string time = textBox1.Text;
            string holiday_whether = "否";

            if (checkBox1.Checked == true) {
                holiday_whether = "是";
            }

            if (MyRegular_Method.Eight_Number(time) == true) {
                try {
                    string sql = $"INSERT INTO 每日流程0试验班 (发布时间,普通流程,台架流程,是否假期) VALUES ({time},'已起草','已起草','{holiday_whether}') ";
                    MySQL_Method.SQLite_add(sql);
                    sql = $"INSERT INTO 每日流程0试制班 (发布时间,普通流程,台架流程,是否假期) VALUES ({time},'已起草','已起草','{holiday_whether}') ";
                    MySQL_Method.SQLite_add(sql);
                    this.Close();
                }
                catch { MessageBox.Show("重复了日期"); }
            }
            else {
                MessageBox.Show("日期不符合格式，请输入8位数字");
            }

            


        }
    }
}
