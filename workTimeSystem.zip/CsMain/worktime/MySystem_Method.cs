﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace worktime
{
    class MySystem_Method
    {
        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        static extern int PostMessage(IntPtr hwnd, int msg, uint wParam, uint lParam);

        //让窗口关闭的方法
        [DllImport("user32.dll", EntryPoint = "SendMessage")]
        private static extern int SendMessage(IntPtr hwnd, int wMsg, int wParam, int lParam);


        //找窗口句柄的方法
        [DllImport("User32.dll", EntryPoint = "FindWindow")]

        private extern static IntPtr FindWindow(string lpClassName, string lpWindowName);

        public static void Find_File(string text)
        {
            IntPtr ParenthWnd = new IntPtr(0);

            ParenthWnd = FindWindow(null, $@"{text}");
            //判断这个窗体是否有效 
            if (ParenthWnd != IntPtr.Zero) {
                MessageBox.Show("找到窗口");
                SendMessage(ParenthWnd, 0x10, 0,0);
            }

            else

                MessageBox.Show("没有找到窗口");
        }
    }
}
