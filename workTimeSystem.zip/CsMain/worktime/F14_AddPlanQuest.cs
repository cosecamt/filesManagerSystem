﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace worktime
{
    public partial class F14_AddPlanQuest : Form
    {
        public F14_AddPlanQuest()
        {
            InitializeComponent();
        }
        public F14_AddPlanQuest(string group)
        {
            InitializeComponent();
            label8.Text = group;
        }


        private void F14_AddPlanQuest_Load(object sender, EventArgs e)
        {
            comboBox1.SelectedIndex = comboBox1.Items.IndexOf("TDM");//默认TDM

            //把处于 已分配 和 已发布 的日期找出来填进框里
            MyOtherWin_Method.WriteIn_CanAddQuestDay(this, label8.Text);

            //先把当天的任务统一编号查出来，在刚开始肯定是get到空的时间，要做个判断
            //然后在度所有任务，在之前给个判断，重复的标红
            MyOtherWin_Method.Search_Quest_WhenAddQuest(this, label8.Text, comboBox2.Text);
            //现在再加一个，与右边相同的标红
            MyTools_Method.Find_HasChoose_ToRed_WhenAdd(this);



        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            MyOtherWin_Method.Search_Quest_WhenAddQuest(this, label8.Text, comboBox2.Text);
            MyTools_Method.Find_HasChoose_ToRed_WhenAdd(this);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            MyOtherWin_Method.Search_Quest_WhenAddQuest(this, label8.Text, comboBox2.Text);
            MyTools_Method.Find_HasChoose_ToRed_WhenAdd(this);
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            MyOtherWin_Method.Search_Quest_WhenAddQuest(this, label8.Text, comboBox2.Text);
            MyTools_Method.Find_HasChoose_ToRed_WhenAdd(this);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (listView2.Items.Count >= 1) {
                for (int i = 0; i < listView2.Items.Count; i++) {
                    string num = listView2.Items[i].SubItems[0].Text;
                    MyOtherWin_Method.Add_Publish_WhenAddQuest(comboBox2.Text, num, label8.Text);
                }

            }

            string sql = $"SELECT* FROM 每日流程0{label8.Text} WHERE (普通流程 = '已发布' OR 普通流程 = '已分配' OR 普通流程 = '无') AND 发布时间 = {comboBox2.Text} ";
            DataSet ds = MySQL_Method.SQLite_search(sql);
            if (ds.Tables[0].Rows[0]["普通流程"].ToString() == "无") {
                sql = $"UPDATE 每日流程0{label8.Text} SET 普通流程 = '已发布' WHERE 发布时间 = {comboBox2.Text}";
                MySQL_Method.SQLite_update(sql);
            }





            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //干脆抄到右边去
            string num = listView1.FocusedItem.SubItems[0].Text;
            string name = listView1.FocusedItem.SubItems[1].Text;
            string type = listView1.FocusedItem.SubItems[2].Text;

            //已被标红则不能进行
            if (listView1.FocusedItem.SubItems[0].ForeColor == Color.Red) {
                MessageBox.Show("该任务已经被选择了！");
            }
            else {
                //先抄写，当日说明另说
                ListViewItem first = new ListViewItem(num);
                first.SubItems.Add(name);
                first.SubItems.Add(type);

                //来读取当日说明

                string sql = $"SELECT* FROM 任务说明0{label8.Text} WHERE 发布时间 = {comboBox2.Text} AND 统一编号 = '{num}'";
                DataSet ds = MySQL_Method.SQLite_search(sql);
                if (ds.Tables[0].Rows.Count >= 1) {
                    first.SubItems.Add(ds.Tables[0].Rows[0]["当日说明"].ToString());
                }
                else {
                    //如果没有要查找最近的带进来
                    string sql3 = $"SELECT* FROM 任务说明0{label8.Text} WHERE 发布时间 < {comboBox2.Text} AND 统一编号 = '{num}' AND 当日说明 <> '' ORDER BY 发布时间 DESC";
                    DataSet ds3 = MySQL_Method.SQLite_search(sql3);
                    if (ds3.Tables[0].Rows.Count >= 1) {
                        first.SubItems.Add(ds3.Tables[0].Rows[0]["当日说明"].ToString());
                        string sql4 = $"insert into [任务说明0{label8.Text}](发布时间,统一编号,当日说明)values({comboBox2.Text},'{num}','{ds3.Tables[0].Rows[0]["当日说明"].ToString()}')";
                        MySQL_Method.SQLite_update(sql4);
                    }
                    else {
                        first.SubItems.Add("");
                    }
                }

                //录完了，绘制
                listView2.Items.Add(first);
                MyOtherWin_Method.Search_Quest_WhenAddQuest(this, label8.Text, comboBox2.Text);
                MyTools_Method.Find_HasChoose_ToRed_WhenAdd(this);

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            listView2.Items.Remove(listView2.SelectedItems[0]);
            MyOtherWin_Method.Search_Quest_WhenAddQuest(this, label8.Text, comboBox2.Text);
            MyTools_Method.Find_HasChoose_ToRed_WhenAdd(this);
        }

        private void listView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            //干脆抄到右边去
            string num = listView1.FocusedItem.SubItems[0].Text;
            string name = listView1.FocusedItem.SubItems[1].Text;
            string type = listView1.FocusedItem.SubItems[2].Text;

            //已被标红则不能进行
            if (listView1.FocusedItem.SubItems[0].ForeColor == Color.Red) {
                MessageBox.Show("该任务已经被选择了！");
            }
            else {
                //先抄写，当日说明另说
                ListViewItem first = new ListViewItem(num);
                first.SubItems.Add(name);

                //来读取当日说明

                string sql = $"SELECT* FROM 任务说明0{label8.Text} WHERE 发布时间 = {comboBox2.Text} AND 统一编号 = '{num}'";
                DataSet ds = MySQL_Method.SQLite_search(sql);
                if (ds.Tables[0].Rows.Count >= 1) {
                    first.SubItems.Add(ds.Tables[0].Rows[0]["当日说明"].ToString());
                }
                else {
                    //如果没有要查找最近的带进来
                    string sql3 = $"SELECT* FROM 任务说明0{label8.Text} WHERE 发布时间 < {comboBox2.Text} AND 统一编号 = '{num}' AND 当日说明 <> '' ORDER BY 发布时间 DESC";
                    DataSet ds3 = MySQL_Method.SQLite_search(sql3);
                    if (ds3.Tables[0].Rows.Count >= 1) {
                        first.SubItems.Add(ds3.Tables[0].Rows[0]["当日说明"].ToString());
                        string sql4 = $"insert into [任务说明0{label8.Text}](发布时间,统一编号,当日说明)values({comboBox2.Text},'{num}','{ds3.Tables[0].Rows[0]["当日说明"].ToString()}')";
                        MySQL_Method.SQLite_update(sql4);
                    }
                    else {
                        first.SubItems.Add("");
                    }
                }

                //录完了，绘制
                listView2.Items.Add(first);
                MyOtherWin_Method.Search_Quest_WhenAddQuest(this, label8.Text, comboBox2.Text);
                MyTools_Method.Find_HasChoose_ToRed_WhenAdd(this);

            }
        }

        private void listView2_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            listView2.Items.Remove(listView2.SelectedItems[0]);
            MyOtherWin_Method.Search_Quest_WhenAddQuest(this, label8.Text, comboBox2.Text);
            MyTools_Method.Find_HasChoose_ToRed_WhenAdd(this);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (listView2.FocusedItem != null) {
                if(comboBox2.Text == "") {
                    return;
                }


                string publish_time = comboBox2.Text;
                string num = listView2.FocusedItem.Text;
                string ask = textBox2.Text;
                string sql = $"SELECT* FROM 任务说明0{label8.Text} WHERE 发布时间 = {publish_time} AND 统一编号 = '{num}'";
                DataSet ds = MySQL_Method.SQLite_search(sql);
                if (ds.Tables[0].Rows.Count != 0) {
                    MyOtherWin_Method.Change_TodayAsk(publish_time, num, ask, label8.Text);
                    listView2.FocusedItem.SubItems[2].Text = ask;
                }
                else {
                    MyOtherWin_Method.Add_TodayAsk(publish_time, num, ask, label8.Text);
                    listView2.FocusedItem.SubItems[2].Text = ask;
                }
            }
            else {
                MessageBox.Show("请先选择一项");
            }
        }

        private void listView2_MouseClick(object sender, MouseEventArgs e)
        {
            try {
                string publish_time = comboBox2.Text;
                string num = listView2.FocusedItem.Text;
                MyOtherWin_Method.Show_QuestInfo_AndNearAsk(this, publish_time, num, label8.Text);
                MyOtherWin_Method.Read_TodayAsk(this, publish_time, num, label8.Text);

            }
            catch { }
        }
    }
}
