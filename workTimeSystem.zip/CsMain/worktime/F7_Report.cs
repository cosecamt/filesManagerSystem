﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace worktime
{
    public partial class F7_Report : Form
    {
        public F7_Report()
        {
            InitializeComponent();
        }

        public F7_Report(string time, string name, string num, string group)
        {

            //all
            InitializeComponent();

            label5.Text = num;
            label6.Text = name;
            label8.Text = time;
            label45.Text = group;

            comboBox2.Items.Add("（无）");
            comboBox5.Items.Add("（无）");
            comboBox7.Items.Add("（无）");
            comboBox9.Items.Add("（无）");
            comboBox11.Items.Add("（无）");
            comboBox13.Items.Add("（无）");

            string people = "";

            string sql = $"SELECT* FROM 任务分配0{group} INNER JOIN 员工信息 ON 任务分配0{group}.工号 = 员工信息.工号 WHERE 统一编号 = '{num}' AND 发布时间 = {time} AND 工作类型 = '（分配标记）'";
            DataSet ds = MySQL_Method.SQLite_search(sql);
            foreach (DataRow row in ds.Tables[0].Rows) {
                people = people + " " + row["姓名"].ToString();
                comboBox2.Items.Add(row["姓名"].ToString() + "-" + row["工号"].ToString());
                comboBox5.Items.Add(row["姓名"].ToString() + "-" + row["工号"].ToString());
                comboBox7.Items.Add(row["姓名"].ToString() + "-" + row["工号"].ToString());
                comboBox9.Items.Add(row["姓名"].ToString() + "-" + row["工号"].ToString());
                comboBox11.Items.Add(row["姓名"].ToString() + "-" + row["工号"].ToString());
                comboBox13.Items.Add(row["姓名"].ToString() + "-" + row["工号"].ToString());
            }
            comboBox1.SelectedIndex = comboBox1.Items.IndexOf("1");
            label7.Text = people.Substring(1);
            label14.Text = people.Substring(1);

            //alone
            label16.Text = num;
            label15.Text = name;
            label12.Text = time;
            comboBox3.SelectedIndex = comboBox3.Items.IndexOf("1");
            comboBox4.SelectedIndex = comboBox4.Items.IndexOf("1");
            comboBox6.SelectedIndex = comboBox6.Items.IndexOf("1");
            comboBox8.SelectedIndex = comboBox8.Items.IndexOf("1");
            comboBox10.SelectedIndex = comboBox10.Items.IndexOf("1");
            comboBox12.SelectedIndex = comboBox12.Items.IndexOf("1");
            comboBox2.SelectedIndex = comboBox2.Items.IndexOf("（无）");
            comboBox5.SelectedIndex = comboBox5.Items.IndexOf("（无）");
            comboBox7.SelectedIndex = comboBox7.Items.IndexOf("（无）");
            comboBox9.SelectedIndex = comboBox9.Items.IndexOf("（无）");
            comboBox11.SelectedIndex = comboBox11.Items.IndexOf("（无）");
            comboBox13.SelectedIndex = comboBox13.Items.IndexOf("（无）");
        }

        private void F7_Report_Load(object sender, EventArgs e)
        {
            MyConstant_1.box_num = 1;
            button6.Visible = false;

            //第2组
            label27.Visible = false;
            label26.Visible = false;
            label25.Visible = false;
            label24.Visible = false;

            comboBox5.Visible = false;
            comboBox4.Visible = false;

            textBox3.Visible = false;

            //第3组
            label31.Visible = false;
            label30.Visible = false;
            label29.Visible = false;
            label28.Visible = false;

            comboBox7.Visible = false;
            comboBox6.Visible = false;

            textBox4.Visible = false;

            //第4组
            label43.Visible = false;
            label42.Visible = false;
            label41.Visible = false;
            label40.Visible = false;

            comboBox13.Visible = false;
            comboBox12.Visible = false;

            textBox7.Visible = false;

            //第5组
            label39.Visible = false;
            label38.Visible = false;
            label37.Visible = false;
            label36.Visible = false;

            comboBox11.Visible = false;
            comboBox10.Visible = false;

            textBox6.Visible = false;

            //第6组
            label35.Visible = false;
            label34.Visible = false;
            label33.Visible = false;
            label32.Visible = false;

            comboBox9.Visible = false;
            comboBox8.Visible = false;

            textBox5.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string time = label8.Text;
            string num = label5.Text;
            string workkinds_ratio = comboBox1.Text;
            string hours = textBox1.Text;
            string group = label45.Text;
            string comments = textBox8.Text;

            MyOtherWin_Method.Add_WorkTime_AllWorker(time, num, workkinds_ratio, hours, group);
            MyOtherWin_Method.Change_QuestCompleteAndNote(time, num, group, comments);


            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string time = label12.Text;
            string num = label16.Text;
            string name = label15.Text;

            string worker = "";
            string workkinds_ratio = "";
            string hours = "";
            string worker_num = "";
            string comments = "";

            try {
                //第1个
                if (comboBox2.Text != "（无）") {
                    worker = comboBox2.Text;
                    worker_num = worker.Split('-')[1];

                    workkinds_ratio = comboBox3.Text;
                    hours = textBox2.Text;
                    MyOtherWin_Method.Add_WorkTimeAlone(time, num, name, worker_num, workkinds_ratio, hours, MyConstant_1.now_group);
                }

                //第2个
                if (comboBox5.Text != "（无）") {
                    worker = comboBox5.Text;
                    worker_num = worker.Split('-')[1];

                    workkinds_ratio = comboBox4.Text;
                    hours = textBox3.Text;
                    MyOtherWin_Method.Add_WorkTimeAlone(time, num, name, worker_num, workkinds_ratio, hours, MyConstant_1.now_group);
                }

                //第3个
                if (comboBox7.Text != "（无）") {
                    worker = comboBox7.Text;
                    worker_num = worker.Split('-')[1];

                    workkinds_ratio = comboBox6.Text;
                    hours = textBox4.Text;
                    MyOtherWin_Method.Add_WorkTimeAlone(time, num, name, worker_num, workkinds_ratio, hours, MyConstant_1.now_group);
                }

                //第4个
                if (comboBox13.Text != "（无）") {
                    worker = comboBox13.Text;
                    worker_num = worker.Split('-')[1];

                    workkinds_ratio = comboBox12.Text;
                    hours = textBox7.Text;
                    MyOtherWin_Method.Add_WorkTimeAlone(time, num, name, worker_num, workkinds_ratio, hours, MyConstant_1.now_group);
                }

                //第5个
                if (comboBox11.Text != "（无）") {
                    worker = comboBox11.Text;
                    worker_num = worker.Split('-')[1];

                    workkinds_ratio = comboBox10.Text;
                    hours = textBox6.Text;
                    MyOtherWin_Method.Add_WorkTimeAlone(time, num, name, worker_num, workkinds_ratio, hours, MyConstant_1.now_group);
                }

                //第6个
                if (comboBox9.Text != "（无）") {
                    worker = comboBox9.Text;
                    worker_num = worker.Split('-')[1];

                    workkinds_ratio = comboBox8.Text;
                    hours = textBox5.Text;
                    MyOtherWin_Method.Add_WorkTimeAlone(time, num, name, worker_num, workkinds_ratio, hours, MyConstant_1.now_group);
                }


                comments = textBox8.Text;
                MyOtherWin_Method.Change_QuestCompleteAndNote(time, num, MyConstant_1.now_group, comments);



            }
            catch {
                MessageBox.Show("工时填写请使用数字。");
                    }

            this.Close();

        }

        private void button5_Click(object sender, EventArgs e)
        {
            MyConstant_1.box_num++;
            if (MyConstant_1.box_num == 2) {
                button6.Visible = true;

                //第2组
                label27.Visible = true;
                label26.Visible = true;
                label25.Visible = true;
                label24.Visible = true;

                comboBox5.Visible = true;
                comboBox4.Visible = true;

                textBox3.Visible = true;
            }
            else if (MyConstant_1.box_num == 3) {
                //第3组
                label31.Visible = true;
                label30.Visible = true;
                label29.Visible = true;
                label28.Visible = true;

                comboBox7.Visible = true;
                comboBox6.Visible = true;

                textBox4.Visible = true;

            }
            else if (MyConstant_1.box_num == 4) {
                //第4组
                label43.Visible = true;
                label42.Visible = true;
                label41.Visible = true;
                label40.Visible = true;

                comboBox13.Visible = true;
                comboBox12.Visible = true;

                textBox7.Visible = true;
            }
            else if (MyConstant_1.box_num == 5) {
                //第5组
                label39.Visible = true;
                label38.Visible = true;
                label37.Visible = true;
                label36.Visible = true;

                comboBox11.Visible = true;
                comboBox10.Visible = true;

                textBox6.Visible = true;
            }
            else if (MyConstant_1.box_num == 6) {
                //第6组
                label35.Visible = true;
                label34.Visible = true;
                label33.Visible = true;
                label32.Visible = true;


                comboBox9.Visible = true;
                comboBox8.Visible = true;

                textBox5.Visible = true;

                button5.Visible = false;
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (MyConstant_1.box_num == 2) {
                if (comboBox5.Text != "（无）") {
                    if (MessageBox.Show("这样可能会让已经填写的信息丢失，确定要删除么？", "Confirm Message", MessageBoxButtons.OKCancel) == DialogResult.OK) {
                        button6.Visible = false;

                        //第2组
                        label27.Visible = false;
                        label26.Visible = false;
                        label25.Visible = false;
                        label24.Visible = false;

                        comboBox5.SelectedIndex = comboBox2.Items.IndexOf("（无）");
                        comboBox4.SelectedIndex = comboBox12.Items.IndexOf("1");
                        textBox3.Text = "0";

                        comboBox5.Visible = false;
                        comboBox4.Visible = false;

                        textBox3.Visible = false;
                        MyConstant_1.box_num--;
                    }
                }
                else {
                    button6.Visible = false;

                    //第2组
                    label27.Visible = false;
                    label26.Visible = false;
                    label25.Visible = false;
                    label24.Visible = false;

                    comboBox5.SelectedIndex = comboBox2.Items.IndexOf("（无）");
                    comboBox4.SelectedIndex = comboBox12.Items.IndexOf("1");
                    textBox3.Text = "0";

                    comboBox5.Visible = false;
                    comboBox4.Visible = false;

                    textBox3.Visible = false;
                    MyConstant_1.box_num--;
                }

            }
            else if (MyConstant_1.box_num == 3) {
                if (comboBox7.Text != "（无）") {
                    if (MessageBox.Show("这样可能会让已经填写的信息丢失，确定要删除么？", "Confirm Message", MessageBoxButtons.OKCancel) == DialogResult.OK) {
                        //第3组
                        label31.Visible = false;
                        label30.Visible = false;
                        label29.Visible = false;
                        label28.Visible = false;

                        comboBox7.SelectedIndex = comboBox2.Items.IndexOf("（无）");
                        comboBox6.SelectedIndex = comboBox12.Items.IndexOf("1");
                        textBox4.Text = "0";

                        comboBox7.Visible = false;
                        comboBox6.Visible = false;

                        textBox4.Visible = false;
                        MyConstant_1.box_num--;
                    }
                }
                else {
                    //第3组
                    label31.Visible = false;
                    label30.Visible = false;
                    label29.Visible = false;
                    label28.Visible = false;

                    comboBox7.SelectedIndex = comboBox2.Items.IndexOf("（无）");
                    comboBox6.SelectedIndex = comboBox12.Items.IndexOf("1");
                    textBox4.Text = "0";

                    comboBox7.Visible = false;
                    comboBox6.Visible = false;

                    textBox4.Visible = false;
                    MyConstant_1.box_num--;
                }

            }
            else if (MyConstant_1.box_num == 4) {

                if (comboBox13.Text != "（无）") {
                    if (MessageBox.Show("这样可能会让已经填写的信息丢失，确定要删除么？", "Confirm Message", MessageBoxButtons.OKCancel) == DialogResult.OK) {
                        //第4组
                        label43.Visible = false;
                        label42.Visible = false;
                        label41.Visible = false;
                        label40.Visible = false;

                        comboBox13.SelectedIndex = comboBox2.Items.IndexOf("（无）");
                        comboBox12.SelectedIndex = comboBox12.Items.IndexOf("1");
                        textBox7.Text = "0";

                        comboBox13.Visible = false;
                        comboBox12.Visible = false;

                        textBox7.Visible = false;
                        MyConstant_1.box_num--;
                    }
                }
                else {
                    //第4组
                    label43.Visible = false;
                    label42.Visible = false;
                    label41.Visible = false;
                    label40.Visible = false;

                    comboBox13.SelectedIndex = comboBox2.Items.IndexOf("（无）");
                    comboBox12.SelectedIndex = comboBox12.Items.IndexOf("1");
                    textBox7.Text = "0";

                    comboBox13.Visible = false;
                    comboBox12.Visible = false;

                    textBox7.Visible = false;
                    MyConstant_1.box_num--;
                }

            }
            else if (MyConstant_1.box_num == 5) {

                if (comboBox11.Text != "（无）") {
                    if (MessageBox.Show("这样可能会让已经填写的信息丢失，确定要删除么？", "Confirm Message", MessageBoxButtons.OKCancel) == DialogResult.OK) {
                        //第5组
                        label39.Visible = false;
                        label38.Visible = false;
                        label37.Visible = false;
                        label36.Visible = false;

                        comboBox11.SelectedIndex = comboBox2.Items.IndexOf("（无）");
                        comboBox10.SelectedIndex = comboBox12.Items.IndexOf("1");
                        textBox6.Text = "0";

                        comboBox11.Visible = false;
                        comboBox10.Visible = false;

                        textBox6.Visible = false;
                        MyConstant_1.box_num--;
                    }
                }
                else {
                    //第5组
                    label39.Visible = false;
                    label38.Visible = false;
                    label37.Visible = false;
                    label36.Visible = false;

                    comboBox11.SelectedIndex = comboBox2.Items.IndexOf("（无）");
                    comboBox10.SelectedIndex = comboBox12.Items.IndexOf("1");
                    textBox6.Text = "0";

                    comboBox11.Visible = false;
                    comboBox10.Visible = false;

                    textBox6.Visible = false;
                    MyConstant_1.box_num--;
                }
            }
            else if (MyConstant_1.box_num == 6) {
                if (comboBox9.Text != "（无）") {
                    if (MessageBox.Show("这样可能会让已经填写的信息丢失，确定要删除么？", "Confirm Message", MessageBoxButtons.OKCancel) == DialogResult.OK) {
                        //第6组
                        label35.Visible = false;
                        label34.Visible = false;
                        label33.Visible = false;
                        label32.Visible = false;

                        comboBox9.SelectedIndex = comboBox2.Items.IndexOf("（无）");
                        comboBox8.SelectedIndex = comboBox12.Items.IndexOf("1");
                        textBox5.Text = "0";

                        comboBox9.Visible = false;
                        comboBox8.Visible = false;

                        textBox5.Visible = false;

                        button5.Visible = true;
                        MyConstant_1.box_num--;
                    }
                }
                else {
                    //第6组
                    label35.Visible = false;
                    label34.Visible = false;
                    label33.Visible = false;
                    label32.Visible = false;

                    comboBox9.SelectedIndex = comboBox2.Items.IndexOf("（无）");
                    comboBox8.SelectedIndex = comboBox12.Items.IndexOf("1");
                    textBox5.Text = "0";

                    comboBox9.Visible = false;
                    comboBox8.Visible = false;

                    textBox5.Visible = false;

                    button5.Visible = true;
                    MyConstant_1.box_num--;
                }

            }
        }
    }
}
