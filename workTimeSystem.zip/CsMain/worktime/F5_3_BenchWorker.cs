﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace worktime
{
    public partial class F5_3_BenchWorker : Form
    {
        public F5_3_BenchWorker()
        {
            InitializeComponent();
        }

        public F5_3_BenchWorker(string time)
        {
            InitializeComponent();
            label4.Text = time;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void F5_3_BenchWorker_Load(object sender, EventArgs e)
        {
            MyOtherWin_Method.Read_TwoClassWorker_ForBench(this, label4.Text);//把人员信息和上次是否值班填进去
            MyOtherWin_Method.Check_TodayBenchWorker(this, label4.Text);//把今天排班的人员打勾
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string time = label4.Text;

            //先全删掉
            MyOtherWin_Method.DeleteWorker_BeforeChangeWorker(time);

            //先试验班
            for (int i = 0; i < dataGridView1.Rows.Count; i++) {
                if (dataGridView1.Rows[i].Cells[0].Value.ToString() == "True") {
                    string worker_num = dataGridView1.Rows[i].Cells[1].Value.ToString();
                    MyOtherWin_Method.AddBench_NewDistributePlan(time, worker_num);
                }
            }
            //再试制班
            for (int i = 0; i < dataGridView2.Rows.Count; i++) {
                if (dataGridView2.Rows[i].Cells[0].Value.ToString() == "True") {
                    string worker_num = dataGridView2.Rows[i].Cells[1].Value.ToString();
                    MyOtherWin_Method.AddBench_NewDistributePlan(time, worker_num);
                }
            }

            this.Close();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString() == "True") {
                dataGridView1.Rows[e.RowIndex].Cells[0].Value = false;
            }
            else {
                dataGridView1.Rows[e.RowIndex].Cells[0].Value = true;
            }
        }

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView2.Rows[e.RowIndex].Cells[0].Value.ToString() == "True") {
                dataGridView2.Rows[e.RowIndex].Cells[0].Value = false;
            }
            else {
                dataGridView2.Rows[e.RowIndex].Cells[0].Value = true;
            }
        }
    }
}
