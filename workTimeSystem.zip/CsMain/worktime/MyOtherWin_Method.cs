﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Data;
using System.Windows.Forms;
using System.Drawing;

namespace worktime
{
    class MyOtherWin_Method   //此class记载：各个子页面里的各种操作方法。
    {
        /*******************************    F2-增添人员  *******************************************/

        //在点确定时，判断是否曾经被删除过。
        public static bool Judge_WhetherHideWorker(string num)
        {
            string sql = $"SELECT* FROM 员工信息 WHERE 是否隐藏 = '是' AND 工号 = {num}";
            DataSet ds = MySQL_Method.SQLite_search(sql);
            if (ds.Tables[0].Rows.Count >= 1) {
                return true;
            }
            else {
                return false;
            }
        }

        //恢复被隐藏的用户信息
        public static void Recovery_HidedWorker(string num)
        {
            string sql = $"UPDATE 员工信息 SET 是否隐藏 = '否' WHERE 工号 = {num}";
            MySQL_Method.SQLite_update(sql);
        }

        //增加新的员工信息
        public static void Add_NewWorker(string num, string name, string row)
        {
            string sql = $"INSERT INTO 员工信息 (工号,姓名,所属班组,是否隐藏) VALUES ({num},'{name}','{row}','否')";
            MySQL_Method.SQLite_add(sql);
        }

        /******************************    F3-修改人员  *******************************************/

        //修改人员信息
        public static void Change_WorkerInfo(string num, string name, string row)
        {
            string sql = $"UPDATE 员工信息 SET 姓名 = '{name}', 所属班组 = '{row}' WHERE 工号 = {num}";
            MySQL_Method.SQLite_update(sql);
        }

        /******************************    F4-增加任务  *******************************************/

        //对于新增加的任务，在点确定时，判断是否曾经被删除过。
        public static bool Judge_Whether_HidedQuest(string num)
        {
            string sql = $"SELECT* FROM 任务信息 WHERE 是否隐藏 = '是' AND 统一编号 = '{num}'";
            DataSet ds = MySQL_Method.SQLite_search(sql);
            if (ds.Tables[0].Rows.Count >= 1) {
                return true;
            }
            else {
                return false;
            }
        }

        //恢复被隐藏的任务
        public static void Recovery_HidedQuest(string num)
        {
            string sql = $"UPDATE 任务信息 SET 是否隐藏 = '否' WHERE 统一编号 = '{num}'";
            MySQL_Method.SQLite_update(sql);
        }

        //添加项目信息
        public static void Add_NewQuest(string num_in, string num_order, string num_unify, string part, string name, string ask, string time, string type,string difficult)
        {
            string sql = $"insert into [任务信息] (内部编号,生产订单号,统一编号,编制部门,项目名,项目要求,录入时间,项目状态,项目分类,是否隐藏,项目等级)values('{num_in}','{num_order}','{num_unify}','{part}','{name}','{ask}',{time},'未完成','{type}','否','{difficult}')";
            MySQL_Method.SQLite_add(sql);
        }

        //添加项目信息——临时版本
        public static void Add_NewQuestTemp(string num_in, string num_order, string num_unify, string part, string name, string ask, string time, string type, string difficult)
        {
            string sql = $"insert into [任务信息] (内部编号,生产订单号,统一编号,编制部门,项目名,项目要求,录入时间,项目状态,项目分类,是否隐藏,项目等级)values('{num_in}','{num_order}','{num_unify}','{part}','{name}','{ask}',{time},'未完成','{type}','否','{difficult}')";
            MySQL_Method.SQLite_add(sql);
        }

        //自动填入的相关方法
        public static void Auto_WriteIn(string write_in, out string num_in, out string num_order, out string num_unify, out string part, out string name, out string ask, out string Quest_Kind)
        {
            num_in = "";
            num_order = "";
            num_unify = "";
            part = "";
            name = "";
            ask = "";

            Quest_Kind = "";



            //内部编号
            string key = "内部订单号:";
            string end = "研发项目号:";
            
            if (write_in.IndexOf(key) == -1) {
                num_in = "";
            }
            else {
                int index_start = write_in.IndexOf(key) + 6;
                int index_end = write_in.IndexOf(end) - index_start;
                num_in = write_in.Substring(index_start, index_end);
                num_in = num_in.TrimEnd();
            }


            //生产订单号
            num_order = "";

            //统一编号
            key = "部门编号:";
            end = "任务标题:";

            if (write_in.IndexOf(key) == -1) {
                num_unify = "";
            }
            else {
                int index_start = write_in.IndexOf(key) + 5;
                int index_end = write_in.IndexOf(end) - index_start;
                num_unify = write_in.Substring(index_start, index_end);
                num_unify = num_unify.TrimEnd();
            }


            //编制部门（人）
            key = "编制人:";
            end = "下发时间:";

            if (write_in.IndexOf(key) == -1) {
                part = "";
            }else {
                int index_start = write_in.IndexOf(key) + 4;
                int index_end = write_in.IndexOf(end) - index_start;
                part = write_in.Substring(index_start, index_end);
                part = part.TrimEnd();
            }


            //任务名
            key = "任务标题:";
            end = "期望完工期:";

            if (write_in.IndexOf(key) == -1) {
                name = "";
            }
            else {
                int index_start = write_in.IndexOf(key) + 5;
                int index_end = write_in.IndexOf(end) - index_start;
                name = write_in.Substring(index_start, index_end);
                name = name.TrimEnd();
            }



            //任务要求
            key = "内容要求:";
            end = "采购计划:";

            if (write_in.IndexOf(key) == -1 || write_in.IndexOf(end) == -1) {
                end = "1) 任务下发";        
            }

            if(write_in.IndexOf(key) == -1 || write_in.IndexOf(end) == -1) {
                ask = "";
            }
            else {
                int index_start = write_in.IndexOf(key) + 5;
                int index_end = write_in.IndexOf(end) - index_start;

                ask = write_in.Substring(index_start, index_end);
                ask = ask.Trim();
            }


            //任务种类
            key = "流程：";
            end = "项目基本信息";

            if (write_in.IndexOf(key) == -1) {
                Quest_Kind = "";
            }
            else {
                int index_start = write_in.IndexOf(key) + 3;
                int index_end = write_in.IndexOf(end) - index_start;
                Quest_Kind = write_in.Substring(index_start, index_end);
                Quest_Kind = Quest_Kind.TrimEnd();
            }

        }

        /******************************    F5-发布任务  *******************************************/

        //在发布界面按条件搜索相应的项目
        public static void Read_Quest_WhenPublish(F5_Publish F5_Publish)
        {
            F5_Publish.listView1.Items.Clear();
            string type = F5_Publish.comboBox1.Text;
            string keyword = F5_Publish.textBox5.Text;
            string sql = $"SELECT* FROM 任务信息 WHERE 项目状态 = '未完成' AND 项目分类 = '{type}' AND ( 项目名 LIKE '%{keyword}%' OR 编制部门 LIKE '%{keyword}%' OR 统一编号 LIKE '%{keyword}%') AND 是否隐藏 = '否'";
            DataSet ds = MySQL_Method.SQLite_search(sql);

            foreach (DataRow row in ds.Tables[0].Rows) {
                ListViewItem first = new ListViewItem(row["统一编号"].ToString());
                first.SubItems.Add(row["项目名"].ToString());
                //first.SubItems.Add(row["项目分类"].ToString());

                F5_Publish.listView1.Items.Add(first);
            }


        }

        //在发布界面加载时填充最近5天的记录
        public static void Search_NearFiveDays(F5_Publish F5_Publish, string time, string group)
        {

            //先把combo清空
            F5_Publish.comboBox2.Items.Clear();

            //查出历史
            string sql = $"SELECT DISTINCT 发布时间 FROM 任务发布0{group} WHERE 发布时间 <= {time} ORDER BY 发布时间 DESC LIMIT 5";
            DataSet ds = MySQL_Method.SQLite_search(sql);
            foreach (DataRow row in ds.Tables[0].Rows) {
                F5_Publish.comboBox2.Items.Add(row["发布时间"].ToString());
            }

            //要注意下万一没有记录要try-catch
            try {
                F5_Publish.comboBox2.SelectedIndex = F5_Publish.comboBox2.Items.IndexOf(ds.Tables[0].Rows[0]["发布时间"].ToString());
            }
            catch {
                F5_Publish.comboBox2.SelectedIndex = F5_Publish.comboBox2.Items.IndexOf("");
            }


        }

        //在发布界面选取历史时，对应出现相应的历史记录，但是已经完成的不显示
        public static void Search_HistoryQuest(F5_Publish F5_Publish, string time, string group)
        {

            F5_Publish.listView2.Items.Clear();

            string sql = $"SELECT* FROM 任务发布0{group} INNER JOIN 任务信息 ON 任务发布0{group}.统一编号 = 任务信息.统一编号 WHERE 发布时间 = {time} AND 完成情况 != '完成！'";
            DataSet ds = MySQL_Method.SQLite_search(sql);
            foreach (DataRow row in ds.Tables[0].Rows) {
                ListViewItem first = new ListViewItem(row["统一编号"].ToString());
                first.SubItems.Add(row["项目名"].ToString());
                //first.SubItems.Add(row["项目分类"].ToString());
                F5_Publish.listView2.Items.Add(first);

                string sql2 = $"SELECT* FROM 任务说明0{group} WHERE 发布时间 = {F5_Publish.label9.Text} AND 统一编号 = '{row["统一编号"].ToString()}'";
                DataSet ds2 = MySQL_Method.SQLite_search(sql2);
                if (ds2.Tables[0].Rows.Count >= 1) {
                    first.SubItems.Add(ds2.Tables[0].Rows[0]["当日说明"].ToString());
                }
                else {
                    //如果没有要查找最近的带进来
                    string sql3 = $"SELECT* FROM 任务说明0{group} WHERE 发布时间 < {F5_Publish.label9.Text} AND 统一编号 = '{row["统一编号"].ToString()}' AND 当日说明 <> '' ORDER BY 发布时间 DESC";
                    DataSet ds3 = MySQL_Method.SQLite_search(sql3);
                    if (ds3.Tables[0].Rows.Count >= 1) {
                        first.SubItems.Add(ds3.Tables[0].Rows[0]["当日说明"].ToString());
                        string sql4 = $"insert into [任务说明0{group}](发布时间,统一编号,当日说明)values({F5_Publish.label9.Text},'{row["统一编号"].ToString()}','{ds3.Tables[0].Rows[0]["当日说明"].ToString()}')";
                        MySQL_Method.SQLite_update(sql4);
                    }
                    else {
                        first.SubItems.Add("");
                    }

                }
            }

        }

        //发布页面，点击今天的任务，显示出说明
        public static void Read_TodayAsk(F5_Publish F5_Publish, string time, string num, string group)
        {
            F5_Publish.textBox2.Clear();

            string sql = $"SELECT* FROM 任务说明0{group} WHERE 发布时间 = {time} AND 统一编号 = '{num}'";
            DataSet ds = MySQL_Method.SQLite_search(sql);
            if (ds.Tables[0].Rows.Count >= 1) {
                F5_Publish.textBox2.Text = ds.Tables[0].Rows[0]["当日说明"].ToString();
            }
            else {
                F5_Publish.textBox2.Text = "";
            }
        }

        //发布页面，点击今天的任务，显示出说明
        public static void Read_TodayAsk(F14_AddPlanQuest F14_AddPlanQuest, string time, string num, string group)
        {
            F14_AddPlanQuest.textBox2.Clear();

            string sql = $"SELECT* FROM 任务说明0{group} WHERE 发布时间 = {time} AND 统一编号 = '{num}'";
            DataSet ds = MySQL_Method.SQLite_search(sql);
            if (ds.Tables[0].Rows.Count >= 1) {
                F14_AddPlanQuest.textBox2.Text = ds.Tables[0].Rows[0]["当日说明"].ToString();
            }
            else {
                F14_AddPlanQuest.textBox2.Text = "";
            }
        }

        //发布页面的说明进行修改
        public static void Change_TodayAsk(string time, string num, string ask, string group)
        {
            string sql = $"UPDATE 任务说明0{group} SET 当日说明 = '{ask}' WHERE 统一编号 = '{num}' AND 发布时间 = {time}";
            MySQL_Method.SQLite_update(sql);
        }


        //发布页面，写入今日说明
        public static void Add_TodayAsk(string time, string num, string ask, string group)
        {
            string sql = $"insert into [任务说明0{group}](发布时间,统一编号,当日说明)values({time},'{num}','{ask}')";
            MySQL_Method.SQLite_update(sql);
        }

        //录入每日流程，要分两个班组
        public static void Add_DailyProcess(string time, string group)
        {
            string sql = $"UPDATE 每日流程0{group} SET 普通流程 = '已'";
            DataSet ds = MySQL_Method.SQLite_search(sql);
        }

        //录入任务发布，要分两个班组
        public static void Add_Publish(string time, string num, string name, string group)
        {
            string sql = $"insert into [任务发布0{group}](发布时间,统一编号,完成情况,是否分配)values({time},'{num}','未完成','完成分配')";
            DataSet ds = MySQL_Method.SQLite_search(sql);
        }



        //录入任务之前，要先删除避免重复，要分两个班组
        public static void DeleteQuest_BeforeAdd_Publish(string time, string group)
        {
            string sql = $"DELETE FROM 任务发布0{group} WHERE 发布时间 = {time}";
            MySQL_Method.SQLite_delete(sql);
        }

        //发布普通任务的时候，单击列表中的任务，在右边的框中显示相应的任务信息以及最近的一次任务说明，对两边都兼容
        public static void Show_QuestInfo_AndNearAsk(F5_Publish F5_Publish, string time, string num, string group)
        {
            string sql = $"SELECT* FROM 任务信息 WHERE 统一编号 = '{num}' ";
            DataSet ds = MySQL_Method.SQLite_search(sql);

            string text_num = ds.Tables[0].Rows[0]["统一编号"].ToString();
            string text_name = ds.Tables[0].Rows[0]["项目名"].ToString();
            string text_numin = ds.Tables[0].Rows[0]["内部编号"].ToString();
            string text_nummake = ds.Tables[0].Rows[0]["生产订单号"].ToString();
            string text_questask = ds.Tables[0].Rows[0]["项目要求"].ToString();
            string text_timeadd = ds.Tables[0].Rows[0]["录入时间"].ToString();
            string text_whogive = ds.Tables[0].Rows[0]["编制部门"].ToString();

            string text_near_ask = "";
            string sql2 = $"SELECT* FROM 任务说明0{group} WHERE 统一编号 = '{num}' AND 发布时间 = {time}";
            DataSet ds2 = MySQL_Method.SQLite_search(sql2);
            if (ds2.Tables[0].Rows.Count >= 1) {
                text_near_ask = ds2.Tables[0].Rows[0]["当日说明"].ToString();
            }

            string all_text = $"统一编号：{text_num}\r\n \r\n任务名：{text_name}\r\n \r\n内部编号：{text_numin}\r\n生产订单号：{text_nummake}\r\n任务要求：{text_questask}\r\n录入时间：{text_timeadd}\r\n下发人:{text_whogive}\r\n \r\n当日说明（{group}）：{text_near_ask}";

            F5_Publish.textBox3.Text = all_text;

        }

        //发布普通任务的时候，单击列表中的任务，在右边的框中显示相应的任务信息以及最近的一次任务说明，对两边都兼容
        public static void Show_QuestInfo_AndNearAsk(F14_AddPlanQuest F14_AddPlanQuest, string time, string num, string group)
        {
            string sql = $"SELECT* FROM 任务信息 WHERE 统一编号 = '{num}' ";
            DataSet ds = MySQL_Method.SQLite_search(sql);

            string text_num = ds.Tables[0].Rows[0]["统一编号"].ToString();
            string text_name = ds.Tables[0].Rows[0]["项目名"].ToString();
            string text_numin = ds.Tables[0].Rows[0]["内部编号"].ToString();
            string text_nummake = ds.Tables[0].Rows[0]["生产订单号"].ToString();
            string text_questask = ds.Tables[0].Rows[0]["项目要求"].ToString();
            string text_timeadd = ds.Tables[0].Rows[0]["录入时间"].ToString();
            string text_whogive = ds.Tables[0].Rows[0]["编制部门"].ToString();

            string text_near_ask = "";
            string sql2 = $"SELECT* FROM 任务说明0{group} WHERE 统一编号 = '{num}' AND 发布时间 = {time}";
            DataSet ds2 = MySQL_Method.SQLite_search(sql2);
            if (ds2.Tables[0].Rows.Count >= 1) {
                text_near_ask = ds2.Tables[0].Rows[0]["当日说明"].ToString();
            }

            string all_text = $"统一编号：{text_num}\r\n \r\n任务名：{text_name}\r\n \r\n内部编号：{text_numin}\r\n生产订单号：{text_nummake}\r\n任务要求：{text_questask}\r\n录入时间：{text_timeadd}\r\n下发人:{text_whogive}\r\n \r\n当日说明（{group}）：{text_near_ask}";

            F14_AddPlanQuest.textBox3.Text = all_text;

        }


        //发布台架任务的时候，单击列表中的任务，在右边的框中显示相应的任务信息以及最近的一次任务说明，对两边都兼容
        public static void Show_BenchQuestInfo_AndNearAsk(F5_2_Publish_Bench F5_2_Publish_Bench, string time, string num)
        {
            string sql = $"SELECT* FROM 任务信息 WHERE 统一编号 = '{num}' ";
            DataSet ds = MySQL_Method.SQLite_search(sql);

            string text_num = ds.Tables[0].Rows[0]["统一编号"].ToString();
            string text_name = ds.Tables[0].Rows[0]["项目名"].ToString();
            string text_numin = ds.Tables[0].Rows[0]["内部编号"].ToString();
            string text_nummake = ds.Tables[0].Rows[0]["生产订单号"].ToString();
            string text_questask = ds.Tables[0].Rows[0]["项目要求"].ToString();
            string text_timeadd = ds.Tables[0].Rows[0]["录入时间"].ToString();
            string text_whogive = ds.Tables[0].Rows[0]["编制部门"].ToString();

            string text_near_ask = "";
            string sql2 = $"SELECT* FROM 台架说明 WHERE 统一编号 = '{num}' AND 发布时间 < {time}";
            DataSet ds2 = MySQL_Method.SQLite_search(sql2);
            if (ds2.Tables[0].Rows.Count >= 1) {
                text_near_ask = ds2.Tables[0].Rows[0]["当日说明"].ToString();
            }

            string all_text = $"统一编号：{text_num}\r\n \r\n任务名：{text_name}\r\n \r\n内部编号：{text_numin}\r\n生产订单号：{text_nummake}\r\n任务要求：{text_questask}\r\n录入时间：{text_timeadd}\r\n下发人:{text_whogive}\r\n \r\n当日说明：{text_near_ask}";

            F5_2_Publish_Bench.textBox3.Text = all_text;

        }

        /******************************    F5.2-台架试验  *******************************************/
        //在发布台架界面填入所有台架项目
        public static void Read_BenchQuest_WhenPublish(F5_2_Publish_Bench F5_2_Publish_Bench)
        {
            F5_2_Publish_Bench.listView1.Items.Clear();
            string type = "台架试验";
            string keyword = F5_2_Publish_Bench.textBox5.Text;
            string sql = $"SELECT* FROM 任务信息 WHERE 项目状态 = '未完成' AND 项目分类 = '{type}' AND ( 项目名 LIKE '%{keyword}%' OR 编制部门 LIKE '%{keyword}%' OR 统一编号 LIKE '%{keyword}%') AND 是否隐藏 = '否'";
            DataSet ds = MySQL_Method.SQLite_search(sql);

            foreach (DataRow row in ds.Tables[0].Rows) {
                ListViewItem first = new ListViewItem(row["统一编号"].ToString());
                first.SubItems.Add(row["项目名"].ToString());
                //first.SubItems.Add(row["项目分类"].ToString());

                F5_2_Publish_Bench.listView1.Items.Add(first);
            }
        }

        //在台架界面加载时填充最近5天的记录
        public static void SearchBench_NearFiveDays(F5_2_Publish_Bench F5_2_Publish_Bench, string time)
        {

            //先把combo清空
            F5_2_Publish_Bench.comboBox2.Items.Clear();

            //查出历史
            string sql = $"SELECT DISTINCT 发布时间 FROM 台架发布 WHERE 发布时间 <= {time} ORDER BY 发布时间 DESC LIMIT 5";
            DataSet ds = MySQL_Method.SQLite_search(sql);
            foreach (DataRow row in ds.Tables[0].Rows) {
                F5_2_Publish_Bench.comboBox2.Items.Add(row["发布时间"].ToString());
            }

            //要注意下万一没有记录要try-catch
            try {
                F5_2_Publish_Bench.comboBox2.SelectedIndex = F5_2_Publish_Bench.comboBox2.Items.IndexOf(ds.Tables[0].Rows[0]["发布时间"].ToString());
            }
            catch {
                F5_2_Publish_Bench.comboBox2.Text = "";
            }


        }

        //（台架版）在发布界面选取历史时，对应出现相应的历史记录，但是已经完成的不显示
        public static void SearchBench_HistoryQuest(F5_2_Publish_Bench F5_2_Publish_Bench, string time)
        {

            F5_2_Publish_Bench.listView2.Items.Clear();

            string sql = $"SELECT* FROM 台架发布 INNER JOIN 任务信息 ON 台架发布.统一编号 = 任务信息.统一编号 WHERE 发布时间 = {time} AND 完成情况 <> '完成！'";
            DataSet ds = MySQL_Method.SQLite_search(sql);
            foreach (DataRow row in ds.Tables[0].Rows) {
                ListViewItem first = new ListViewItem(row["统一编号"].ToString());
                first.SubItems.Add(row["项目名"].ToString());
                //first.SubItems.Add(row["项目分类"].ToString());
                string sql2 = $"SELECT* FROM 台架说明 WHERE 发布时间 ={F5_2_Publish_Bench.label12.Text} AND 统一编号 ='{row["统一编号"].ToString()}'";
                DataSet ds2 = MySQL_Method.SQLite_search(sql2);
                if (ds2.Tables[0].Rows.Count >= 1) {
                    first.SubItems.Add(ds2.Tables[0].Rows[0]["当日说明"].ToString());
                }else {
                    //如果没有要查找最近的带进来
                    string sql3 = $"SELECT* FROM 台架说明 WHERE 发布时间 < {F5_2_Publish_Bench.label12.Text} AND 统一编号 = '{row["统一编号"].ToString()}' AND 当日说明 <> '' ORDER BY 发布时间 DESC";
                    DataSet ds3 = MySQL_Method.SQLite_search(sql3);
                    if (ds3.Tables[0].Rows.Count >= 1) {
                        first.SubItems.Add(ds3.Tables[0].Rows[0]["当日说明"].ToString());
                        string sql4 = $"insert into [台架说明](发布时间,统一编号,当日说明)values({F5_2_Publish_Bench.label12.Text},'{row["统一编号"].ToString()}','{ds3.Tables[0].Rows[0]["当日说明"].ToString()}')";
                        MySQL_Method.SQLite_update(sql4);
                    }
                    else {
                        first.SubItems.Add("");
                    }
                }
                F5_2_Publish_Bench.listView2.Items.Add(first);
            }
        }

        //台架版-发布页面，点击今天的任务，显示出说明
        public static void ReadBench_TodayAsk(F5_2_Publish_Bench F5_2_Publish_Bench, string time, string num)
        {
            F5_2_Publish_Bench.textBox2.Clear();

            string sql = $"SELECT* FROM 台架说明 WHERE 发布时间 = {time} AND 统一编号 = '{num}'";
            DataSet ds = MySQL_Method.SQLite_search(sql);
            if (ds.Tables[0].Rows.Count >= 1) {
                F5_2_Publish_Bench.textBox2.Text = ds.Tables[0].Rows[0]["当日说明"].ToString();
            }
            else {
                F5_2_Publish_Bench.textBox2.Text = "";
            }
        }

        //台架版，发布页面的说明进行修改
        public static void ChangeBench_TodayAsk(string time, string num, string ask)
        {
            string sql = $"UPDATE 台架说明 SET 当日说明 = '{ask}' WHERE 统一编号 = '{num}' AND 发布时间 = {time}";
            MySQL_Method.SQLite_update(sql);
        }


        //台架版，发布页面，写入今日说明
        public static void AddBench_TodayAsk(string time, string num, string ask)
        {
            string sql = $"insert into [台架说明](发布时间,统一编号,当日说明)values({time},'{num}','{ask}')";
            MySQL_Method.SQLite_update(sql);
        }


        //台架版，录入任务发布
        public static void AddBench_Publish(string time, string num)
        {
            string sql = $"insert into [台架发布](发布时间,统一编号,完成情况,数据类型)values({time},'{num}','未完成','项目')";
            MySQL_Method.SQLite_add(sql);
        }

        //台架版，录入任务之前，要先删除避免重复，要分两个班组
        public static void DeleteQuest_BeforeAdd_PublishBench(string time)
        {
            string sql = $"DELETE FROM 台架发布 WHERE 发布时间 = {time} AND 数据类型 = '项目'";
            MySQL_Method.SQLite_delete(sql);
        }

        //选取值班人员，在如两个班组的人员名单
        public static void Read_TwoClassWorker_ForBench(F5_3_BenchWorker F5_3_BenchWorker, string time)
        {
            F5_3_BenchWorker.dataGridView1.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            F5_3_BenchWorker.dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            F5_3_BenchWorker.dataGridView2.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            F5_3_BenchWorker.dataGridView2.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            string last_time = "无";

            //先确认上一次有记录的值班时间是什么时候
            string sql = $"SELECT* FROM 台架发布 WHERE 发布时间 < {time} ORDER BY 发布时间 DESC";
            DataSet ds = MySQL_Method.SQLite_search(sql);
            if (ds.Tables[0].Rows.Count >= 1) {
                last_time = ds.Tables[0].Rows[0]["发布时间"].ToString();
            }

            //先加载试验班，再加载试制班
            string last_whether_work = "";
            sql = $"SELECT* FROM 员工信息 WHERE 所属班组 = '试验班' AND 是否隐藏 = '否'";
            DataSet ds2 = MySQL_Method.SQLite_search(sql);

            foreach (DataRow row in ds2.Tables[0].Rows) {
                last_whether_work = "";
                string num = row["工号"].ToString();
                string name = row["姓名"].ToString();

                string sql2 = $"SELECT* FROM 台架发布 WHERE 工号 = '{row["工号"].ToString()}' ORDER BY 发布时间 DESC";
                DataSet ds3 = MySQL_Method.SQLite_search(sql2);
                if (ds3.Tables[0].Rows.Count >= 1) {
                    if (ds3.Tables[0].Rows[0]["发布时间"].ToString() == last_time) {
                        last_whether_work = "是";
                    }
                }

                F5_3_BenchWorker.dataGridView1.Rows.Add(false, num, name, last_whether_work);
            }

            //轮到试制班
            sql = $"SELECT* FROM 员工信息 WHERE 所属班组 = '试制班' AND 是否隐藏 = '否'";
            DataSet ds5 = MySQL_Method.SQLite_search(sql);

            foreach (DataRow row in ds5.Tables[0].Rows) {
                last_whether_work = "";
                string num = row["工号"].ToString();
                string name = row["姓名"].ToString();

                string sql2 = $"SELECT* FROM 台架发布 WHERE 工号 = '{row["工号"].ToString()}' ORDER BY 发布时间 DESC";
                DataSet ds4 = MySQL_Method.SQLite_search(sql2);
                if (ds4.Tables[0].Rows.Count >= 1) {
                    if (ds4.Tables[0].Rows[0]["发布时间"].ToString() == last_time) {
                        last_whether_work = "是";
                    }
                }

                F5_3_BenchWorker.dataGridView2.Rows.Add(false, num, name, last_whether_work);
            }



        }

        //选取值班人员，在如两个班组的人员名单——报工时界面版
        public static void Read_TwoClassWorker_ForBench_WhenReport(F5_4_BenchWorker_Change F5_4_BenchWorker_Change, string time)
        {
            F5_4_BenchWorker_Change.dataGridView1.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            F5_4_BenchWorker_Change.dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            F5_4_BenchWorker_Change.dataGridView2.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            F5_4_BenchWorker_Change.dataGridView2.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            string last_time = "无";

            //先确认上一次有记录的值班时间是什么时候
            string sql = $"SELECT* FROM 台架发布 WHERE 发布时间 < {time} ORDER BY 发布时间 DESC";
            DataSet ds = MySQL_Method.SQLite_search(sql);
            if (ds.Tables[0].Rows.Count >= 1) {
                last_time = ds.Tables[0].Rows[0]["发布时间"].ToString();
            }

            //先加载试验班，再加载试制班
            string last_whether_work = "";
            sql = $"SELECT* FROM 员工信息 WHERE 所属班组 = '试验班' AND 是否隐藏 = '否'";
            DataSet ds2 = MySQL_Method.SQLite_search(sql);

            foreach (DataRow row in ds2.Tables[0].Rows) {
                last_whether_work = "";
                string num = row["工号"].ToString();
                string name = row["姓名"].ToString();

                string sql2 = $"SELECT* FROM 台架发布 WHERE 工号 = '{row["工号"].ToString()}' ORDER BY 发布时间 DESC";
                DataSet ds3 = MySQL_Method.SQLite_search(sql2);
                if (ds3.Tables[0].Rows.Count >= 1) {
                    if (ds3.Tables[0].Rows[0]["发布时间"].ToString() == last_time) {
                        last_whether_work = "是";
                    }
                }

                F5_4_BenchWorker_Change.dataGridView1.Rows.Add(false, num, name, last_whether_work);
            }

            //轮到试制班
            sql = $"SELECT* FROM 员工信息 WHERE 所属班组 = '试制班' AND 是否隐藏 = '否'";
            DataSet ds5 = MySQL_Method.SQLite_search(sql);

            foreach (DataRow row in ds5.Tables[0].Rows) {
                last_whether_work = "";
                string num = row["工号"].ToString();
                string name = row["姓名"].ToString();

                string sql2 = $"SELECT* FROM 台架发布 WHERE 工号 = '{row["工号"].ToString()}' ORDER BY 发布时间 DESC";
                DataSet ds4 = MySQL_Method.SQLite_search(sql2);
                if (ds4.Tables[0].Rows.Count >= 1) {
                    if (ds4.Tables[0].Rows[0]["发布时间"].ToString() == last_time) {
                        last_whether_work = "是";
                    }
                }

                F5_4_BenchWorker_Change.dataGridView2.Rows.Add(false, num, name, last_whether_work);
            }



        }





        //选取值班人员，在如两个班组的人员名单
        public static void Check_TodayBenchWorker(F5_3_BenchWorker F5_3_BenchWorker, string time)
        {

            //先查再勾
            //先查
            string worker_num = "";
            string sql = $"SELECT* FROM 台架发布 WHERE 数据类型 = '人员' AND 发布时间 = {time}";
            DataSet ds = MySQL_Method.SQLite_search(sql);
            if (ds.Tables[0].Rows.Count >= 1) {
                foreach (DataRow row in ds.Tables[0].Rows) {
                    for (int i = 0; i < F5_3_BenchWorker.dataGridView1.Rows.Count; i++) {
                        worker_num = F5_3_BenchWorker.dataGridView1.Rows[i].Cells[1].Value.ToString();
                        if (row["工号"].ToString() == worker_num) {
                            F5_3_BenchWorker.dataGridView1.Rows[i].Cells[0].Value = true;
                        }
                    }
                    for (int i = 0; i < F5_3_BenchWorker.dataGridView2.Rows.Count; i++) {
                        worker_num = F5_3_BenchWorker.dataGridView2.Rows[i].Cells[1].Value.ToString();
                        if (row["工号"].ToString() == worker_num) {
                            F5_3_BenchWorker.dataGridView2.Rows[i].Cells[0].Value = true;
                        }
                    }

                }
            }
        }


        //选取值班人员，在如两个班组的人员名单——报工时界面版本
        public static void Check_TodayBenchWorker_WhenReport(F5_4_BenchWorker_Change F5_4_BenchWorker_Change, string time)
        {

            //先查再勾
            //先查
            string worker_num = "";
            string sql = $"SELECT* FROM 台架发布 WHERE 数据类型 = '人员' AND 发布时间 = {time}";
            DataSet ds = MySQL_Method.SQLite_search(sql);
            if (ds.Tables[0].Rows.Count >= 1) {
                foreach (DataRow row in ds.Tables[0].Rows) {
                    for (int i = 0; i < F5_4_BenchWorker_Change.dataGridView1.Rows.Count; i++) {
                        worker_num = F5_4_BenchWorker_Change.dataGridView1.Rows[i].Cells[1].Value.ToString();
                        if (row["工号"].ToString() == worker_num) {
                            F5_4_BenchWorker_Change.dataGridView1.Rows[i].Cells[0].Value = true;
                        }
                    }
                    for (int i = 0; i < F5_4_BenchWorker_Change.dataGridView2.Rows.Count; i++) {
                        worker_num = F5_4_BenchWorker_Change.dataGridView2.Rows[i].Cells[1].Value.ToString();
                        if (row["工号"].ToString() == worker_num) {
                            F5_4_BenchWorker_Change.dataGridView2.Rows[i].Cells[0].Value = true;
                        }
                    }

                }
            }
        }

        //添加-分配信息
        public static void AddBench_NewDistributePlan(string time, string worker_num)
        {
            string sql = $"insert into [台架发布](发布时间,工号,数据类型)values({time},{worker_num},'人员')";
            MySQL_Method.SQLite_add(sql);
        }

        //刷新值班人员选择,要显示最近的一个,等会再写，先显示当天吧
        public static void Read_BenchWorker_Today(F5_2_Publish_Bench F5_2_Publish_Bench, string time)
        {
            string time_near = "20200230";
            string sql2 = $"SELECT* FROM 台架发布 INNER JOIN 员工信息 ON 台架发布.工号 = 员工信息.工号 WHERE 数据类型 = '人员' AND 发布时间 <= {time} ORDER BY 发布时间 DESC";
            DataSet ds2 = MySQL_Method.SQLite_search(sql2);
            if (ds2.Tables[0].Rows.Count >= 1) {
                time_near = ds2.Tables[0].Rows[0]["发布时间"].ToString();
            }

            string sql = $"SELECT* FROM 台架发布 INNER JOIN 员工信息 ON 台架发布.工号 = 员工信息.工号 WHERE 数据类型 = '人员' AND 发布时间 = {time_near}";
            DataSet ds = MySQL_Method.SQLite_search(sql);
            string sy = "";
            string sz = "";

            foreach (DataRow row in ds.Tables[0].Rows) {
                if (row["所属班组"].ToString() == "试验班") {
                    sy = sy + "，" + row["姓名"].ToString();
                }
                else {
                    sz = sz + "，" + row["姓名"].ToString();
                }
            }
            if (sy.Length >= 1) {
                sy = sy.Substring(1);
            }
            if (sz.Length >= 1) {
                sz = sz.Substring(1);
            }
            
            F5_2_Publish_Bench.label10.Text = sy;
            F5_2_Publish_Bench.label11.Text = sz;

        }

        public static void Change_BenchProcess(string time)
        {
            //先给试验班处理
            string sql = $"SELECT* FROM 每日流程0试验班 WHERE 发布时间 = {time}";
            DataSet ds = MySQL_Method.SQLite_search(sql);
            if (ds.Tables[0].Rows.Count >=1 ) {
                string sql2 = $"UPDATE 每日流程0试验班 SET 台架流程 = '已分配' WHERE 发布时间 = {time}";
                MySQL_Method.SQLite_update(sql2);
            }else {
                string sql2 = $"INSERT INTO 每日流程0试验班 (发布时间,台架流程) VALUES ({time},'已分配')";
                MySQL_Method.SQLite_add(sql2);
            }

            //再给试制班处理
            string sql3 = $"SELECT* FROM 每日流程0试制班 WHERE 发布时间 = {time}";
            DataSet ds3 = MySQL_Method.SQLite_search(sql3);
            if (ds3.Tables[0].Rows.Count >= 1) {
                string sql2 = $"UPDATE 每日流程0试制班 SET 台架流程 = '已分配' WHERE 发布时间 = {time}";
                MySQL_Method.SQLite_update(sql2);
            }
            else {
                string sql2 = $"INSERT INTO 每日流程0试制班 (发布时间,台架流程) VALUES ({time},'已分配')";
                MySQL_Method.SQLite_add(sql2);
            }


        }

        public static void Judge_WhetherTodayWorker_AndCopyNear(string time)
        {
            string sql = $"SELECT* FROM 台架发布 WHERE 发布时间 = {time} AND 数据类型 = '人员'";
            DataSet ds = MySQL_Method.SQLite_search(sql);
            if (ds.Tables[0].Rows.Count == 0) {
                string sql2 = $"SELECT* FROM 台架发布 WHERE 发布时间 < {time} AND 数据类型 = '人员' ORDER BY 发布时间 DESC";
                DataSet ds2 = MySQL_Method.SQLite_search(sql2);
                string last_time = "";
                if (ds2.Tables[0].Rows.Count >= 1) {
                    last_time = ds2.Tables[0].Rows[0]["发布时间"].ToString();
                }

                string sql3 = $"SELECT* FROM 台架发布 WHERE 发布时间 = {last_time} AND 数据类型 = '人员'";
                DataSet ds3 = MySQL_Method.SQLite_search(sql3);

                if (ds3.Tables[0].Rows.Count >= 1) {
                    foreach (DataRow row in ds3.Tables[0].Rows) {
                        string sql4 = $"INSERT INTO 台架发布 (发布时间,工号,数据类型) VALUES ({time}, '{row["工号"].ToString()}', '人员')";
                        MySQL_Method.SQLite_add(sql4);
                    }
                }
            }

        }


        /******************************    F6-分配任务  *******************************************/

        //分配页面-员工更新
        public static void Read_Worker_AndThierQuest(F6_Dis F6_Dis, string group)
        {
            F6_Dis.dataGridView1.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            F6_Dis.dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;

            string sql = $"SELECT* FROM 员工信息 WHERE 所属班组 = '{group}' AND 是否隐藏 = '否'";
            DataSet ds = MySQL_Method.SQLite_search(sql);//把所有人抓出来

            string sql2 = $"SELECT* FROM 台架发布 INNER JOIN 员工信息 ON 台架发布.工号 = 员工信息.工号 WHERE 发布时间 = {F6_Dis.label4.Text} AND 数据类型 = '人员'";
            DataSet ds2 = MySQL_Method.SQLite_search(sql2);//把值班的人抓出来
            
            foreach (DataRow row in ds.Tables[0].Rows) {
                string num = row["工号"].ToString();
                string name = row["姓名"].ToString();
                string bench = "";

                foreach (DataRow row2 in ds2.Tables[0].Rows) {
                    if (row2["工号"].ToString() == row["工号"].ToString()) {
                        bench = "●值班";
                    }
                }
                F6_Dis.dataGridView1.Rows.Add(false, num, name, bench);
            }

        }

        //添加-分配信息
        public static void Add_NewDistributePlan(string time, string num,string worker_num, string group)
        {
            string sql = $"insert into [任务分配0{group}](发布时间,统一编号,工号,工作类型,工时系数,工作小时)values({time},'{num}',{worker_num},'（分配标记）',0,0)";
            MySQL_Method.SQLite_add(sql);
        }

        //在工时填报界面，删除部分人员的信息
        public static void Del_DistributePlan(string time, string num, string worker_num, string group)
        {
            string sql = $"DELETE FROM 任务分配0{group} WHERE 发布时间 = {time} AND 统一编号 = '{num}' AND 工号 = {worker_num}";         
            MySQL_Method.SQLite_delete(sql);
        }


        //在工时填报界面，查找该人员存在与否
        public static bool Search_DistributePlan(string time, string num, string worker_num, string group)
        {
            string sql = $"SELECT * FROM 任务分配0{group} WHERE 发布时间 = {time} AND 统一编号 = '{num}' AND 工号 = {worker_num}";
            DataSet ds = MySQL_Method.SQLite_search(sql);
            if (ds.Tables[0].Rows.Count >= 1) {
                return true;
            }
            else {
                return false;
            }
        }

        //在工时填报界面，查找该人员存在与否——台架版
        public static bool Search_DistributePlan_Bench(string time, string worker_num)
        {
            string sql = $"SELECT * FROM 台架发布 WHERE 发布时间 = {time} AND 工号 = {worker_num} AND 数据类型 = '人员'";
            DataSet ds = MySQL_Method.SQLite_search(sql);
            if (ds.Tables[0].Rows.Count >= 1) {
                return true;
            }
            else {
                return false;
            }
        }

        //修改分配页面，加载现在分配的状况
        public static void Read_ChangeSurfaceLoad(F6_2_Change_Dis F6_2_Change_Dis, string num, string time, string group)
        {

            F6_2_Change_Dis.dataGridView1.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            F6_2_Change_Dis.dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;

            string sql = $"SELECT* FROM 员工信息 WHERE 所属班组 = '{group}' AND 是否隐藏 = '否'";
            DataSet ds = MySQL_Method.SQLite_search(sql);//把所有人抓出来

            string sql2 = $"SELECT* FROM 台架发布 INNER JOIN 员工信息 ON 台架发布.工号 = 员工信息.工号 WHERE 发布时间 = {time} AND 数据类型 = '人员'";
            DataSet ds2 = MySQL_Method.SQLite_search(sql2);//把值班的人抓出来

            foreach (DataRow row in ds.Tables[0].Rows) {
                string quest_num = row["工号"].ToString();
                string name = row["姓名"].ToString();
                string bench = "";

                foreach (DataRow row2 in ds2.Tables[0].Rows) {
                    if (row2["工号"].ToString() == row["工号"].ToString()) {
                        bench = "●值班";
                    }
                }
                F6_2_Change_Dis.dataGridView1.Rows.Add(false, quest_num, name, bench);
            }

            sql = $"SELECT* FROM 任务分配0{group} WHERE 工作类型 = '（分配标记）' AND 统一编号 = '{num}' AND 发布时间 = {time}";
            DataSet ds3 = MySQL_Method.SQLite_search(sql);
            foreach (DataRow row3 in ds3.Tables[0].Rows) {
                string worker_num = "";
                for (int i = 0; i < F6_2_Change_Dis.dataGridView1.Rows.Count; i++) {
                    worker_num = F6_2_Change_Dis.dataGridView1.Rows[i].Cells[1].Value.ToString();
                    if (row3["工号"].ToString() == worker_num) {
                        F6_2_Change_Dis.dataGridView1.Rows[i].Cells[0].Value = true;
                    }
                }
            }

        }


        //修改分配页面，加载现在分配的状况——在工时填报页面的版本
        public static void Read_ChangeSurfaceLoad_WhenWriteWorkTime(F6_4_Change_WhenWork_Another F6_4_Change_WhenWork_Another, string num, string time, string group)
        {

            F6_4_Change_WhenWork_Another.dataGridView1.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            F6_4_Change_WhenWork_Another.dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;

            string sql = $"SELECT* FROM 员工信息 WHERE 所属班组 = '{group}' AND 是否隐藏 = '否'";
            DataSet ds = MySQL_Method.SQLite_search(sql);//把所有人抓出来

            string sql2 = $"SELECT* FROM 台架发布 INNER JOIN 员工信息 ON 台架发布.工号 = 员工信息.工号 WHERE 发布时间 = {time} AND 数据类型 = '人员'";
            DataSet ds2 = MySQL_Method.SQLite_search(sql2);//把值班的人抓出来

            foreach (DataRow row in ds.Tables[0].Rows) {
                string quest_num = row["工号"].ToString();
                string name = row["姓名"].ToString();
                string bench = "";

                foreach (DataRow row2 in ds2.Tables[0].Rows) {
                    if (row2["工号"].ToString() == row["工号"].ToString()) {
                        bench = "●值班";
                    }
                }
                F6_4_Change_WhenWork_Another.dataGridView1.Rows.Add(false, quest_num, name, bench);
            }

            sql = $"SELECT* FROM 任务分配0{group} WHERE 工作类型 = '（分配标记）' AND 统一编号 = '{num}' AND 发布时间 = {time}";
            DataSet ds3 = MySQL_Method.SQLite_search(sql);
            foreach (DataRow row3 in ds3.Tables[0].Rows) {
                string worker_num = "";
                for (int i = 0; i < F6_4_Change_WhenWork_Another.dataGridView1.Rows.Count; i++) {
                    worker_num = F6_4_Change_WhenWork_Another.dataGridView1.Rows[i].Cells[1].Value.ToString();
                    if (row3["工号"].ToString() == worker_num) {
                        F6_4_Change_WhenWork_Another.dataGridView1.Rows[i].Cells[0].Value = true;
                    }
                }
            }

        }

        //台架版，录入人员之前，要先删除避免重复
        public static void DeleteWorker_BeforeChangeWorker(string time)
        {
            string sql = $"DELETE FROM 台架发布 WHERE 发布时间 = {time} AND 数据类型 = '人员'";
            MySQL_Method.SQLite_delete(sql);
        }

        //台架版，录入人员之前，要先删除避免重复——在报工时界面的版本
        public static void DeleteWorker_BeforeChangeWorker_WhenReport(string time,string num_worker)
        {
            string sql = $"DELETE FROM 台架发布 WHERE 发布时间 = {time} AND 数据类型 = '人员' AND 工号 = {num_worker}";
            MySQL_Method.SQLite_delete(sql);
            sql = $"DELETE FROM 台架分配 WHERE 发布时间 = {time} AND 工号 = {num_worker}";
            MySQL_Method.SQLite_delete(sql);
        }



        /******************************    F7-工时汇报  *******************************************/

        //录入工作时间-“统一录入”
        public static void Add_WorkTime_AllWorker(string time, string num, string workkinds_ratio, string hours, string group)
        {
            string ratio = workkinds_ratio;

            string worker = "";
            string sql = $"SELECT* FROM 任务分配0{group} WHERE 发布时间 = {time} AND 统一编号 = '{num}' AND 工作类型 = '（分配标记）'";

            string sql_2 = "";

            DataSet ds = MySQL_Method.SQLite_search(sql);
            foreach (DataRow row in ds.Tables[0].Rows) {
                worker = row["工号"].ToString();
                sql_2 = $"insert into [任务分配0{group}](发布时间,统一编号,工号,工作类型,工时系数,工作小时)values({time},'{num}','{worker}','废弃属性',{ratio},{hours})";
                MySQL_Method.SQLite_add(sql_2);
            }
        }

        //改变该项目汇报时的完成状态和备注
        public static void Change_QuestCompleteAndNote(string time, string num, string group, string comments)
        {
            string sql = $"UPDATE 任务发布0{group} SET 当日备注 = '{comments}' WHERE 发布时间 = {time} AND 统一编号 = '{num}' ";
            MySQL_Method.SQLite_update(sql);
        }

        //录入工作时间-“分开录入”
        public static void Add_WorkTimeAlone(string time, string num, string name, string worker_num, string workkinds_ratio, string hours, string group)
        {
            string ratio = workkinds_ratio;
            string sql = $"insert into [任务分配0{group}](发布时间,统一编号,工号,工作类型,工时系数,工作小时)values({time},'{num}',{worker_num} ,'废弃属性',{ratio},{hours})";
            MySQL_Method.SQLite_add(sql);

        }


        //录入工作时间-“统一录入”——台架版
        public static void Add_WorkTime_AllWorkerBench(string time, string num, string workkinds_ratio, string hours)
        {
            string ratio = workkinds_ratio;

            string worker = "";
            string sql = $"SELECT* FROM 台架发布 INNER JOIN 员工信息 ON 台架发布.工号 = 员工信息.工号 WHERE 发布时间 = {time} AND 数据类型 = '人员'";

            string sql_2 = "";

            DataSet ds = MySQL_Method.SQLite_search(sql);
            foreach (DataRow row in ds.Tables[0].Rows) {
                worker = row["工号"].ToString();
                sql_2 = $"insert into [台架分配](发布时间,统一编号,工号,工作类型,工时系数,工作小时)values({time},'{num}','{worker}','废弃属性',{ratio},{hours})";
                MySQL_Method.SQLite_add(sql_2);
            }
        }

        //改变该项目汇报时的完成状态和备注——台架版,算了，就当他没这个功能吧
        public static void Change_QuestCompleteAndNoteBench(string time, string num, string result, string group, string comments)
        {
            string sql = $"UPDATE 台架发布 SET 完成情况 = '{result}',当日备注 = '{comments}' WHERE 发布时间 = {time} AND 统一编号 = '{num}' ";
            MySQL_Method.SQLite_update(sql);
        }

        //录入工作时间-“分开录入”——台架版
        public static void Add_WorkTimeAloneBench(string time, string num, string name, string worker_num, string workkinds_ratio, string hours, string group)
        {
            string ratio = workkinds_ratio;
            string sql = $"insert into [台架分配](发布时间,统一编号,工号,工作类型,工时系数,工作小时)values({time},'{num}',{worker_num} ,'废弃属性',{ratio},{hours})";
            MySQL_Method.SQLite_add(sql);

        }


        /******************************    F8-请假  *******************************************/

        //读取请假列表
        public static void Read_AskForLeave_History(string time, F8_holiday F8_holiday)
        {
            F8_holiday.listView1.Items.Clear();
            time = MyTools_Method.Date_ToNum(time).ToString();
            if (MyConstant_1.now_group == "管理员") {
                string sql = $"SELECT* FROM 任务分配0试验班 INNER JOIN 员工信息 ON 任务分配0试验班.工号 = 员工信息.工号 WHERE 发布时间 = {time} AND 工作类型 = '（请假）'";
                DataSet ds = MySQL_Method.SQLite_search(sql);
                foreach (DataRow row in ds.Tables[0].Rows) {
                    ListViewItem first = new ListViewItem(row["工号"].ToString());
                    first.SubItems.Add(row["姓名"].ToString());
                    first.SubItems.Add(row["工作小时"].ToString());

                    F8_holiday.listView1.Items.Add(first);
                }

                sql = $"SELECT* FROM 任务分配0试制班 INNER JOIN 员工信息 ON 任务分配0试制班.工号 = 员工信息.工号 WHERE 发布时间 = {time} AND 工作类型 = '（请假）'";
                DataSet ds2 = MySQL_Method.SQLite_search(sql);
                foreach (DataRow row in ds2.Tables[0].Rows) {
                    ListViewItem first = new ListViewItem(row["工号"].ToString());
                    first.SubItems.Add(row["姓名"].ToString());
                    first.SubItems.Add(row["工作小时"].ToString());

                    F8_holiday.listView1.Items.Add(first);
                }


            }
            else {
                string sql = $"SELECT* FROM 任务分配0{MyConstant_1.now_group} INNER JOIN 员工信息 ON 任务分配0{MyConstant_1.now_group}.工号 = 员工信息.工号 WHERE 发布时间 = {time} AND 工作类型 = '（请假）'";
                DataSet ds = MySQL_Method.SQLite_search(sql);
                foreach (DataRow row in ds.Tables[0].Rows) {
                    ListViewItem first = new ListViewItem(row["工号"].ToString());
                    first.SubItems.Add(row["姓名"].ToString());
                    first.SubItems.Add(row["工作小时"].ToString());

                    F8_holiday.listView1.Items.Add(first);
                }
            }

        }

        //修改请假信息
        public static void Change_AskForLeave(string time, string worker_num, string hours)
        {
            time = MyTools_Method.Date_ToNum(time).ToString();
            string sql = $"UPDATE 任务分配0{MyConstant_1.now_group} SET 工作小时 = '{hours}' WHERE 工号 = {worker_num} AND 工作类型 = '（请假）' AND 发布时间 = {time}";
            MySQL_Method.SQLite_update(sql);
        }

        //添加请假信息
        public static void Add_AskForLeave(string time, string worker_num, string hours)
        {
            time = MyTools_Method.Date_ToNum(time).ToString();
            string sql = $"insert into [任务分配0{MyConstant_1.now_group}](发布时间, 工号, 工作小时, 工作类型)values({time},{worker_num},{hours},'（请假）')";
            MySQL_Method.SQLite_add(sql);
        }

        /******************************    F9-数据库地址  *******************************************/

        //将INI文件中记录的数据库连接剪切成用来显示的地址
        public static string convert_IniData_to_WriteInData(string last_connect)
        {
            int index_start = 12;
            int index_end = last_connect.Length - 12 - 11;
            string writein = last_connect.Substring(index_start, index_end);
            return writein;
        }

        /******************************    F11-登录界面  *******************************************/
        //在加载时，从INI填写上次的登录信息
        public static void Auto_WriteIn_LastInfo(F11_Login_In F11_Login_In, string choose, string user, string password)
        {
            if (choose == "1") {
                F11_Login_In.radioButton1.Checked = true;
                F11_Login_In.textBox1.Text = "";
                F11_Login_In.textBox2.Text = "";
            }
            else if (choose == "2") {
                F11_Login_In.radioButton3.Checked = true;
                F11_Login_In.textBox1.Text = "";
                F11_Login_In.textBox2.Text = "";
            }
            else if (choose == "3") {
                F11_Login_In.radioButton2.Checked = true;
                F11_Login_In.textBox1.Text = user;
                F11_Login_In.textBox2.Text = password;
            }
            else if (choose == "4") {
                F11_Login_In.radioButton4.Checked = true;
                F11_Login_In.textBox1.Text = user;
                F11_Login_In.textBox2.Text = password;
            }
            else {
                F11_Login_In.radioButton1.Checked = true;
                F11_Login_In.textBox1.Text = "";
                F11_Login_In.textBox2.Text = "";
            }
        }

        //在点击登录时，判断勾选的类型
        public static string Judge_KindOfPower(F11_Login_In F11_Login_In)
        {
            string kind = "试验班";
            if (F11_Login_In.radioButton1.Checked == true) {
                return kind;
            }
            else if (F11_Login_In.radioButton3.Checked == true) {
                kind = "试制班";
                return kind;
            }
            else if (F11_Login_In.radioButton2.Checked == true) {
                kind = "管理员";
                return kind;
            }
            else if (F11_Login_In.radioButton4.Checked == true) {
                kind = "技术组";
                return kind;
            }
            else {
                return kind;
            }
        }

        //在点击登录时，将权限类型写入INI
        public static void WriteIn_PowerInfo_ToIni(string kind_of_power)
        {
            if (kind_of_power == "试验班") {
                MyIni_Method.writeString("LogIn", "choose", "1", @"data\setting.ini");
            }
            else if (kind_of_power == "试制班") {
                MyIni_Method.writeString("LogIn", "choose", "2", @"data\setting.ini");
            }
            else if (kind_of_power == "管理员") {
                MyIni_Method.writeString("LogIn", "choose", "3", @"data\setting.ini");
            }
            else if (kind_of_power == "技术组") {
                MyIni_Method.writeString("LogIn", "choose", "4", @"data\setting.ini");
            }
            else {
                MyIni_Method.writeString("LogIn", "choose", "1", @"data\setting.ini");
            }
        }

        //在点击登录时，1-判断登录种类并返回，登录失败也视作一种情况 2-修改公共变量“now_group”3-如果是管理员，需要验证密码
        public static string Judge_LoginPower(string kind_of_power, string user, string password)
        {
            if (kind_of_power == "试验班") {
                MyConstant_1.now_group = "试验班";
                return "成功";
            }
            else if (kind_of_power == "试制班") {
                MyConstant_1.now_group = "试制班";
                return "成功";
            }
            else if (kind_of_power == "管理员") {
                string sql = $"SELECT * FROM 权限 WHERE 账号 = '{user}' AND 密码 = '{password}' AND 用户类型 = '管理员'";
                DataSet ds = MySQL_Method.SQLite_search(sql);

                if (ds.Tables[0].Rows.Count >= 1) {
                    MyConstant_1.now_group = "管理员";
                    MyIni_Method.writeString("LogIn", "choose", "3", @"data\setting.ini");
                    return "成功";
                }
                else {
                    MyConstant_1.now_group = "试验班";
                    return "登录失败";
                }
            }
            else if (kind_of_power == "技术组") {
                string sql = $"SELECT * FROM 权限 WHERE 账号 = '{user}' AND 密码 = '{password}' AND 用户类型 = '技术组'";
                DataSet ds = MySQL_Method.SQLite_search(sql);

                if (ds.Tables[0].Rows.Count >= 1) {
                    MyConstant_1.now_group = "技术组";
                    MyIni_Method.writeString("LogIn", "choose", "4", @"data\setting.ini");
                    return "成功";
                }
                else {
                    MyConstant_1.now_group = "试验班";
                    return "登录失败";
                }
            }
            else {
                MyConstant_1.now_group = "试验班";
                return "试验班";
            }
        }


        /******************************    F14-追加任务  *******************************************/

        //把处于 已分配 和 已发布 的日期找出来填进框里
        public static void WriteIn_CanAddQuestDay(F14_AddPlanQuest F14_AddPlanQuest, string group)
        {
            string sql = $"SELECT* FROM 每日流程0{group} WHERE 普通流程 = '已发布' OR 普通流程 = '已分配' OR 普通流程 = '无'";
            DataSet ds = MySQL_Method.SQLite_search(sql);
            foreach (DataRow row in ds.Tables[0].Rows) {
                F14_AddPlanQuest.comboBox2.Items.Add(row["发布时间"].ToString());
            }

        }

        //先把当天的任务统一编号查出来，在刚开始肯定是get到空的时间，要做个判断,然后在度所有任务，在之前给个判断，重复的标红
        public static void Search_Quest_WhenAddQuest(F14_AddPlanQuest F14_AddPlanQuest, string group, string time)
        {
            F14_AddPlanQuest.listView1.Items.Clear();

            if(time != "") {
                string sql = $"SELECT* FROM 任务发布0{group} WHERE 发布时间 = {time}";
                DataSet ds = MySQL_Method.SQLite_search(sql);

                //接下来查所有任务就行了
                int red_aim = 0;

                string type = F14_AddPlanQuest.comboBox1.Text;
                string keyword = F14_AddPlanQuest.textBox5.Text;
                string sql2 = $"SELECT* FROM 任务信息 WHERE 项目状态 = '未完成' AND 项目分类 = '{type}' AND ( 项目名 LIKE '%{keyword}%' OR 编制部门 LIKE '%{keyword}%' OR 统一编号 LIKE '%{keyword}%') AND 是否隐藏 = '否'";
                DataSet ds2 = MySQL_Method.SQLite_search(sql2);

                foreach (DataRow row2 in ds2.Tables[0].Rows) {
                    ListViewItem first = new ListViewItem(row2["统一编号"].ToString());
                    first.SubItems.Add(row2["项目名"].ToString());
                    first.SubItems.Add(row2["项目分类"].ToString());

                    F14_AddPlanQuest.listView1.Items.Add(first);

                    //匹配并标红
                    foreach (DataRow row in ds.Tables[0].Rows) {
                        if (row2["统一编号"].ToString() == row["统一编号"].ToString()) {
                            F14_AddPlanQuest.listView1.Items[red_aim].SubItems[0].ForeColor = Color.Red;
                        }
                    }
                    red_aim++;
                }
            }

        }


        //在追加任务的时候，录入任务发布，要分两个班组
        public static void Add_Publish_WhenAddQuest(string time, string num, string group)
        {
            string sql = $"insert into [任务发布0{group}](发布时间,统一编号,完成情况,是否分配)values({time},'{num}','未完成','没有分配')";
            DataSet ds = MySQL_Method.SQLite_search(sql);
        }





        /******************************    F19-权限  *******************************************/
        public static void Refresh_OfPower(F19_Power F19_Power)
        {
            F19_Power.listView1.Items.Clear();
            //查询所有员工的信息
            string sql = "SELECT* FROM 权限";
            DataSet ds = MySQL_Method.SQLite_search(sql);

            foreach (DataRow row in ds.Tables[0].Rows) {
                ListViewItem first = new ListViewItem(row["账号"].ToString());
                first.SubItems.Add(row["密码"].ToString());
                first.SubItems.Add(row["用户类型"].ToString());

                F19_Power.listView1.Items.Add(first);
            }
        }


        /******************************    F20-新版填工时界面  *******************************************/


        //在新版填报工时界面，读取当日的备注
        public static void WriteTodayNotes_WhenNewReport(F20_New_Report F20_New_Report, string time, string num_quest, string group)
        {
            string sql = $"SELECT* FROM 任务发布0{group} WHERE 发布时间 ={time} AND 统一编号 = '{num_quest}'";
            DataSet ds = MySQL_Method.SQLite_search(sql);
            if (ds.Tables[0].Rows.Count >= 1) {
                F20_New_Report.textBox8.Text = ds.Tables[0].Rows[0]["当日备注"].ToString();
            }

        }

        //在新版填报工时界面，读取当日的分配人员到列表中
        public static void SearchWorkerInThisQuest_WhenNewReport(F20_New_Report F20_New_Report, string time, string num_quest, string group)
        {
            F20_New_Report.listView8.Items.Clear();
            string sql = $"SELECT* FROM 任务分配0{group} INNER JOIN 员工信息 ON 任务分配0{group}.工号 = 员工信息.工号 WHERE 发布时间 ={time} AND 统一编号 = '{num_quest}' AND 工作类型 = '（分配标记）'";
            DataSet ds = MySQL_Method.SQLite_search(sql);
            if (ds.Tables[0].Rows.Count >= 1) {
                foreach (DataRow row in ds.Tables[0].Rows) {
                    ListViewItem first = new ListViewItem(row["工号"].ToString());
                    first.SubItems.Add(row["姓名"].ToString());

                    F20_New_Report.listView8.Items.Add(first);
                }
            }
        }

        //在新版填报工时界面，读取现在的工时情况并放进表格
        public static void SearchNowWorkTime_WhenNewReport(F20_New_Report F20_New_Report, string time, string num_quest, string group)
        {
            F20_New_Report.dataGridView5.Rows.Clear();
            string sql = $"SELECT* FROM 任务分配0{group} INNER JOIN 员工信息 ON 任务分配0{group}.工号 = 员工信息.工号 WHERE 发布时间 ={time} AND 统一编号 = '{num_quest}' AND 工作类型 = '废弃属性'";
            DataSet ds = MySQL_Method.SQLite_search(sql);
            if (ds.Tables[0].Rows.Count >= 1) {
                foreach (DataRow row in ds.Tables[0].Rows) {
                    string Hours = row["工作小时"].ToString();
                    string Radio = row["工时系数"].ToString();

                    F20_New_Report.dataGridView5.Rows.Add(row["工号"].ToString(), row["姓名"].ToString(), Radio, Hours);
                }
            }
        }

        //在新版填报工时界面，在点击确定时先删除所有信息
        public static void DeleteAllInfoInThisQuest_WhenNewReport(F20_New_Report F20_New_Report, string time, string num_quest, string group)
        {
            string sql = $"DELETE FROM 任务分配0{group} WHERE 统一编号 = '{num_quest}' AND 发布时间 = {time} AND 工作类型 = '废弃属性'";
            MySQL_Method.SQLite_delete(sql);

        }

    }
}
