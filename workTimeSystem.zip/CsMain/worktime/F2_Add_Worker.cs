﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace worktime
{
    public partial class F2_Add_Worker : Form
    {
        public F2_Add_Worker()
        {
            InitializeComponent();
        }

        private void F2_Add_Worker_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            label3.Text = "试验班";
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            label3.Text = "试制班";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string num = textBox1.Text;
            //正则判断工号是否为纯数字
            if (MyRegular_Method.Pure_Number(num) == true) {
                //1.先查询并判断是否是隐藏的。2.若隐藏则恢复;若非隐藏则添加。
                if (MyOtherWin_Method.Judge_WhetherHideWorker(num) == true) {
                    if (MessageBox.Show("查找到该工号曾被删除，是否恢复该工号相关信息\r\n由于工号具有唯一性，建议恢复，若工号错误可以重新删除；若名称改变可以双击修改。", "Confirm Message", MessageBoxButtons.OKCancel) == DialogResult.OK) {
                        MyOtherWin_Method.Recovery_HidedWorker(num);//恢复被隐藏的
                        this.Close();
                    }
                }
                else {
                    try {
                        MyOtherWin_Method.Add_NewWorker(num, textBox2.Text, label3.Text);
                        this.Close();
                    }
                    catch {
                        MessageBox.Show("工号重复。");
                    }
                }
            }
            else {
                MessageBox.Show("请保证工号为纯数字。");
            }
        }
    }
}
