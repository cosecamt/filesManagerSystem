﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace worktime
{
    public partial class F6_4_Change_WhenWork_Another : Form
    {
        public F6_4_Change_WhenWork_Another()
        {
            InitializeComponent();
        }

        public F6_4_Change_WhenWork_Another(string num, string time, string quest, string group)
        {
            InitializeComponent();
            label2.Text = num;
            label4.Text = time;
            label5.Text = quest;
            label7.Text = group;
        }

        private void F6_4_Change_WhenWork_Another_Load(object sender, EventArgs e)
        {
            string num = label2.Text;
            string time = label4.Text;
            MyOtherWin_Method.Read_ChangeSurfaceLoad_WhenWriteWorkTime(this, num, time, label7.Text);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string time = label4.Text;
            string num = label2.Text;
            string quest = label5.Text;
            string group = label7.Text;

            //先遍历所有没有勾选的
            //对每一个没被勾选的人删除相关，不用查了，直接删，管他原本有没有
            for (int i = 0; i < dataGridView1.Rows.Count; i++) {
                if (dataGridView1.Rows[i].Cells[0].Value.ToString() == "False") {
                    string worker_num = dataGridView1.Rows[i].Cells[1].Value.ToString();
                    MyOtherWin_Method.Del_DistributePlan(time, num, worker_num, group);
                }
            }

            //遍历所有勾选的
            //对于每一个勾选的人，查表，看看存不存在，
            for (int i = 0; i < dataGridView1.Rows.Count; i++) {
                if (dataGridView1.Rows[i].Cells[0].Value.ToString() == "True") {
                    string worker_num = dataGridView1.Rows[i].Cells[1].Value.ToString();
                    bool Reslut_OfSearch =  MyOtherWin_Method.Search_DistributePlan(time, num, worker_num, group);
                    //存在的不处理
                    //不存在的，添加
                    if (Reslut_OfSearch == false) {
                        MyOtherWin_Method.Add_NewDistributePlan(time, num, worker_num, group);
                    }
                }
            }


            this.Close();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString() == "True") {
                dataGridView1.Rows[e.RowIndex].Cells[0].Value = false;
            }
            else {
                dataGridView1.Rows[e.RowIndex].Cells[0].Value = true;
            }
        }
    }
}
