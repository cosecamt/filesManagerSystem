﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Data.SQLite;
using System.Data.Common;
using System.Diagnostics;
using System.IO;

namespace worktime
{
    public partial class F1_Main : Form
    {
        public F1_Main()
        {
            InitializeComponent();
        }

        private void F1_Main_Load(object sender, EventArgs e)
        {
            //默认工时系数
            comboBox3.SelectedIndex = comboBox3.Items.IndexOf(MyIni_Method.getString("DefaultRadio", "Radio", "", @"data\setting.ini"));
            MyConstant_1.DefaultWorkRadio = comboBox3.Text;
            //填报工时的窗口开始要隐藏掉
            dataGridView7.Visible = false;
            dataGridView8.Visible = false;
            //让前两列不能被修改
            dataGridView7.Columns[1].ReadOnly = true;
            dataGridView7.Columns[0].ReadOnly = true;
            dataGridView8.Columns[1].ReadOnly = true;
            dataGridView8.Columns[0].ReadOnly = true;

            dataGridView7.Columns[1].DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            dataGridView7.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dataGridView8.Columns[1].DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            dataGridView8.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;


            连接数据库ToolStripMenuItem.Enabled = false;
            删除人员和项目以外的所有ToolStripMenuItem.Enabled = false;

            this.Text = "生产管理系统-V3.4-Beta-" + MyConstant_1.now_group;

            //吧所有页面全都刷新
            dataGridView1.Rows.Clear();
            dataGridView4.Rows.Clear();
            listView4.Items.Clear();
            dataGridView5.Rows.Clear();
            listView5.Items.Clear();
            listView6.Items.Clear();
            listView7.Items.Clear();
            dataGridView2.Rows.Clear();
            dataGridView3.Rows.Clear();

            //分两部分就行了，是管理员和不是管理员
            //结果现在有了第三部分，技术组
            if (MyConstant_1.now_group == "管理员") {//管理员的情况
                //1.读取的情况
                try {
                    MyMain_Method.Refrash_WhenSoftStart(this);  //总体的刷新，所有的刷新
                }
                catch {
                    Process proc = Process.Start(@"z:\");
                    //MySystem_Method.Find_File();
                    MyMain_Method.Refrash_WhenSoftStart(this);  //总体的刷新，所有的刷新
                }

                //2.隐藏功能的情况
                //分配页面
                button34.Visible = false;
                button29.Visible = false;
                button7.Visible = false;

                //今日任务界面
                button28.Visible = false;
                button16.Visible = false;
                button19.Visible = false;
                button10.Visible = false;
                button6.Visible = false;

                //不让管理员填工时
                dataGridView7.Columns[2].ReadOnly = true;
                dataGridView8.Columns[2].ReadOnly = true;

                //待审核界面
                button37.Visible = false;
            }
            else if (MyConstant_1.now_group == "技术组") {//技术组的情况
                                                       //1.读取的情况
                try {
                    MyMain_Method.Refrash_WhenSoftStart(this);  //总体的刷新，所有的刷新
                }
                catch {
                    Process proc = Process.Start(@"z:\");
                    //MySystem_Method.Find_File();
                    MyMain_Method.Refrash_WhenSoftStart(this);  //总体的刷新，所有的刷新
                }

                //2.隐藏功能的情况
                //账号管理隐藏
                账号管理ToolStripMenuItem.Visible = false;

                //今日任务界面
                button28.Visible = false;
                button16.Visible = false;
                button19.Visible = false;
                button10.Visible = false;
                button6.Visible = false;

                //分配页面
                button34.Visible = false;
                button29.Visible = false;
                button7.Visible = false;

                //台架页面
                button27.Visible = false;

                //待审核界面
                button37.Visible = false;
                button33.Visible = false;
                button8.Visible = false;
                button18.Visible = false;
                button26.Visible = false;

                //项目总览
                button1.Visible = false;
                button4.Visible = false;
                button13.Visible = false;

                //人员信息
                button31.Visible = false;
                button30.Visible = false;
                button2.Visible = false;
                button3.Visible = false;


                //不让管理员填工时
                dataGridView7.Columns[2].ReadOnly = true;
                dataGridView8.Columns[2].ReadOnly = true;

                //吧任务分配去掉
                this.tabControl1.Controls["tabPage12"].Parent = null;
                this.tabControl1.Controls["tabPage2"].Parent = null;


            }
            else {//班组的情况
                  //1.读取的情况
                  //comboBox1.SelectedIndex = comboBox1.Items.IndexOf("TDM");//项目分类默认TDM

                //MyMain_Method.Read_WorkerList(this);//读取人员信息
                //MyMain_Method.Read_Quest_ByLimit(this);//读取任务信息（根据限制条件，初始当然是TDM）

                //MyMain_Method.Read_DraftList(this);//读取“已起草”的日期列表
                try {
                    MyMain_Method.Read_Distribute_DateList(this);//（班组功能）读取“任务分配”日期列表（分试验班和试制班和管理员）
                    MyMain_Method.Read_TodayQuestList(this);//（班组功能）读取“当日任务”的日期列表（分试验班和试制班和管理员）
                    MyMain_Method.Read_TodayQuestList_Bench(this);//（班组功能）读取“台架试验”列表
                    MyMain_Method.Read_ListOfJudging(this);//（班组功能）读取“历史记录”中“未审核”的日期列表（分试验班和试制班和管理员）

                }
                catch {
                    Process proc = Process.Start(@"z:\");
                    //MySystem_Method.Find_File();

                    MyMain_Method.Read_Distribute_DateList(this);//（班组功能）读取“任务分配”日期列表（分试验班和试制班和管理员）
                    MyMain_Method.Read_TodayQuestList(this);//（班组功能）读取“当日任务”的日期列表（分试验班和试制班和管理员）
                    MyMain_Method.Read_TodayQuestList_Bench(this);//（班组功能）读取“台架试验”列表
                    MyMain_Method.Read_ListOfJudging(this);//（班组功能）读取“历史记录”中“未审核”的日期列表（分试验班和试制班和管理员）

                }

                //MyMain_Method.Search_DataExtent(this);//确定数据库记录范围，并填写到历史记录和数据分析的部分
                //MyMain_Method.WriteIn_TodayYearAndMonth(this); //在历史记录的“已审核”页面预先填入今天的年、月-也把已完成任务部分一起初始化一下
                //MyMain_Method.Read_JudgedList(this, textBox3.Text, textBox4.Text);//读取历史记录中“已审核”的事件列表并显示（只有管理员）
                //MyMain_Method.Read_Quest_HasDone(this, textBox9.Text, textBox8.Text);//读取已经完成的任务,由于需要使用到时间参数，所以最后读取

                //2.隐藏功能的情况
                this.tabControl1.Controls["tabPage12"].Parent = null;
                this.tabControl1.Controls["tabPage3"].Parent = null;
                this.tabControl1.Controls["tabPage4"].Parent = null;
                this.tabControl1.Controls["tabPage6"].Parent = null;

                this.tabControl3.Controls["tabPage10"].Parent = null;

                //接下来是隐藏控件
                //未审核页面
                button33.Visible = false;
                button8.Visible = false;
                button18.Visible = false;
                button26.Visible = false;

                //台架页面
                button27.Visible = false;

                //账号管理隐藏
                账号管理ToolStripMenuItem.Visible = false;
            }

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            MyMain_Method.Read_Quest_ByLimit(this);//按条件读取任务信息
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            MyMain_Method.Read_Quest_ByLimit(this);//按条件读取任务信息
        }

        private void button2_Click(object sender, EventArgs e)
        {
            F2_Add_Worker F2_Add_Worker = new F2_Add_Worker();
            F2_Add_Worker.ShowDialog();
            MyMain_Method.Read_WorkerList(this);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (listView1.FocusedItem != null) {
                string num = listView1.FocusedItem.SubItems[0].Text;
                MyMain_Method.Delete_ThisWorker(num);
                MyMain_Method.Read_WorkerList(this);
            }
            else {
                MessageBox.Show("请先选择需要删除的目标");
            }
        }

        private void listView1_DoubleClick(object sender, EventArgs e)
        {
            if (listView1.FocusedItem != null) {
                string num = listView1.FocusedItem.Text;
                F3_Change_Worker F3_Change_Worker = new F3_Change_Worker(num);
                F3_Change_Worker.ShowDialog();
                MyMain_Method.Read_WorkerList(this);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            F4_Add_Quest F4_Add_Quest = new F4_Add_Quest();
            F4_Add_Quest.ShowDialog();
            MyMain_Method.Read_Quest_ByLimit(this);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("确定要删除此条信息么？", "Confirm Message", MessageBoxButtons.OKCancel) == DialogResult.OK) {
                if (listView2.FocusedItem != null) {
                    string num = listView2.FocusedItem.SubItems[0].Text;
                    MyMain_Method.Delete_ThisQuest(num);
                    MyMain_Method.Read_Quest_ByLimit(this);
                }
                else {
                    MessageBox.Show("请先选择需要删除的目标");
                }
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            if (listView2.FocusedItem != null) {
                string num = listView2.FocusedItem.Text;
                F4_2_Change_quest F4_2_Change_quest = new F4_2_Change_quest(num);
                F4_2_Change_quest.ShowDialog();
                MyMain_Method.Read_Quest_ByLimit(this);
            }

        }

        private void listView2_DoubleClick(object sender, EventArgs e)
        {
            string num = listView2.FocusedItem.Text;
            F4_3_Quest_Ansys F4_3_Quest_Ansys = new F4_3_Quest_Ansys(num);
            F4_3_Quest_Ansys.ShowDialog();
            MyMain_Method.Read_Quest_HasDone(this, textBox9.Text, textBox8.Text);//读取已经完成的任务
            MyMain_Method.Read_Quest_ByLimit(this);//读取未经完成的任务
        }

        private void button14_Click(object sender, EventArgs e)
        {
            textBox5.Text = "";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            /*
            F5_Publish F5_Publish = new F5_Publish("试验班");
            F5_Publish.ShowDialog();
            MyMain_Method.Read_Distribute_DateList(this);
            */
        }

        private void listBox1_MouseClick(object sender, MouseEventArgs e)
        {
            listView4.Items.Clear();
            try {
                string time = MyTools_Method.Date_ToNum(listBox1.SelectedItem.ToString()).ToString();
                if (MyConstant_1.now_group == "管理员" || MyConstant_1.now_group == "技术组") {
                    if (listBox1.SelectedItem.ToString().Contains("试验") == true) {
                        MyMain_Method.Read_DistributeResult(this, time, "试验班");
                    }
                    else if (listBox1.SelectedItem.ToString().Contains("试制") == true) {
                        MyMain_Method.Read_DistributeResult(this, time, "试制班");
                    }
                    else {
                        listView4.Items.Clear();
                        dataGridView5.Rows.Clear();
                    }
                }
                else {
                    MyMain_Method.Read_DistributeResult(this, time, MyConstant_1.now_group);
                }

            }
            catch {
                listView4.Items.Clear();
                dataGridView5.Rows.Clear();
            }
        }

        private void listView4_MouseClick(object sender, MouseEventArgs e)
        {
            string num = listView4.FocusedItem.SubItems[0].Text;
            string time = MyTools_Method.Date_ToNum(listBox1.SelectedItem.ToString()).ToString();

            if (MyConstant_1.now_group == "管理员") {
                if (listBox1.SelectedItem.ToString().Contains("试验")) {
                    //MyMain_Method.Read_InfoOf_ThisTodayQuest(time, num, "试验班", this);
                    //MyMain_Method.Read_Distribute_Reslt(this, num, time, "试验班");
                    MyMain_Method.Read_DistributeResltAnd_QuestInfo(this, num, time, "试验班");
                }
                else {
                    //MyMain_Method.Read_InfoOf_ThisTodayQuest(time, num, "试制班", this);
                    //MyMain_Method.Read_Distribute_Reslt(this, num, time, "试制班");
                    MyMain_Method.Read_DistributeResltAnd_QuestInfo(this, num, time, "试制班");
                }
            }
            else {
                //MyMain_Method.Read_InfoOf_ThisTodayQuest(time, num, MyConstant_1.now_group, this);
                //MyMain_Method.Read_Distribute_Reslt(this, num, time, MyConstant_1.now_group);
                MyMain_Method.Read_DistributeResltAnd_QuestInfo(this, num, time, MyConstant_1.now_group);
            }
        }

        private void listView4_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            /*
            string num = listView4.FocusedItem.SubItems[0].Text;
            string quest = listView4.FocusedItem.SubItems[1].Text;
            string time = MyTools_Method.Date_ToNum(listBox1.SelectedItem.ToString()).ToString();
            string worker = listView4.FocusedItem.SubItems[2].Text;

            if (worker == "（未设置）")//若符合，则进入新增安排的窗口
            {
                if (MyConstant_1.now_group == "管理员")//其实不应该做管理员的功能的，他应该没有权限
                {
                    if (listBox1.SelectedItem.ToString().Contains("试验") == true) {
                        F6_Dis F6_Dis = new F6_Dis(num, time, quest, "试验班");
                        F6_Dis.ShowDialog();
                        MyMain_Method.Read_DistributeResult(this, time, "试验班");
                    }
                    else {
                        F6_Dis F6_Dis = new F6_Dis(num, time, quest, "试制班");
                        F6_Dis.ShowDialog();
                        MyMain_Method.Read_DistributeResult(this, time, "试制班");
                    }
                }
                else {
                    F6_Dis F6_Dis = new F6_Dis(num, time, quest, MyConstant_1.now_group);
                    F6_Dis.ShowDialog();
                    MyMain_Method.Read_DistributeResult(this, time, MyConstant_1.now_group);
                }
            }
            else//否则 ，进入修改安排的窗口
            {
                if (MyConstant_1.now_group == "管理员") {
                    if (listBox1.SelectedItem.ToString().Contains("试验") == true) {
                        F6_2_Change_Dis F6_2_Change_Dis = new F6_2_Change_Dis(num, time, quest, "试验班");
                        F6_2_Change_Dis.ShowDialog();
                        MyMain_Method.Read_DistributeResult(this, time, "试验班");
                    }
                    else {
                        F6_2_Change_Dis F6_2_Change_Dis = new F6_2_Change_Dis(num, time, quest, "试制班");
                        F6_2_Change_Dis.ShowDialog();
                        MyMain_Method.Read_DistributeResult(this, time, "试制班");
                    }
                }
                else {
                    F6_2_Change_Dis F6_2_Change_Dis = new F6_2_Change_Dis(num, time, quest, MyConstant_1.now_group);
                    F6_2_Change_Dis.ShowDialog();
                    MyMain_Method.Read_DistributeResult(this, time, MyConstant_1.now_group);
                }
            }*/
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (MyConstant_1.now_group != "管理员") {
                //先看看是不是所有任务都分配了
                int tep = 1;
                foreach (ListViewItem item in listView4.Items) {
                    string now = item.SubItems[2].Text;
                    if (now == "（未设置）") {
                        tep = 0;
                    }
                }

                //然后改一下流程就行了，要注意一下，由于管理员没有分配的权限，所以这里不需要考虑管理员
                if (tep == 1) {
                    try {
                        string time = listBox1.SelectedItem.ToString();
                        time = MyTools_Method.Date_ToNum(time).ToString();
                        if (MessageBox.Show($"确定{time}的工作已经分配完毕了么？", "Confirm Message", MessageBoxButtons.OKCancel) == DialogResult.OK) {
                            try {
                                //打标记，让他被标记为完成分配

                                //事务写入开始                       
                                SQLiteConnection connect = new SQLiteConnection(MyConstant_1.conStr);
                                connect.Open();
                                DbTransaction trans = connect.BeginTransaction();
                                foreach (ListViewItem item in listView4.Items) {
                                    string mark_num = item.SubItems[0].Text;
                                    string sql9 = $"UPDATE 任务发布0{MyConstant_1.now_group} SET 是否分配 = '完成分配' WHERE 发布时间 = {time} AND 统一编号 = '{mark_num}'";
                                    SQLiteCommand cmd = new SQLiteCommand(sql9, connect);
                                    cmd.ExecuteNonQuery();
                                }
                                trans.Commit();
                                connect.Close();
                                //事务写入结束      

                                listView4.Items.Clear();
                                listBox1.Items.Clear();
                                MyMain_Method.Change_TodayHasDistributed(time);
                                MyMain_Method.Read_Distribute_DateList(this);//读取“任务分配”日期列表（分试验班和试制班和管理员）

                            }
                            catch {
                                MessageBox.Show("请至少分配一个人员");
                            }
                        }
                    }
                    catch {
                        MessageBox.Show("请先选择一项");
                    }
                }
                else {
                    MessageBox.Show("请为所有的任务都指派人员");
                }
            }


        }

        private void listBox2_MouseClick(object sender, MouseEventArgs e)
        {

            this.dataGridView1.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            this.dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;

            dataGridView1.Rows.Clear();

            try {
                string time = MyTools_Method.Date_ToNum(listBox2.SelectedItem.ToString()).ToString();
                if (MyConstant_1.now_group == "管理员" || MyConstant_1.now_group == "技术组") {
                    if (listBox2.SelectedItem.ToString().Contains("试验班") == true) {
                        MyMain_Method.Read_TodayQuest(this, time, "试验班");
                    }
                    else {
                        MyMain_Method.Read_TodayQuest(this, time, "试制班");
                    }
                }
                else {
                    MyMain_Method.Read_TodayQuest(this, time, MyConstant_1.now_group);
                }

            }
            catch { }

            this.dataGridView6.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            this.dataGridView6.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;

            dataGridView6.Rows.Clear();

            try {
                string time = MyTools_Method.Date_ToNum(listBox2.SelectedItem.ToString()).ToString();
                if (MyConstant_1.now_group == "管理员") {
                    if (listBox2.SelectedItem.ToString().Contains("试验班") == true) {
                        MyMain_Method.Read_TodayQuest_ForEachWorker(this, time, "试验班");
                    }
                    else {
                        MyMain_Method.Read_TodayQuest_ForEachWorker(this, time, "试制班");
                    }
                }
                else {
                    MyMain_Method.Read_TodayQuest_ForEachWorker(this, time, MyConstant_1.now_group);
                }

            }
            catch { }
                                  
        }

        private void dataGridView1_MouseClick(object sender, MouseEventArgs e)
        {
            /*
            //先显示任务信息
            try {
                string time = MyTools_Method.Date_ToNum(listBox2.SelectedItem.ToString()).ToString();
                string num = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                MyMain_Method.TodayQuest_ThisInfo(this, num, time);
            }
            catch { return; }
            */

            //先显示任务信息——富文本
            try {
                string time = MyTools_Method.Date_ToNum(listBox2.SelectedItem.ToString()).ToString();
                string num = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                MyMain_Method.TodayQuest_ThisInfo_InRichTextBox(this, num, time);
            }
            catch { return; }


            //右边要显示工时填写的信息
            //管理员不能报工时，不给他权限
            if (dataGridView1.CurrentRow.Cells[2].Value.ToString() == "(无)") {
                MessageBox.Show("请先分配人员在进行工时填写");
                return;
            }
            try {
                string time = MyTools_Method.Date_ToNum(listBox2.SelectedItem.ToString()).ToString();
                string name = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                string num = dataGridView1.CurrentRow.Cells[0].Value.ToString();

                dataGridView8.Rows.Clear();

                if (MyConstant_1.now_group != "管理员") {

                    MyMain_Method.Read_WorkTime_ForThisQuest(this, time, num, MyConstant_1.now_group);
                }
                else {
                    if (listBox2.SelectedItem.ToString().Contains("试验") == true) {
                        MyMain_Method.Read_WorkTime_ForThisQuest(this, time, num, "试验班");
                    }
                    else {
                        MyMain_Method.Read_WorkTime_ForThisQuest(this, time, num, "试制班");
                    }
                }

                dataGridView8.Visible = true;
            }
            catch { }
            


        }

        private void dataGridView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (MyConstant_1.now_group == "技术组" || MyConstant_1.now_group == "管理员") {
                return;
            }

            //管理员不能报工时，不给他权限
            if (dataGridView1.CurrentRow.Cells[2].Value.ToString() == "(无)") {
                MessageBox.Show("请先分配人员在进行工时填写");
                return;
            }

            string time = MyTools_Method.Date_ToNum(listBox2.SelectedItem.ToString()).ToString();

            string name = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            string num_quest = dataGridView1.CurrentRow.Cells[0].Value.ToString();

            string complete = dataGridView1.CurrentRow.Cells[3].Value.ToString();


            /*
            if (MyConstant_1.now_group != "管理员") {
                if (complete == "（未填报）") {
                    F7_Report F7_Report = new F7_Report(time, name, num, MyConstant_1.now_group);
                    F7_Report.ShowDialog();
                    MyMain_Method.Read_TodayQuest(this, time, MyConstant_1.now_group);
                }
                else {
                    F7_2_Change_Report F7_2_Change_Report = new F7_2_Change_Report(time, name, num, MyConstant_1.now_group);
                    F7_2_Change_Report.ShowDialog();
                    MyMain_Method.Read_TodayQuest(this, time, MyConstant_1.now_group);
                }
            }
            */
            if (MyConstant_1.now_group != "管理员") {
                F20_New_Report F20_New_Report = new F20_New_Report(time, name, num_quest, MyConstant_1.now_group);
                F20_New_Report.ShowDialog();
                MyMain_Method.Read_TodayQuest(this, time, MyConstant_1.now_group);
            }



        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (listBox2.SelectedItem != null) {
                string time = MyTools_Method.Date_ToNum(listBox2.SelectedItem.ToString()).ToString();
                F8_holiday F8_holiday = new F8_holiday(time);
                F8_holiday.ShowDialog();
            }

        }

        private void button9_Click(object sender, EventArgs e)
        {
            try {
                string time = MyTools_Method.Date_ToNum(listBox2.SelectedItem.ToString()).ToString();

                if (MyConstant_1.now_group == "管理员") {
                    if (listBox2.SelectedItem.ToString().Contains("试验班")) {
                        F10_Today_View F10_Today_View = new F10_Today_View(time, "试验班");
                        F10_Today_View.ShowDialog();
                    }
                    else {
                        F10_Today_View F10_Today_View = new F10_Today_View(time, "试制班");
                        F10_Today_View.ShowDialog();
                    }
                }
                else {
                    F10_Today_View F10_Today_View = new F10_Today_View(time, MyConstant_1.now_group);
                    F10_Today_View.ShowDialog();
                }
            }
            catch { }
        }

        private void button16_Click(object sender, EventArgs e)
        {
            try {
                if (listBox2.SelectedItem.ToString() != "###############") {
                    try {
                        string time = listBox2.SelectedItem.ToString();
                        F12_1_Today_Add_New F12_1_Today_Add_New = new F12_1_Today_Add_New(time);
                        F12_1_Today_Add_New.ShowDialog();

                        MyMain_Method.Read_TodayQuest(this, MyTools_Method.Date_ToNum(time).ToString(), MyConstant_1.now_group);
                    }
                    catch { }
                }
            }
            catch { }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            try {
                string time = MyTools_Method.Date_ToNum(listBox2.SelectedItem.ToString()).ToString();
                //要注意一下是否当日发布都是“完成分配”，否则可能会导致补发任务没有进来
                string sql = $"SELECT * FROM 任务发布0{MyConstant_1.now_group} WHERE 发布时间 = {time} AND 是否分配 <> '完成分配'";
                DataSet ds = MySQL_Method.SQLite_search(sql);
                if (ds.Tables[0].Rows.Count == 0) {
                    if (MessageBox.Show($"确定{time}的工作已经填报完毕了么？", "Confirm Message", MessageBoxButtons.OKCancel) == DialogResult.OK) {
                        try {
                            MyMain_Method.Change_ToSubmit(time);
                            MyMain_Method.Read_TodayQuestList(this);
                            MyMain_Method.Read_ListOfJudging(this);
                            this.dataGridView1.Rows.Clear();
                        }
                        catch {
                            MessageBox.Show("请先选择一项");
                        }
                    }
                }
                else {
                    MessageBox.Show("有补发任务没有填写");
                }


            }
            catch {
                MessageBox.Show("请先选择一项");
            }
        }

        private void listBox3_MouseClick(object sender, MouseEventArgs e)
        {

            this.dataGridView2.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            this.dataGridView2.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dataGridView2.Rows.Clear();
            try {
                string time = MyTools_Method.Date_ToNum(listBox3.SelectedItem.ToString()).ToString();

                if (MyConstant_1.now_group == "管理员" || MyConstant_1.now_group == "技术组") {
                    if (listBox3.SelectedItem.ToString().Contains("试验班") == true) {
                        MyMain_Method.Read_JudgingQuestInfo(this, time, "试验班");
                        MyMain_Method.Read_JudgingQuestInfo_ByBench(this, time, "试验班");
                        //给label填写，并且让按钮disable
                        MyMain_Method.Look_PocessWhenJudge(this, "试验班", time);
                    }
                    else {
                        MyMain_Method.Read_JudgingQuestInfo(this, time, "试制班");
                        MyMain_Method.Read_JudgingQuestInfo_ByBench(this, time, "试制班");
                        MyMain_Method.Look_PocessWhenJudge(this, "试制班", time);
                    }
                }
                else {
                    MyMain_Method.Read_JudgingQuestInfo(this, time, MyConstant_1.now_group);
                    MyMain_Method.Read_JudgingQuestInfo_ByBench(this, time, MyConstant_1.now_group);
                    MyMain_Method.Look_PocessWhenJudge(this, MyConstant_1.now_group, time);
                }

            }
            catch { }
        }

        private void button17_Click(object sender, EventArgs e)
        {
            try {
                string time = MyTools_Method.Date_ToNum(listBox3.SelectedItem.ToString()).ToString();

                if (MyConstant_1.now_group == "管理员") {
                    if (listBox3.SelectedItem.ToString().Contains("试验班")) {
                        F10_Today_View F10_Today_View = new F10_Today_View(time, "试验班");
                        F10_Today_View.ShowDialog();
                    }
                    else {
                        F10_Today_View F10_Today_View = new F10_Today_View(time, "试制班");
                        F10_Today_View.ShowDialog();
                    }
                }
                else {
                    F10_Today_View F10_Today_View = new F10_Today_View(time, MyConstant_1.now_group);
                    F10_Today_View.ShowDialog();
                }
            }
            catch { }
        }

        private void button18_Click(object sender, EventArgs e)
        {
            if (listBox3.SelectedItem != null) {
                string num = "";
                string time = MyTools_Method.Date_ToNum(listBox3.SelectedItem.ToString()).ToString();

                num = dataGridView2.CurrentRow.Cells[0].Value.ToString();
                F4_3_Quest_Ansys F4_3_Quest_Ansys = new F4_3_Quest_Ansys(num);
                F4_3_Quest_Ansys.ShowDialog();

                try {
                    if (MyConstant_1.now_group == "管理员") {
                        if (listBox1.SelectedItem.ToString().Contains("试验班")) {
                            MyMain_Method.Read_JudgingQuestInfo(this, time, "试验班");
                        }
                        else {
                            MyMain_Method.Read_JudgingQuestInfo(this, time, "试制班");
                        }
                    }
                    else {
                        MyMain_Method.Read_JudgingQuestInfo(this, time, MyConstant_1.now_group);
                    }
                }
                catch { }
            }


        }

        private void dataGridView2_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            string time = MyTools_Method.Date_ToNum(listBox3.SelectedItem.ToString()).ToString();
            string name = dataGridView2.CurrentRow.Cells[1].Value.ToString();
            string num = dataGridView2.CurrentRow.Cells[0].Value.ToString();
            string complete = dataGridView2.CurrentRow.Cells[3].Value.ToString();

            //逻辑可能有点绕，写一下免得我又忘了
            //1.判断权限；
            //2.如果是管理员，那么还要看contains，如果不是就不用看了——这决定了查哪张表；
            //3.接下来看当前项目名是否包含“台架”，如果包含，那之前全作废，从台架的表查；
            //4.我滴娘，还要看看当前状态是不是未完成？
            //顺序不太对，应该最先考虑台架才对。

            if (name.Contains("(台架)") == true) {//是台架的情况
                if (complete == "（未填报）") {//台架未填报的状况
                    F7_3_ReportBench F7_3_ReportBench = new F7_3_ReportBench(time, name, num);
                    F7_3_ReportBench.ShowDialog();
                }
                else {//台架已填报的状况
                    F7_4_Change_ReportBench F7_4_Change_ReportBench = new F7_4_Change_ReportBench(time, name, num);
                    F7_4_Change_ReportBench.ShowDialog();
                }
            }
            else {//不是台架的情况
                if (MyConstant_1.now_group == "管理员") {//是管理员的情况
                    if (listBox3.SelectedItem.ToString().Contains("试验班") == true) {//listbox是试验班
                        if (complete == "（未填报）") {//未填报的状况
                            F7_Report F7_Report = new F7_Report(time, name, num, "试验班");
                            F7_Report.ShowDialog();
                        }
                        else {//已经填报的状况
                            F7_2_Change_Report F7_2_Change_Report = new F7_2_Change_Report(time, name, num, "试验班");
                            F7_2_Change_Report.ShowDialog();
                        }
                    }
                    else {//listbox是试制班
                        if (complete == "（未填报）") {//未填报的状况
                            F7_Report F7_Report = new F7_Report(time, name, num, "试制班");
                            F7_Report.ShowDialog();
                        }
                        else {//已经填报的状况
                            F7_2_Change_Report F7_2_Change_Report = new F7_2_Change_Report(time, name, num, "试制班");
                            F7_2_Change_Report.ShowDialog();
                        }
                    }
                }
                else {//不是管理员的情况
                    if (complete == "（未填报）") {//未填报的状况
                        F7_Report F7_Report = new F7_Report(time, name, num, MyConstant_1.now_group);
                        F7_Report.ShowDialog();
                    }
                    else {//已经填报的状况
                        F7_2_Change_Report F7_2_Change_Report = new F7_2_Change_Report(time, name, num, MyConstant_1.now_group);
                        F7_2_Change_Report.ShowDialog();
                    }
                }
            }

            //全弄完再说读取刷新的事情
            if (MyConstant_1.now_group == "管理员") {
                if (listBox3.SelectedItem.ToString().Contains("试验班") == true) {
                    MyMain_Method.Read_JudgingQuestInfo(this, time, "试验班");
                    MyMain_Method.Read_JudgingQuestInfo_ByBench(this, time, "试验班");
                    //给label填写，并且让按钮disable
                    MyMain_Method.Look_PocessWhenJudge(this, "试验班", time);
                }
                else {
                    MyMain_Method.Read_JudgingQuestInfo(this, time, "试制班");
                    MyMain_Method.Read_JudgingQuestInfo_ByBench(this, time, "试制班");
                    MyMain_Method.Look_PocessWhenJudge(this, "试制班", time);
                }
            }
            else {
                MyMain_Method.Read_JudgingQuestInfo(this, time, MyConstant_1.now_group);
                MyMain_Method.Read_JudgingQuestInfo_ByBench(this, time, MyConstant_1.now_group);
                MyMain_Method.Look_PocessWhenJudge(this, MyConstant_1.now_group, time);
            }


        }

        private void button8_Click(object sender, EventArgs e)
        {
            try {
                string time = MyTools_Method.Date_ToNum(listBox3.SelectedItem.ToString()).ToString();

                //要注意这个是管理员才有的权限，所以不需考虑其他权限的情况
                if (MessageBox.Show($"确定{time}的工作已经审核通过了么？", "Confirm Message", MessageBoxButtons.OKCancel) == DialogResult.OK) {
                    try {
                        if (listBox3.SelectedItem.ToString().Contains("试验班") == true) {
                            MyMain_Method.Change_JudingToJudged(time, "试验班");
                        }
                        else {
                            MyMain_Method.Change_JudingToJudged(time, "试制班");
                        }
                        MyMain_Method.Read_ListOfJudging(this);
                        MyMain_Method.Search_DataExtent(this);
                        MyMain_Method.Read_JudgedList(this, textBox3.Text, textBox4.Text);
                        dataGridView2.Rows.Clear();
                    }
                    catch {
                        MessageBox.Show("这也能报错？未知错误");
                    }
                }
            }
            catch {
                MessageBox.Show("请先选择一项");
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            string year = textBox3.Text;
            string month = textBox4.Text;
            dataGridView3.Rows.Clear();
            MyMain_Method.Read_JudgedList(this, year, month);
        }

        private void listBox4_MouseClick(object sender, MouseEventArgs e)
        {
            dataGridView3.Rows.Clear();
            this.dataGridView3.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            this.dataGridView3.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;

            try {
                string time = MyTools_Method.Date_ToNum(listBox4.SelectedItem.ToString()).ToString();
                if (MyConstant_1.now_group == "管理员" || MyConstant_1.now_group == "技术组") {
                    if (listBox4.SelectedItem.ToString().Contains("试验班") == true) {
                        MyMain_Method.Read_ResultOf_JudgedQuest(this, time, "试验班");
                        MyMain_Method.Read_ResultOf_JudgedQuest_ByBench(this, time, "试验班");
                    }
                    else {
                        MyMain_Method.Read_ResultOf_JudgedQuest(this, time, "试制班");
                        MyMain_Method.Read_ResultOf_JudgedQuest_ByBench(this, time, "试制班");
                    }
                }
                else {
                    MyMain_Method.Read_ResultOf_JudgedQuest(this, time, MyConstant_1.now_group);
                    MyMain_Method.Read_ResultOf_JudgedQuest_ByBench(this, time, MyConstant_1.now_group);
                }

            }
            catch { }
        }

        private void button19_Click(object sender, EventArgs e)
        {
            /*
            F5_2_Publish_Bench F5_2_Publish_Bench = new F5_2_Publish_Bench();
            F5_2_Publish_Bench.ShowDialog();
            //MyMain_Method.Read_Distribute_DateList(this);
            */
        }

        private void button15_Click(object sender, EventArgs e)
        {
            /*
            F5_Publish F5_Publish = new F5_Publish("试制班");
            F5_Publish.ShowDialog();
            MyMain_Method.Read_Distribute_DateList(this);
            */
        }

        private void button20_Click(object sender, EventArgs e)
        {
            MyMain_Method.Read_Quest_HasDone(this, textBox9.Text, textBox8.Text);//读取已经完成的任务,由于需要时间参数，所以最后读取
        }

        private void button23_Click(object sender, EventArgs e)
        {
            if (listBox6.SelectedItem != null) {
                string time = MyTools_Method.Date_ToNum(listBox6.SelectedItem.ToString()).ToString();
                F5_Publish F5_Publish = new F5_Publish("试验班", time);
                F5_Publish.ShowDialog();
                MyMain_Method.Read_DraftQuest_SY(this, time);//读取试验
            }

        }

        private void button24_Click(object sender, EventArgs e)
        {
            if (listBox6.SelectedItem != null) {
                string time = MyTools_Method.Date_ToNum(listBox6.SelectedItem.ToString()).ToString();
                //发布任务，但是要判断有没有任务列表里是没有任务的，那样的部分不能变为“已发布”，要变为“无”
                //先来试验班
                if (listView5.Items.Count >= 1) {
                    MyMain_Method.ChangeProcess_WhenPubished(this, time, "试验班");
                }
                else {
                    MyMain_Method.ChangeProcess_WhenPubished_ButNoQuest(this, time, "试验班");
                }
                //再来试制班
                if (listView6.Items.Count >= 1) {
                    MyMain_Method.ChangeProcess_WhenPubished(this, time, "试制班");
                }
                else {
                    MyMain_Method.ChangeProcess_WhenPubished_ButNoQuest(this, time, "试制班");
                }
                //最后台架比较特殊单独来
                if (listView7.Items.Count >= 1) {
                    MyMain_Method.ChangeProcess_Bench_WhenPubished(this, time);
                }
                else {
                    MyMain_Method.ChangeProcess_Bench_WhenPubished_ButNoQuest(this, time);
                }
                //刷新一下列表
                MyMain_Method.Read_DraftList(this);//读取已起草的日期列表
            }

        }

        private void button25_Click(object sender, EventArgs e)
        {
            F13_NewDaily F13_NewDaily = new F13_NewDaily();
            F13_NewDaily.ShowDialog();
            MyMain_Method.Read_DraftList(this);//读取“已起草”的日期列表

        }

        private void listBox6_MouseClick(object sender, MouseEventArgs e)
        {
            //读取三个listview，分开写，方便后面的更新工作
            //先写试制
            if (listBox6.SelectedItem != null) {
                string time = MyTools_Method.Date_ToNum(listBox6.SelectedItem.ToString()).ToString();
                MyMain_Method.Read_DraftQuest_SY(this, time);//读取试验
                MyMain_Method.Read_DraftQuest_SZ(this, time);//读取试制
                MyMain_Method.Read_DraftQuest_TJ(this, time);//读取台架
                MyMain_Method.Read_BenchWorker_InPublish(this, time);//读取台架值班人员
                MyMain_Method.Read_BenchWorker_Today_WhenpublishList(this, time);//刷新值班人员选择
            }

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {


        }

        private void button22_Click(object sender, EventArgs e)
        {
            if (listBox6.SelectedItem != null) {
                string time = MyTools_Method.Date_ToNum(listBox6.SelectedItem.ToString()).ToString();
                F5_Publish F5_Publish = new F5_Publish("试制班", time);
                F5_Publish.ShowDialog();
                MyMain_Method.Read_DraftQuest_SZ(this, time);//读取试制
            }
        }

        private void button21_Click(object sender, EventArgs e)
        {
            if (listBox6.SelectedItem != null) {
                string time = MyTools_Method.Date_ToNum(listBox6.SelectedItem.ToString()).ToString();
                F5_2_Publish_Bench F5_2_Publish_Bench = new F5_2_Publish_Bench(time);
                F5_2_Publish_Bench.ShowDialog();
                MyMain_Method.Read_DraftQuest_TJ(this, time);//读取台架
            }
        }

        private void listView5_MouseClick(object sender, MouseEventArgs e)
        {
            if (listBox6.SelectedItem != null) {
                string time = MyTools_Method.Date_ToNum(listBox6.SelectedItem.ToString()).ToString();
                string num = listView5.FocusedItem.Text;
                MyMain_Method.Read_QuestInfo_WhenPublish(this, time, num, "试验班");
            }

        }

        private void listView6_MouseClick(object sender, MouseEventArgs e)
        {
            string time = MyTools_Method.Date_ToNum(listBox6.SelectedItem.ToString()).ToString();
            string num = listView6.FocusedItem.Text;
            MyMain_Method.Read_QuestInfo_WhenPublish(this, time, num, "试制班");
        }

        private void listView7_MouseClick(object sender, MouseEventArgs e)
        {
            string time = MyTools_Method.Date_ToNum(listBox6.SelectedItem.ToString()).ToString();
            string num = listView7.FocusedItem.Text;
            MyMain_Method.Read_QuestInfo_WhenPublish_Bench(this, time, num);
        }

        private void 连接数据库ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            F9_data_way F9_data_way = new F9_data_way();
            F9_data_way.ShowDialog();


            //吧所有页面全都刷新
            dataGridView1.Rows.Clear();
            dataGridView4.Rows.Clear();
            listView4.Items.Clear();
            dataGridView5.Rows.Clear();
            listView5.Items.Clear();
            listView6.Items.Clear();
            listView7.Items.Clear();
            dataGridView2.Rows.Clear();
            dataGridView3.Rows.Clear();

            //分两部分就行了，是管理员和不是管理员
            if (MyConstant_1.now_group == "管理员") {//管理员的情况
                //1.读取的情况
                MyMain_Method.Refrash_WhenSoftStart(this);  //总体的刷新，所有的刷新

                //2.隐藏功能的情况
                //分配页面
                button34.Visible = false;
                button29.Visible = false;
                button7.Visible = false;

                //今日任务界面
                button28.Visible = false;
                button16.Visible = false;
                button19.Visible = false;
                button10.Visible = false;
                button6.Visible = false;
            }
            else {//班组的情况
                  //1.读取的情况
                  //comboBox1.SelectedIndex = comboBox1.Items.IndexOf("TDM");//项目分类默认TDM

                //MyMain_Method.Read_WorkerList(this);//读取人员信息
                //MyMain_Method.Read_Quest_ByLimit(this);//读取任务信息（根据限制条件，初始当然是TDM）

                //MyMain_Method.Read_DraftList(this);//读取“已起草”的日期列表
                MyMain_Method.Read_Distribute_DateList(this);//（班组功能）读取“任务分配”日期列表（分试验班和试制班和管理员）
                MyMain_Method.Read_TodayQuestList(this);//（班组功能）读取“当日任务”的日期列表（分试验班和试制班和管理员）
                MyMain_Method.Read_TodayQuestList_Bench(this);//（班组功能）读取“台架试验”列表
                MyMain_Method.Read_ListOfJudging(this);//（班组功能）读取“历史记录”中“未审核”的日期列表（分试验班和试制班和管理员）

                //MyMain_Method.Search_DataExtent(this);//确定数据库记录范围，并填写到历史记录和数据分析的部分
                //MyMain_Method.WriteIn_TodayYearAndMonth(this); //在历史记录的“已审核”页面预先填入今天的年、月-也把已完成任务部分一起初始化一下
                //MyMain_Method.Read_JudgedList(this, textBox3.Text, textBox4.Text);//读取历史记录中“已审核”的事件列表并显示（只有管理员）
                //MyMain_Method.Read_Quest_HasDone(this, textBox9.Text, textBox8.Text);//读取已经完成的任务,由于需要使用到时间参数，所以最后读取

                ////2.隐藏功能的情况
                //this.tabControl1.Controls["tabPage12"].Parent = null;
                //this.tabControl1.Controls["tabPage3"].Parent = null;
                //this.tabControl1.Controls["tabPage4"].Parent = null;
                //this.tabControl1.Controls["tabPage6"].Parent = null;

                //this.tabControl3.Controls["tabPage10"].Parent = null;

                //接下来是隐藏控件
                //未审核页面
                button33.Visible = false;
                button8.Visible = false;
                button18.Visible = false;
                button26.Visible = false;

                //台架页面
                button27.Visible = false;
            }
        }

        private void listBox5_MouseClick(object sender, MouseEventArgs e)
        {
            this.dataGridView4.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            this.dataGridView4.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;

            dataGridView4.Rows.Clear();

            try {
                string time = MyTools_Method.Date_ToNum(listBox5.SelectedItem.ToString()).ToString();
                MyMain_Method.Read_TodayQuest_Bench(this, time);
                MyMain_Method.Read_BenchWorker_Today_WhenBenchList(this, time);

            }
            catch { }





        }

        private void dataGridView4_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (MyConstant_1.now_group == "技术组") {
                return;
            }


            //管理员不能报工时，不给他权限
            string time = MyTools_Method.Date_ToNum(listBox5.SelectedItem.ToString()).ToString();

            string name = dataGridView4.CurrentRow.Cells[1].Value.ToString();
            string num = dataGridView4.CurrentRow.Cells[0].Value.ToString();

            string complete = dataGridView4.CurrentRow.Cells[3].Value.ToString();

            if (MyConstant_1.now_group == "管理员") {
                if (complete == "（未填报）") {
                    F7_3_ReportBench F7_3_ReportBench = new F7_3_ReportBench(time, name, num);
                    F7_3_ReportBench.ShowDialog();
                    MyMain_Method.Read_TodayQuest_Bench(this, time);
                }
                else {
                    F7_4_Change_ReportBench F7_4_Change_ReportBench = new F7_4_Change_ReportBench(time, name, num);
                    F7_4_Change_ReportBench.ShowDialog();
                    MyMain_Method.Read_TodayQuest_Bench(this, time);

                }
            }
        }

        private void textToolStripMenuItem_Click(object sender, EventArgs e)//竟然是更新按钮，好奇怪的名字都认不出来了
        {
            //吧所有页面全都刷新
            dataGridView1.Rows.Clear();
            dataGridView6.Rows.Clear();
            dataGridView4.Rows.Clear();
            listView4.Items.Clear();
            dataGridView5.Rows.Clear();
            listView5.Items.Clear();
            listView6.Items.Clear();
            listView7.Items.Clear();
            dataGridView2.Rows.Clear();
            dataGridView3.Rows.Clear();

            //分两部分就行了，是管理员和不是管理员
            if (MyConstant_1.now_group == "管理员") {//管理员的情况
                //1.读取的情况
                MyMain_Method.Refrash_WhenSoftStart(this);  //总体的刷新，所有的刷新

                //2.隐藏功能的情况
                //分配页面
                button34.Visible = false;
                button29.Visible = false;
                button7.Visible = false;

                //今日任务界面
                button28.Visible = false;
                button16.Visible = false;
                button19.Visible = false;
                button10.Visible = false;
                button6.Visible = false;
            }
            else {//班组的情况
                  //1.读取的情况
                  //comboBox1.SelectedIndex = comboBox1.Items.IndexOf("TDM");//项目分类默认TDM

                //MyMain_Method.Read_WorkerList(this);//读取人员信息
                //MyMain_Method.Read_Quest_ByLimit(this);//读取任务信息（根据限制条件，初始当然是TDM）

                //MyMain_Method.Read_DraftList(this);//读取“已起草”的日期列表
                MyMain_Method.Read_Distribute_DateList(this);//（班组功能）读取“任务分配”日期列表（分试验班和试制班和管理员）
                MyMain_Method.Read_TodayQuestList(this);//（班组功能）读取“当日任务”的日期列表（分试验班和试制班和管理员）
                MyMain_Method.Read_TodayQuestList_Bench(this);//（班组功能）读取“台架试验”列表
                MyMain_Method.Read_ListOfJudging(this);//（班组功能）读取“历史记录”中“未审核”的日期列表（分试验班和试制班和管理员）

                //MyMain_Method.Search_DataExtent(this);//确定数据库记录范围，并填写到历史记录和数据分析的部分
                //MyMain_Method.WriteIn_TodayYearAndMonth(this); //在历史记录的“已审核”页面预先填入今天的年、月-也把已完成任务部分一起初始化一下
                //MyMain_Method.Read_JudgedList(this, textBox3.Text, textBox4.Text);//读取历史记录中“已审核”的事件列表并显示（只有管理员）
                //MyMain_Method.Read_Quest_HasDone(this, textBox9.Text, textBox8.Text);//读取已经完成的任务,由于需要使用到时间参数，所以最后读取

                ////2.隐藏功能的情况
                //this.tabControl1.Controls["tabPage12"].Parent = null;
                //this.tabControl1.Controls["tabPage3"].Parent = null;
                //this.tabControl1.Controls["tabPage4"].Parent = null;
                //this.tabControl1.Controls["tabPage6"].Parent = null;

                //this.tabControl3.Controls["tabPage10"].Parent = null;

                //接下来是隐藏控件
                //未审核页面
                button33.Visible = false;
                button8.Visible = false;
                button18.Visible = false;
                button26.Visible = false;

                //台架页面
                button27.Visible = false;
            }
        }

        private void button15_Click_1(object sender, EventArgs e)
        {
            F14_AddPlanQuest F14_AddPlanQuest = new F14_AddPlanQuest("试验班");
            F14_AddPlanQuest.ShowDialog();
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            F14_AddPlanQuest F14_AddPlanQuest = new F14_AddPlanQuest("试制班");
            F14_AddPlanQuest.ShowDialog();
        }

        private void button26_Click(object sender, EventArgs e)
        {
            try {
                string time = MyTools_Method.Date_ToNum(listBox3.SelectedItem.ToString()).ToString();

                //要注意这个是管理员才有的权限，所以不需考虑其他权限的情况
                if (MessageBox.Show($"确定{time}的工作需要退回么？", "Confirm Message", MessageBoxButtons.OKCancel) == DialogResult.OK) {
                    try {
                        if (listBox3.SelectedItem.ToString().Contains("试验班") == true) {
                            MyMain_Method.Change_JudingToBack(time, "试验班");
                        }
                        else {
                            MyMain_Method.Change_JudingToBack(time, "试制班");
                        }
                        MyMain_Method.Read_ListOfJudging(this);
                        MyMain_Method.Search_DataExtent(this);
                        MyMain_Method.Read_JudgedList(this, textBox3.Text, textBox4.Text);
                        dataGridView2.Rows.Clear();
                    }
                    catch {
                        MessageBox.Show("这也能报错？未知错误");
                    }
                }
            }
            catch {
                MessageBox.Show("请先选择一项");
            }
        }

        private void button27_Click(object sender, EventArgs e)
        {
            string time = MyTools_Method.Date_ToNum(listBox2.SelectedItem.ToString()).ToString();

            string name = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            string num = dataGridView1.CurrentRow.Cells[0].Value.ToString();


        }

        private void textToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            //事务写入的例子
            SQLiteConnection connect = new SQLiteConnection(MyConstant_1.conStr);
            connect.Open();
            DbTransaction trans = connect.BeginTransaction();


            for (int i = 1; i < 10000; i++) {
                string sql = $"INSERT INTO 台架说明 (统一编号,发布时间,当日说明) VALUES ({i},'{i}','否')";
                SQLiteCommand cmd = new SQLiteCommand(sql, connect);
                cmd.ExecuteNonQuery();
                //SQLiteConnection connect = new SQLiteConnection(MyConstant_1.conStr);
                //SQLiteCommand cmd = new SQLiteCommand(sql, connect);
                //connect.Open();
                //cmd.ExecuteNonQuery();
                //connect.Close();

            }
            trans.Commit();
            connect.Close();

            //string sql2 = $"SELECT* FROM 台架说明";
            //DataSet ds = MySQL_Method.SQLite_search(sql2);
            //foreach(DataRow row in ds.Tables[0].Rows) {
            //    ListViewItem first = new ListViewItem(row["统一编号"].ToString());
            //    first.SubItems.Add(row["发布时间"].ToString());
            //    first.SubItems.Add(row["当日说明"].ToString());

            //    listView1.Items.Add(first);
            //}
        }

        private void 删除人员和项目以外的所有ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("确定要清空数据库么（除了人员和项目的信息）？", "Confirm Message", MessageBoxButtons.OKCancel) == DialogResult.OK) {
                string sql = $"DELETE FROM 任务分配0试制班";
                MySQL_Method.SQLite_delete(sql);
                sql = $"DELETE FROM 任务分配0试验班";
                MySQL_Method.SQLite_delete(sql);
                sql = $"DELETE FROM 任务发布0试验班";
                MySQL_Method.SQLite_delete(sql);
                sql = $"DELETE FROM 任务发布0试制班";
                MySQL_Method.SQLite_delete(sql);
                sql = $"DELETE FROM 任务说明0试验班";
                MySQL_Method.SQLite_delete(sql);
                sql = $"DELETE FROM 任务说明0试制班";
                MySQL_Method.SQLite_delete(sql);
                sql = $"DELETE FROM 每日流程0试验班";
                MySQL_Method.SQLite_delete(sql);
                sql = $"DELETE FROM 每日流程0试制班";
                MySQL_Method.SQLite_delete(sql);

                sql = $"DELETE FROM 台架分配";
                MySQL_Method.SQLite_delete(sql);
                sql = $"DELETE FROM 台架发布";
                MySQL_Method.SQLite_delete(sql);
                sql = $"DELETE FROM 台架说明";
                MySQL_Method.SQLite_delete(sql);


                //吧所有页面全都刷新
                dataGridView1.Rows.Clear();
                dataGridView4.Rows.Clear();
                listView4.Items.Clear();
                dataGridView5.Rows.Clear();
                listView5.Items.Clear();
                listView6.Items.Clear();
                listView7.Items.Clear();
                dataGridView2.Rows.Clear();
                dataGridView3.Rows.Clear();

                //分两部分就行了，是管理员和不是管理员
                if (MyConstant_1.now_group == "管理员") {//管理员的情况
                                                      //1.读取的情况
                    MyMain_Method.Refrash_WhenSoftStart(this);  //总体的刷新，所有的刷新

                    //2.隐藏功能的情况
                    //分配页面
                    button34.Visible = false;
                    button29.Visible = false;
                    button7.Visible = false;

                    //今日任务界面
                    button28.Visible = false;
                    button16.Visible = false;
                    button19.Visible = false;
                    button10.Visible = false;
                    button6.Visible = false;
                }
                else {//班组的情况
                      //1.读取的情况
                      //comboBox1.SelectedIndex = comboBox1.Items.IndexOf("TDM");//项目分类默认TDM

                    //MyMain_Method.Read_WorkerList(this);//读取人员信息
                    //MyMain_Method.Read_Quest_ByLimit(this);//读取任务信息（根据限制条件，初始当然是TDM）

                    //MyMain_Method.Read_DraftList(this);//读取“已起草”的日期列表
                    MyMain_Method.Read_Distribute_DateList(this);//（班组功能）读取“任务分配”日期列表（分试验班和试制班和管理员）
                    MyMain_Method.Read_TodayQuestList(this);//（班组功能）读取“当日任务”的日期列表（分试验班和试制班和管理员）
                    MyMain_Method.Read_TodayQuestList_Bench(this);//（班组功能）读取“台架试验”列表
                    MyMain_Method.Read_ListOfJudging(this);//（班组功能）读取“历史记录”中“未审核”的日期列表（分试验班和试制班和管理员）

                    //MyMain_Method.Search_DataExtent(this);//确定数据库记录范围，并填写到历史记录和数据分析的部分
                    //MyMain_Method.WriteIn_TodayYearAndMonth(this); //在历史记录的“已审核”页面预先填入今天的年、月-也把已完成任务部分一起初始化一下
                    //MyMain_Method.Read_JudgedList(this, textBox3.Text, textBox4.Text);//读取历史记录中“已审核”的事件列表并显示（只有管理员）
                    //MyMain_Method.Read_Quest_HasDone(this, textBox9.Text, textBox8.Text);//读取已经完成的任务,由于需要使用到时间参数，所以最后读取

                    ////2.隐藏功能的情况
                    //this.tabControl1.Controls["tabPage12"].Parent = null;
                    //this.tabControl1.Controls["tabPage3"].Parent = null;
                    //this.tabControl1.Controls["tabPage4"].Parent = null;
                    //this.tabControl1.Controls["tabPage6"].Parent = null;

                    //this.tabControl3.Controls["tabPage10"].Parent = null;

                    //接下来是隐藏控件
                    //未审核页面
                    button33.Visible = false;
                    button8.Visible = false;
                    button18.Visible = false;
                    button26.Visible = false;

                    //台架页面
                    button27.Visible = false;

                }

            }
        }

        private void button19_Click_1(object sender, EventArgs e)
        {
            if (MyConstant_1.now_group != "管理员") {
                F16_password F16_password = new F16_password(MyConstant_1.now_group);
                F16_password.ShowDialog();



            }

        }

        private void dataGridView4_MouseClick(object sender, MouseEventArgs e)
        {
            if (dataGridView4.CurrentRow == null) {
                return;
            }
            string num = dataGridView4.CurrentRow.Cells[0].Value.ToString();
            string time = MyTools_Method.Date_ToNum(listBox5.SelectedItem.ToString()).ToString();
            MyMain_Method.Read_InfoOf_ThisTodayQuestBench(time, num, this);
        }

        private void button28_Click(object sender, EventArgs e)
        {
            if (listBox2.SelectedItem != null) {
                string time = MyTools_Method.Date_ToNum(listBox2.SelectedItem.ToString()).ToString();
                string num = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                string quest = dataGridView1.CurrentRow.Cells[1].Value.ToString();

                if (MyConstant_1.now_group == "管理员") {
                    if (listBox1.SelectedItem.ToString().Contains("试验班") == true) {
                        F6_4_Change_WhenWork_Another F6_4_Change_WhenWork_Another = new F6_4_Change_WhenWork_Another(num, time,quest, "试验班");
                        F6_4_Change_WhenWork_Another.ShowDialog();
                        MyMain_Method.Read_DistributeResult(this, time, "试验班");
                    }
                    else {
                        F6_4_Change_WhenWork_Another F6_4_Change_WhenWork_Another = new F6_4_Change_WhenWork_Another(num, time, quest, "试制班");
                        F6_4_Change_WhenWork_Another.ShowDialog();
                        MyMain_Method.Read_DistributeResult(this, time, "试制班");
                    }

                }
                else {
                    F6_4_Change_WhenWork_Another F6_4_Change_WhenWork_Another = new F6_4_Change_WhenWork_Another(num, time, quest, MyConstant_1.now_group);
                    F6_4_Change_WhenWork_Another.ShowDialog();
                    MyMain_Method.Read_DistributeResult(this, time, MyConstant_1.now_group);
                }
            }

            //这里是刷新，不用管
            this.dataGridView1.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            this.dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;

            dataGridView1.Rows.Clear();

            try {
                string time = MyTools_Method.Date_ToNum(listBox2.SelectedItem.ToString()).ToString();
                if (MyConstant_1.now_group == "管理员") {
                    if (listBox2.SelectedItem.ToString().Contains("试验班") == true) {
                        MyMain_Method.Read_TodayQuest(this, time, "试验班");
                    }
                    else {
                        MyMain_Method.Read_TodayQuest(this, time, "试制班");
                    }
                }
                else {
                    MyMain_Method.Read_TodayQuest(this, time, MyConstant_1.now_group);
                }

            }
            catch { }



            /*
            //这个不要了
            if (listBox2.SelectedItem != null) {
                string time = MyTools_Method.Date_ToNum(listBox2.SelectedItem.ToString()).ToString();
                string num = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                string quest = dataGridView1.CurrentRow.Cells[1].Value.ToString();

                if (MyConstant_1.now_group == "管理员") {
                    if (listBox1.SelectedItem.ToString().Contains("试验班") == true) {
                        F6_3_Change_WhenWork F6_3_Change_WhenWork = new F6_3_Change_WhenWork(time, num, "试验班");
                        F6_3_Change_WhenWork.ShowDialog();
                        MyMain_Method.Read_DistributeResult(this, time, "试验班");
                    }
                    else {
                        F6_3_Change_WhenWork F6_3_Change_WhenWork = new F6_3_Change_WhenWork(time, num, "试制班");
                        F6_3_Change_WhenWork.ShowDialog();
                        MyMain_Method.Read_DistributeResult(this, time, "试制班");
                    }

                }
                else {
                    F6_3_Change_WhenWork F6_3_Change_WhenWork = new F6_3_Change_WhenWork(time, num, MyConstant_1.now_group);
                    F6_3_Change_WhenWork.ShowDialog();
                    MyMain_Method.Read_DistributeResult(this, time, MyConstant_1.now_group);
                }
            }

            this.dataGridView1.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            this.dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;

            dataGridView1.Rows.Clear();

            try {
                string time = MyTools_Method.Date_ToNum(listBox2.SelectedItem.ToString()).ToString();
                if (MyConstant_1.now_group == "管理员") {
                    if (listBox2.SelectedItem.ToString().Contains("试验班") == true) {
                        MyMain_Method.Read_TodayQuest(this, time, "试验班");
                    }
                    else {
                        MyMain_Method.Read_TodayQuest(this, time, "试制班");
                    }
                }
                else {
                    MyMain_Method.Read_TodayQuest(this, time, MyConstant_1.now_group);
                }

            }
            catch { }
            */

        }

        private void button27_Click_1(object sender, EventArgs e)
        {


            string time = MyTools_Method.Date_ToNum(listBox5.SelectedItem.ToString()).ToString();

            if (MessageBox.Show($"确定{time}的工作已经填报完毕了么？", "Confirm Message", MessageBoxButtons.OKCancel) == DialogResult.OK) {
                try {
                    MyMain_Method.Change_ToSubmitBench(time);
                    MyMain_Method.Read_TodayQuestList_Bench(this);
                    MyMain_Method.Read_ListOfJudging(this);
                    this.dataGridView4.Rows.Clear();
                }
                catch {
                    MessageBox.Show("请至少填报一组工时");
                }
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if(checkBox1.CheckState == CheckState.Checked) {
                MyTools_Method.DelectDir(@"data\result");
            }

            if (textBox1.Text == "" || textBox2.Text == "" || comboBox2.Text == "") {
                MessageBox.Show("请确认填入了起始和结束的时间，并且选择了班组");
                return;
            }
            string mintime = textBox1.Text;
            string maxtime = textBox2.Text;
            string group = comboBox2.Text;
            string connect =  MyConstant_1.conStr.Substring(12, MyConstant_1.conStr.Length - 23);
            //string connect = "data/work_info.db3";
            Process proc = Process.Start(@"data\main\main.exe", $"{connect} {mintime} {maxtime} {group} 1-2-工时统计");
            proc.WaitForExit();
            proc.Close();
            Process proc2 = Process.Start(@"data\result");
        }

        private void button42_Click(object sender, EventArgs e)
        {
            if (checkBox1.CheckState == CheckState.Checked) {
                MyTools_Method.DelectDir(@"data\result");
            }

            if (textBox7.Text == "" || textBox14.Text == "" || comboBox4.Text == "") {
                MessageBox.Show("请确认填入了起始和结束的时间，并且选择了班组");
                return;
            }
            string mintime = textBox7.Text;
            string maxtime = textBox14.Text;
            string group = comboBox4.Text;
            string connect = MyConstant_1.conStr.Substring(12, MyConstant_1.conStr.Length - 23);
            //string connect = "data/work_info.db3";
            Process proc = Process.Start(@"data\main\main.exe", $"{connect} {mintime} {maxtime} {group} 2-2-项目难度统计");
            proc.WaitForExit();
            proc.Close();
            Process proc2 = Process.Start(@"data\result");
        }


        private void button30_Click(object sender, EventArgs e)
        {
            F17_Change_Order F17_Change_Order = new F17_Change_Order("试验班");
            F17_Change_Order.ShowDialog();
            MyMain_Method.Read_WorkerList(this);//读取人员信息
        }

        private void button31_Click(object sender, EventArgs e)
        {
            F17_Change_Order F17_Change_Order = new F17_Change_Order("试制班");
            F17_Change_Order.ShowDialog();
            MyMain_Method.Read_WorkerList(this);//读取人员信息
        }

        private void button32_Click(object sender, EventArgs e)
        {
            if (listBox6.SelectedItem != null) {
                string time = MyTools_Method.Date_ToNum(listBox6.SelectedItem.ToString()).ToString();
                if (listBox6.SelectedItem.ToString().Contains("休") == true) {
                    string sql = $"UPDATE 每日流程0试验班 SET 是否假期 = '否' WHERE 发布时间 = {time}";
                    MySQL_Method.SQLite_update(sql);
                    sql = $"UPDATE 每日流程0试制班 SET 是否假期 = '否' WHERE 发布时间 = {time}";
                    MySQL_Method.SQLite_update(sql);
                }
                else {
                    string sql = $"UPDATE 每日流程0试验班 SET 是否假期 = '是' WHERE 发布时间 = {time}";
                    MySQL_Method.SQLite_update(sql);
                    sql = $"UPDATE 每日流程0试制班 SET 是否假期 = '是' WHERE 发布时间 = {time}";
                    MySQL_Method.SQLite_update(sql);
                }
            }
            MyMain_Method.Read_DraftList(this);//读取“已起草”的日期列表


        }

        private void button29_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem == null || listView4.FocusedItem == null) {
                return;
            }
            string time = MyTools_Method.Date_ToNum(listBox1.SelectedItem.ToString()).ToString();
            string num = listView4.FocusedItem.SubItems[0].Text;
            string group = "";

            //后面group用的多，这里先写一个
            if (MyConstant_1.now_group == "管理员") {
                if (listBox1.SelectedItem.ToString().Contains("试验") == true) {
                    group = "试验班";
                }
                else if (listBox1.SelectedItem.ToString().Contains("试制") == true) {
                    group = "试制班";
                }
                else {
                    listView4.Items.Clear();
                }
            }
            else {
                group = MyConstant_1.now_group;
            }

            //先删后加
            string sql = $"DELETE FROM 任务分配0{group} WHERE 发布时间 = {time} AND 统一编号 = '{num}'";
            MySQL_Method.SQLite_delete(sql);

            for (int i = 0; i < dataGridView5.Rows.Count; i++) {
                if (dataGridView5.Rows[i].Cells[0].Value.ToString() == "True") {
                    string worker_num = dataGridView5.Rows[i].Cells[1].Value.ToString();
                    MyOtherWin_Method.Add_NewDistributePlan(time, num, worker_num, group);
                }
            }



            //完成以后要刷新，以免listview丢失角点
            listView4.Items.Clear();
            try {

                if (MyConstant_1.now_group == "管理员") {
                    if (listBox1.SelectedItem.ToString().Contains("试验") == true) {
                        MyMain_Method.Read_DistributeResult(this, time, "试验班");
                    }
                    else if (listBox1.SelectedItem.ToString().Contains("试制") == true) {
                        MyMain_Method.Read_DistributeResult(this, time, "试制班");
                    }
                    else {
                        listView4.Items.Clear();
                    }
                }
                else {
                    MyMain_Method.Read_DistributeResult(this, time, MyConstant_1.now_group);
                }

            }
            catch { }

            dataGridView5.Rows.Clear();


        }

        private void label49_Click(object sender, EventArgs e)
        {

        }

        private void textBox12_TextChanged(object sender, EventArgs e)
        {

        }

        private void button33_Click(object sender, EventArgs e)
        {
            if (listBox3.SelectedItem != null) {
                string time = MyTools_Method.Date_ToNum(listBox3.SelectedItem.ToString()).ToString();
                if (listBox3.SelectedItem.ToString().Contains("休") == true) {
                    string sql = $"UPDATE 每日流程0试验班 SET 是否假期 = '否' WHERE 发布时间 = {time}";
                    MySQL_Method.SQLite_update(sql);
                    sql = $"UPDATE 每日流程0试制班 SET 是否假期 = '否' WHERE 发布时间 = {time}";
                    MySQL_Method.SQLite_update(sql);
                }
                else {
                    string sql = $"UPDATE 每日流程0试验班 SET 是否假期 = '是' WHERE 发布时间 = {time}";
                    MySQL_Method.SQLite_update(sql);
                    sql = $"UPDATE 每日流程0试制班 SET 是否假期 = '是' WHERE 发布时间 = {time}";
                    MySQL_Method.SQLite_update(sql);
                }
            }
            MyMain_Method.Read_ListOfJudging(this);//（班组功能）读取“历史记录”中“未审核”的日期列表（分试验班和试制班和管理员）
        }

        private void button34_Click(object sender, EventArgs e)
        {
            string time = MyTools_Method.Date_ToNum(listBox1.SelectedItem.ToString()).ToString();
            if (listBox1.SelectedItem != null) {
                for (int i = 0; i < listView4.Items.Count; i++) {
                    string num = listView4.Items[i].SubItems[0].Text;
                    string sql = $"SELECT * FROM 任务分配0{MyConstant_1.now_group} WHERE 发布时间 <= {time} AND 统一编号 = '{num}' AND 工作类型 = '（分配标记）' ORDER BY 发布时间 DESC";
                    DataSet ds = MySQL_Method.SQLite_search(sql);
                    if (ds.Tables[0].Rows.Count >= 1) {
                        string near_time = ds.Tables[0].Rows[0]["发布时间"].ToString();
                        string sql3 = $"SELECT * FROM 任务分配0{MyConstant_1.now_group} WHERE 发布时间 = {near_time} AND 统一编号 = '{num}' AND 工作类型 = '（分配标记）' ORDER BY 发布时间 DESC";
                        DataSet ds3 = MySQL_Method.SQLite_search(sql3);
                        //先删后加
                        string sql4 = $"DELETE FROM 任务分配0{MyConstant_1.now_group} WHERE 发布时间 = {time} AND 统一编号 = '{num}' AND 工作类型 = '（分配标记）'";
                        MySQL_Method.SQLite_delete(sql4);
                        foreach (DataRow row in ds3.Tables[0].Rows) {
                            string sql2 = $"insert into 任务分配0{MyConstant_1.now_group} (发布时间,统一编号,工号,工作类型,工时系数,工作小时)values({time},'{num}',{row["工号"].ToString()},'（分配标记）',0,0)";
                            MySQL_Method.SQLite_add(sql2);
                        }

                    }


                }
            }

            //然后记得要刷新
            listView4.Items.Clear();
            try {
                if (MyConstant_1.now_group == "管理员") {
                    if (listBox1.SelectedItem.ToString().Contains("试验") == true) {
                        MyMain_Method.Read_DistributeResult(this, time, "试验班");
                    }
                    else if (listBox1.SelectedItem.ToString().Contains("试制") == true) {
                        MyMain_Method.Read_DistributeResult(this, time, "试制班");
                    }
                    else {
                        listView4.Items.Clear();
                        dataGridView5.Rows.Clear();
                    }
                }
                else {
                    MyMain_Method.Read_DistributeResult(this, time, MyConstant_1.now_group);
                }

            }
            catch {
                listView4.Items.Clear();
                dataGridView5.Rows.Clear();
            }


        }

        private void button35_Click(object sender, EventArgs e)
        {
            if (listBox4.SelectedItem != null) {
                string time = MyTools_Method.Date_ToNum(listBox4.SelectedItem.ToString()).ToString();
                if (listBox4.SelectedItem.ToString().Contains("休") == true) {
                    string sql = $"UPDATE 每日流程0试验班 SET 是否假期 = '否' WHERE 发布时间 = {time}";
                    MySQL_Method.SQLite_update(sql);
                    sql = $"UPDATE 每日流程0试制班 SET 是否假期 = '否' WHERE 发布时间 = {time}";
                    MySQL_Method.SQLite_update(sql);
                }
                else {
                    string sql = $"UPDATE 每日流程0试验班 SET 是否假期 = '是' WHERE 发布时间 = {time}";
                    MySQL_Method.SQLite_update(sql);
                    sql = $"UPDATE 每日流程0试制班 SET 是否假期 = '是' WHERE 发布时间 = {time}";
                    MySQL_Method.SQLite_update(sql);
                }
            }
            MyMain_Method.Read_JudgedList(this, textBox3.Text, textBox4.Text);//读取历史记录中“已审核”的事件列表并显示（只有管理员）

        }

        private void 保存修改ToolStripMenuItem_Click(object sender, EventArgs e)
        {

            if (listBox1.SelectedItem == null || listView4.FocusedItem == null) {
                return;
            }
            string time = MyTools_Method.Date_ToNum(listBox1.SelectedItem.ToString()).ToString();
            string num = listView4.FocusedItem.SubItems[0].Text;
            string group = "";

            //后面group用的多，这里先写一个
            if (MyConstant_1.now_group == "管理员") {
                if (listBox1.SelectedItem.ToString().Contains("试验") == true) {
                    group = "试验班";
                }
                else if (listBox1.SelectedItem.ToString().Contains("试制") == true) {
                    group = "试制班";
                }
                else {
                    listView4.Items.Clear();
                }
            }
            else {
                group = MyConstant_1.now_group;
            }

            //先删后加
            string sql = $"DELETE FROM 任务分配0{group} WHERE 发布时间 = {time} AND 统一编号 = '{num}'";
            MySQL_Method.SQLite_delete(sql);

            for (int i = 0; i < dataGridView5.Rows.Count; i++) {
                if (dataGridView5.Rows[i].Cells[0].Value.ToString() == "True") {
                    string worker_num = dataGridView5.Rows[i].Cells[1].Value.ToString();
                    MyOtherWin_Method.Add_NewDistributePlan(time, num, worker_num, group);
                }
            }


            //完成以后要刷新，以免listview丢失角点
            listView4.Items.Clear();
            try {

                if (MyConstant_1.now_group == "管理员") {
                    if (listBox1.SelectedItem.ToString().Contains("试验") == true) {
                        MyMain_Method.Read_DistributeResult(this, time, "试验班");
                    }
                    else if (listBox1.SelectedItem.ToString().Contains("试制") == true) {
                        MyMain_Method.Read_DistributeResult(this, time, "试制班");
                    }
                    else {
                        listView4.Items.Clear();
                    }
                }
                else {
                    MyMain_Method.Read_DistributeResult(this, time, MyConstant_1.now_group);
                }

            }
            catch { }

            dataGridView5.Rows.Clear();
        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {

        }

        private void dataGridView5_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView5.Rows[e.RowIndex].Cells[0].Value.ToString() == "True") {
                dataGridView5.Rows[e.RowIndex].Cells[0].Value = false;
            }else {
                dataGridView5.Rows[e.RowIndex].Cells[0].Value = true;
            }

        }

        private void button36_Click(object sender, EventArgs e)
        {
            try {
                string time = MyTools_Method.Date_ToNum(listBox4.SelectedItem.ToString()).ToString();

                if (MyConstant_1.now_group == "管理员") {
                    if (listBox4.SelectedItem.ToString().Contains("试验班")) {
                        F10_Today_View F10_Today_View = new F10_Today_View(time, "试验班");
                        F10_Today_View.ShowDialog();
                    }
                    else {
                        F10_Today_View F10_Today_View = new F10_Today_View(time, "试制班");
                        F10_Today_View.ShowDialog();
                    }
                }
                else {
                    F10_Today_View F10_Today_View = new F10_Today_View(time, MyConstant_1.now_group);
                    F10_Today_View.ShowDialog();
                }
            }
            catch { }
        }

        private void dataGridView3_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            string time = MyTools_Method.Date_ToNum(listBox4.SelectedItem.ToString()).ToString();
            string name = dataGridView3.CurrentRow.Cells[1].Value.ToString();
            string num = dataGridView3.CurrentRow.Cells[0].Value.ToString();
            string complete = dataGridView3.CurrentRow.Cells[3].Value.ToString();

            //逻辑可能有点绕，写一下免得我又忘了
            //1.判断权限；
            //2.如果是管理员，那么还要看contains，如果不是就不用看了——这决定了查哪张表；
            //3.接下来看当前项目名是否包含“台架”，如果包含，那之前全作废，从台架的表查；
            //4.我滴娘，还要看看当前状态是不是未完成？
            //顺序不太对，应该最先考虑台架才对。

            if (name.Contains("(台架)") == true) {//是台架的情况
                if (complete == "（未填报）") {//台架未填报的状况
                    F7_3_ReportBench F7_3_ReportBench = new F7_3_ReportBench(time, name, num);
                    F7_3_ReportBench.ShowDialog();
                }
                else {//台架已填报的状况
                    F7_4_Change_ReportBench F7_4_Change_ReportBench = new F7_4_Change_ReportBench(time, name, num);
                    F7_4_Change_ReportBench.ShowDialog();
                }
            }
            else {//不是台架的情况
                if (MyConstant_1.now_group == "管理员") {//是管理员的情况
                    if (listBox4.SelectedItem.ToString().Contains("试验班") == true) {//listbox是试验班
                        if (complete == "（未填报）") {//未填报的状况
                            F7_Report F7_Report = new F7_Report(time, name, num, "试验班");
                            F7_Report.ShowDialog();
                        }
                        else {//已经填报的状况
                            F7_2_Change_Report F7_2_Change_Report = new F7_2_Change_Report(time, name, num, "试验班");
                            F7_2_Change_Report.ShowDialog();
                        }
                    }
                    else {//listbox是试制班
                        if (complete == "（未填报）") {//未填报的状况
                            F7_Report F7_Report = new F7_Report(time, name, num, "试制班");
                            F7_Report.ShowDialog();
                        }
                        else {//已经填报的状况
                            F7_2_Change_Report F7_2_Change_Report = new F7_2_Change_Report(time, name, num, "试制班");
                            F7_2_Change_Report.ShowDialog();
                        }
                    }
                }
                else {//不是管理员的情况
                    if (complete == "（未填报）") {//未填报的状况
                        F7_Report F7_Report = new F7_Report(time, name, num, MyConstant_1.now_group);
                        F7_Report.ShowDialog();
                    }
                    else {//已经填报的状况
                        F7_2_Change_Report F7_2_Change_Report = new F7_2_Change_Report(time, name, num, MyConstant_1.now_group);
                        F7_2_Change_Report.ShowDialog();
                    }
                }
            }

            //全弄完再说读取刷新的事情
            if (MyConstant_1.now_group == "管理员") {
                if (listBox4.SelectedItem.ToString().Contains("试验班") == true) {
                    MyMain_Method.Read_ResultOf_JudgedQuest(this, time, "试验班");
                    MyMain_Method.Read_ResultOf_JudgedQuest_ByBench(this, time, "试验班");
                }
                else {
                    MyMain_Method.Read_ResultOf_JudgedQuest(this, time, "试制班");
                    MyMain_Method.Read_ResultOf_JudgedQuest_ByBench(this, time, "试制班");
                }
            }
            else {
                MyMain_Method.Read_ResultOf_JudgedQuest(this, time, MyConstant_1.now_group);
                MyMain_Method.Read_ResultOf_JudgedQuest_ByBench(this, time, MyConstant_1.now_group);
            }

        }

        private void tabControl4_MouseClick(object sender, MouseEventArgs e)
        {

        }

        private void tabControl4_SelectedIndexChanged(object sender, EventArgs e)
        {
            dataGridView7.Rows.Clear();
            dataGridView8.Rows.Clear();

            dataGridView7.Visible = false;
            dataGridView8.Visible = false;

            richTextBox1.Text = "";
        }

        private void dataGridView6_MouseClick(object sender, MouseEventArgs e)
        {
            if (listBox2.SelectedItem == null) {
                return;
            }


            //右边要显示工时填写的信息
            //管理员不能报工时，不给他权限
            if (dataGridView6.CurrentRow.Cells[2].Value.ToString() == "(无)") {
                MessageBox.Show("请先分配人员在进行工时填写");
                return;
            }
            try {
                string time = MyTools_Method.Date_ToNum(listBox2.SelectedItem.ToString()).ToString();
                string name = dataGridView6.CurrentRow.Cells[1].Value.ToString();
                string num = dataGridView6.CurrentRow.Cells[0].Value.ToString();

                dataGridView7.Rows.Clear();

                if (MyConstant_1.now_group != "管理员") {

                    MyMain_Method.Read_WorkTime_ForThisPeople(this, time, num, MyConstant_1.now_group);
                }
                else {
                    if (listBox2.SelectedItem.ToString().Contains("试验") == true) {
                        MyMain_Method.Read_WorkTime_ForThisPeople(this, time, num, "试验班");
                    }
                    else {
                        MyMain_Method.Read_WorkTime_ForThisPeople(this, time, num, "试制班");
                    }
                }

                dataGridView7.Visible = true;
            }
            catch { }
        }

        private void 保存按任务ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //先用正则过一遍
            for (int i = 0; i < dataGridView8.Rows.Count; i++) {
                if (dataGridView8.Rows[i].Cells[2].Value != null) {
                    if (MyRegular_Method.WorkTimeString(dataGridView8.Rows[i].Cells[2].Value.ToString()) == false) {
                        if (dataGridView8.Rows[i].Cells[2].Value.ToString() != "") {
                            MessageBox.Show($"第{i + 1}行的数据不符合填写要求");
                            return;
                        }
                    }
                }

            }

            //都过了正则以后就录入，要先删后加
            string time = MyTools_Method.Date_ToNum(listBox2.SelectedItem.ToString()).ToString();
            string num_quest = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            string group = "";
            if (MyConstant_1.now_group != "管理员") {
                group = MyConstant_1.now_group;
            }
            else {
                if (listBox2.SelectedItem.ToString().Contains("试验") == true) {
                    group = "试验班";
                }
                else {
                    group = "试制班";
                }
            }


            //先删
            if (MyConstant_1.now_group != "管理员") {
                string sql = $"DELETE FROM 任务分配0{MyConstant_1.now_group} WHERE 统一编号 = '{num_quest}' AND 发布时间 = {time} AND 工作类型 = '废弃属性'";
                MySQL_Method.SQLite_delete(sql);
            }
            else {
                if (listBox2.SelectedItem.ToString().Contains("试验") == true) {
                    string sql = $"DELETE FROM 任务分配0试验班 WHERE 统一编号 = '{num_quest}' AND 发布时间 = {time} AND 工作类型 = '废弃属性'";
                    MySQL_Method.SQLite_delete(sql);
                }
                else {
                    string sql = $"DELETE FROM 任务分配0试制班 WHERE 统一编号 = '{num_quest}' AND 发布时间 = {time} AND 工作类型 = '废弃属性' ";
                    MySQL_Method.SQLite_delete(sql);
                }
            }
            
            //后加
            for (int i = 0; i < dataGridView8.Rows.Count; i++) {
                if (dataGridView8.Rows[i].Cells[2].Value != null) {
                    if (dataGridView8.Rows[i].Cells[2].Value.ToString() != "") {
                        string TimeString_BeforeAnsys = dataGridView8.Rows[i].Cells[2].Value.ToString();
                        string[] TimeString_AfterCross = TimeString_BeforeAnsys.Split('+');
                        foreach (string NoCross in TimeString_AfterCross) {
                            string[] TimeString_AfterStar = NoCross.Split('*');
                            //前面一个是小时数，后面一个是工时系数
                            string Hours = TimeString_AfterStar[0].ToString();
                            string Radio = TimeString_AfterStar[1].ToString();

                            //加吧……
                            string num_worker = dataGridView8.Rows[i].Cells[0].Value.ToString();
                            string sql = $"insert into 任务分配0{group} (发布时间,统一编号,工号,工作类型,工时系数,工作小时)values({time},'{num_quest}',{num_worker},'废弃属性',{Radio},{Hours})";
                            MySQL_Method.SQLite_add(sql);


                        }

                    }
                }
                
            }
            //清空这个界面并且隐藏
            dataGridView8.Rows.Clear();
            dataGridView8.Visible = false;




            //刷新工时的界面

            this.dataGridView1.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            this.dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;

            dataGridView1.Rows.Clear();

            try {
                time = MyTools_Method.Date_ToNum(listBox2.SelectedItem.ToString()).ToString();
                if (MyConstant_1.now_group == "管理员") {
                    if (listBox2.SelectedItem.ToString().Contains("试验班") == true) {
                        MyMain_Method.Read_TodayQuest(this, time, "试验班");
                    }
                    else {
                        MyMain_Method.Read_TodayQuest(this, time, "试制班");
                    }
                }
                else {
                    MyMain_Method.Read_TodayQuest(this, time, MyConstant_1.now_group);
                }

            }
            catch { }

            this.dataGridView6.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            this.dataGridView6.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;

            dataGridView6.Rows.Clear();

            try {
                time = MyTools_Method.Date_ToNum(listBox2.SelectedItem.ToString()).ToString();
                if (MyConstant_1.now_group == "管理员") {
                    if (listBox2.SelectedItem.ToString().Contains("试验班") == true) {
                        MyMain_Method.Read_TodayQuest_ForEachWorker(this, time, "试验班");
                    }
                    else {
                        MyMain_Method.Read_TodayQuest_ForEachWorker(this, time, "试制班");
                    }
                }
                else {
                    MyMain_Method.Read_TodayQuest_ForEachWorker(this, time, MyConstant_1.now_group);
                }

            }
            catch { }





        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void 保存按人员ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //先用正则过一遍
            for (int i = 0; i < dataGridView7.Rows.Count; i++) {
                if (MyRegular_Method.WorkTimeString(dataGridView7.Rows[i].Cells[2].Value.ToString()) == false) {
                    if (dataGridView7.Rows[i].Cells[2].Value.ToString() != "") {
                        MessageBox.Show($"第{i + 1}行的数据不符合填写要求");
                        return;
                    }
                }
            }

            //都过了正则以后就录入，要先删后加
            string time = MyTools_Method.Date_ToNum(listBox2.SelectedItem.ToString()).ToString();
            string num_worker = dataGridView6.CurrentRow.Cells[0].Value.ToString();
            string group = "";
            if (MyConstant_1.now_group != "管理员") {
                group = MyConstant_1.now_group;
            }
            else {
                if (listBox2.SelectedItem.ToString().Contains("试验") == true) {
                    group = "试验班";
                }
                else {
                    group = "试制班";
                }
            }


            //先删
            if (MyConstant_1.now_group != "管理员") {
                string sql = $"DELETE FROM 任务分配0{MyConstant_1.now_group} WHERE 工号 = {num_worker} AND 发布时间 = {time} AND 工作类型 = '废弃属性'";
                MySQL_Method.SQLite_delete(sql);
            }
            else {
                if (listBox2.SelectedItem.ToString().Contains("试验") == true) {
                    string sql = $"DELETE FROM 任务分配0试验班 WHERE 工号 = {num_worker} AND 发布时间 = {time} AND 工作类型 = '废弃属性'";
                    MySQL_Method.SQLite_delete(sql);
                }
                else {
                    string sql = $"DELETE FROM 任务分配0试制班 WHERE 工号 = {num_worker} AND 发布时间 = {time} AND 工作类型 = '废弃属性' ";
                    MySQL_Method.SQLite_delete(sql);
                }
            }

            //后加
            for (int i = 0; i < dataGridView7.Rows.Count; i++) {
                if (dataGridView7.Rows[i].Cells[2].Value.ToString() != "") {
                    string TimeString_BeforeAnsys = dataGridView7.Rows[i].Cells[2].Value.ToString();
                    string[] TimeString_AfterCross = TimeString_BeforeAnsys.Split('+');
                    foreach (string NoCross in TimeString_AfterCross) {
                        string[] TimeString_AfterStar = NoCross.Split('*');
                        //前面一个是小时数，后面一个是工时系数
                        string Hours = TimeString_AfterStar[0].ToString();
                        string Radio = TimeString_AfterStar[1].ToString();

                        //加吧……
                        string num_quest = dataGridView7.Rows[i].Cells[0].Value.ToString();
                        string sql = $"insert into 任务分配0{group} (发布时间,统一编号,工号,工作类型,工时系数,工作小时)values({time},'{num_quest}',{num_worker},'废弃属性',{Radio},{Hours})";
                        MySQL_Method.SQLite_add(sql);


                    }

                }
            }
            //清空这个界面并且隐藏
            dataGridView7.Rows.Clear();
            dataGridView7.Visible = false;




            //刷新工时的界面

            this.dataGridView1.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            this.dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;

            dataGridView1.Rows.Clear();

            try {
                time = MyTools_Method.Date_ToNum(listBox2.SelectedItem.ToString()).ToString();
                if (MyConstant_1.now_group == "管理员") {
                    if (listBox2.SelectedItem.ToString().Contains("试验班") == true) {
                        MyMain_Method.Read_TodayQuest(this, time, "试验班");
                    }
                    else {
                        MyMain_Method.Read_TodayQuest(this, time, "试制班");
                    }
                }
                else {
                    MyMain_Method.Read_TodayQuest(this, time, MyConstant_1.now_group);
                }

            }
            catch { }

            this.dataGridView6.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            this.dataGridView6.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;

            dataGridView6.Rows.Clear();

            try {
                time = MyTools_Method.Date_ToNum(listBox2.SelectedItem.ToString()).ToString();
                if (MyConstant_1.now_group == "管理员") {
                    if (listBox2.SelectedItem.ToString().Contains("试验班") == true) {
                        MyMain_Method.Read_TodayQuest_ForEachWorker(this, time, "试验班");
                    }
                    else {
                        MyMain_Method.Read_TodayQuest_ForEachWorker(this, time, "试制班");
                    }
                }
                else {
                    MyMain_Method.Read_TodayQuest_ForEachWorker(this, time, MyConstant_1.now_group);
                }

            }
            catch { }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button37_Click(object sender, EventArgs e)
        {



        }

        private void button37_Click_1(object sender, EventArgs e)
        {
            //Process proc = Process.Start(@"Z:\");
            //string text = @"Z:\";
            //MySystem_Method.Find_File(text);
        }

        private void button38_Click(object sender, EventArgs e)
        {
            //Process proc = Process.Start(@"Z:\");
            //string text = @"Z: \";
            //MySystem_Method.Find_File(text);
        }

        private void button39_Click(object sender, EventArgs e)
        {
            //Process proc = Process.Start(@"Z:\");
            //string text = @"Z:\ (Z:)";
            //MySystem_Method.Find_File(text);

        }

        private void button40_Click(object sender, EventArgs e)
        {     
            //Process proc = Process.Start(@"F:\KataGoData");
            //string text = @"KataGoData";
            //MySystem_Method.Find_File(text);
        }

        private void button37_Click_2(object sender, EventArgs e)
        {
            if (listBox3.SelectedItem != null) {
                string time = MyTools_Method.Date_ToNum(listBox3.SelectedItem.ToString()).ToString();
                F8_holiday F8_holiday = new F8_holiday(time);
                F8_holiday.ShowDialog();
            }
        }

        private void button38_Click_1(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null) {                
                string num = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                if (num.Contains("临时-") != true) {
                    MessageBox.Show("这并不属于班组的临时任务");
                    return;
                }

                F4_2_Change_quest F4_2_Change_quest = new F4_2_Change_quest(num);
                F4_2_Change_quest.ShowDialog();
                MyMain_Method.Read_Quest_ByLimit(this);
            }
        }

        private void button39_Click_1(object sender, EventArgs e)
        {
            if (listBox5.SelectedItem != null) {
                string time = MyTools_Method.Date_ToNum(listBox5.SelectedItem.ToString()).ToString();
                F5_4_BenchWorker_Change F5_4_BenchWorker_Change = new F5_4_BenchWorker_Change(time);
                F5_4_BenchWorker_Change.ShowDialog();                    
            }

            this.dataGridView4.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            this.dataGridView4.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;

            dataGridView4.Rows.Clear();

            try {
                string time = MyTools_Method.Date_ToNum(listBox5.SelectedItem.ToString()).ToString();
                MyMain_Method.Read_TodayQuest_Bench(this, time);
                MyMain_Method.Read_BenchWorker_Today_WhenBenchList(this, time);

            }
            catch { }
        }

        private void 账号管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            F19_Power F19_Power = new F19_Power();
            F19_Power.ShowDialog();

        }

        private void button40_Click_1(object sender, EventArgs e)
        {
            F20_Delete_Day F20_Delete_Day = new F20_Delete_Day();
            F20_Delete_Day.ShowDialog();
            MyMain_Method.Refrash_WhenSoftStart(this);
        }

        private void dataGridView8_CellClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void cMS_SaveByQuest_Opening(object sender, CancelEventArgs e)
        {

        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            MyIni_Method.writeString("DefaultRadio", "Radio", $"{comboBox3.Text}", @"data\setting.ini");
            MyConstant_1.DefaultWorkRadio = comboBox3.Text;
        }

        private void textBox12_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void button41_Click(object sender, EventArgs e)
        {
            if (checkBox1.CheckState == CheckState.Checked) {
                MyTools_Method.DelectDir(@"data\result");
            }

            if (textBox6.Text == "") {
                MessageBox.Show("请确认填入了起始和结束的时间，并且选择了班组");
                return;
            }
            string mintime = textBox6.Text + "01";
            string maxtime = textBox6.Text + "31";
            string group = "无";
            string connect = MyConstant_1.conStr.Substring(12, MyConstant_1.conStr.Length - 23);
            //string connect = "data/work_info.db3";
            Process proc = Process.Start(@"data\main\main.exe", $"{connect} {mintime} {maxtime} {group} 1-1-原版Excel");
            proc.WaitForExit();
            proc.Close();
            Process proc2 = Process.Start(@"data\result");
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

            //需提前说明，备份文件储存在"data\BackupData"中，且命名格式为“XXXX年XX月XX日-XX时XX分-work_info.db3”
            //这个Timer是用来对数据库进行自动备份的，间隔为1000毫秒，过程中使用到公共参数“MyConstant_1.Time_Meter”；
            //这个值在一开始就是2000以保证在开启软件的时候能进行一次判断；
            //好的，事实上好像没用到，不过也无所谓了——还是用吧，控制一下检测的频率，不然频率太高了
            //每次Timer的流程，其过程如下：   


            //0.检查MyConstant_1.Time_Meter是否大于1800（30分钟），不大于则计数器+1然后return，大于则进行后续检查（并且在最后将计数器清零）
            //清零的位置应该是关闭timer的地方和进行备份的地方。
            if (MyConstant_1.Time_Meter <= 1800) {
                MyConstant_1.Time_Meter++;
                return;
            }

            //1.先查看是否存在当日的备份（BackupData）数据，如果存在就把这个Timer关掉，不用再看了；
            string DataAddress_WhenBackup = MyConstant_1.conStr.Substring(12, MyConstant_1.conStr.Length - 36);
            bool Whether_Existence =  MyTools_Method.Check_BackupDataExistence();

            if (Whether_Existence) {
                //想了想也不用清零了，因为timer已经关掉了，没有任何操作的意义了。
                timer1.Enabled = false;
                return;
            }
            //2.判断当前时间是否大于12：00，如果不到12：00，就啥也不干；

            string NowHours_STR = DateTime.Now.ToString("HH");
            int NowHours_INT = Convert.ToInt32(NowHours_STR);
            if(NowHours_INT < 12) {
                return;
            }

            //3.如果大于12：00，直接进行备份；

            string pLocalFilePath = $@"{DataAddress_WhenBackup}work_info.db3";//要复制的文件路径
            string pSaveFilePath = $@"data\BackupData\{DateTime.Now.ToString("yyyy年MM月dd日-HH时mm分ss秒")}-work_info.db3";//指定存储的路径
            if (File.Exists(pLocalFilePath))//必须判断要复制的文件是否存在
            {
                File.Copy(pLocalFilePath, pSaveFilePath, true);//三个参数分别是源文件路径，存储路径，若存储路径有相同文件是否替换
            }
            MyConstant_1.Time_Meter = 0;

            //在最后补充一个，对备份文件进行检查，并且删除所有在30天以前的备份文件。

            MyTools_Method.DelectDir_BeforeOneMonth(@"data\BackupData");


        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            //此Timer为测试用的，短间隔来验证性能和可靠性,因此并没有什么卵用
            Console.WriteLine(MyConstant_1.Time_Meter2);


            //需提前说明，备份文件储存在"data\BackupData"中，且命名格式为“work_info-XXXX年XX月XX日-XX时XX分.db3”
            //这个Timer是用来对数据库进行自动备份的，间隔为1000毫秒，过程中使用到公共参数“MyConstant_1.Time_Meter”；
            //这个值在一开始就是2000以保证在开启软件的时候能进行一次判断；
            //好的，事实上好像没用到，不过也无所谓了——还是用吧，控制一下检测的频率，不然频率太高了
            //每次Timer的流程，其过程如下：
            //0.检查MyConstant_1.Time_Meter是否大于1800（30分钟），不大于则计数器+1然后return，大于则进行后续检查（并且在最后将计数器清零）
            //清零的位置应该是关闭timer的地方和进行备份的地方。
            if (MyConstant_1.Time_Meter2 <= 5) {
                MyConstant_1.Time_Meter2++;
                return;
            }

            //1.先查看是否存在当日的备份（BackupData）数据，如果存在就把这个Timer关掉，不用再看了；
            string DataAddress_WhenBackup = MyConstant_1.conStr.Substring(12, MyConstant_1.conStr.Length - 36);

            bool Whether_Existence = MyTools_Method.Check_BackupDataExistence();

            if (Whether_Existence) {
                //想了想也不用清零了，因为timer已经关掉了，没有任何操作的意义了。
                timer2.Enabled = false;
                return;
            }

            //2.判断当前时间是否大于12：00，如果不到12：00，就啥也不干；

            string NowHours_STR = DateTime.Now.ToString("ss");
            int NowHours_INT = Convert.ToInt32(NowHours_STR);
            if (NowHours_INT < 30) {
                return;
            }

            //3.如果大于12：00，直接进行备份；

            string pLocalFilePath = $@"{DataAddress_WhenBackup}work_info.db3";//要复制的文件路径
            string pSaveFilePath = $@"data\BackupData\{DateTime.Now.ToString("yyyy年MM月dd日-HH时mm分ss秒")}-work_info.db3";//指定存储的路径
            if (File.Exists(pLocalFilePath))//必须判断要复制的文件是否存在
            {
                File.Copy(pLocalFilePath, pSaveFilePath, true);//三个参数分别是源文件路径，存储路径，若存储路径有相同文件是否替换
            }
            MyConstant_1.Time_Meter2 = 0;


        }

        private void button43_Click(object sender, EventArgs e)
        {
            if (listBox3.SelectedItem != null) {
                string num = "";
                string time = MyTools_Method.Date_ToNum(listBox3.SelectedItem.ToString()).ToString();

                num = dataGridView2.CurrentRow.Cells[0].Value.ToString();
                F4_2_Change_quest F4_2_Change_quest = new F4_2_Change_quest(num);
                F4_2_Change_quest.ShowDialog();

                try {
                    if (MyConstant_1.now_group == "管理员" || MyConstant_1.now_group == "技术组") {
                        if (listBox3.SelectedItem.ToString().Contains("试验班") == true) {
                            MyMain_Method.Read_JudgingQuestInfo(this, time, "试验班");
                            MyMain_Method.Read_JudgingQuestInfo_ByBench(this, time, "试验班");
                            //给label填写，并且让按钮disable
                            MyMain_Method.Look_PocessWhenJudge(this, "试验班", time);
                        }
                        else {
                            MyMain_Method.Read_JudgingQuestInfo(this, time, "试制班");
                            MyMain_Method.Read_JudgingQuestInfo_ByBench(this, time, "试制班");
                            MyMain_Method.Look_PocessWhenJudge(this, "试制班", time);
                        }
                    }
                    else {
                        MyMain_Method.Read_JudgingQuestInfo(this, time, MyConstant_1.now_group);
                        MyMain_Method.Read_JudgingQuestInfo_ByBench(this, time, MyConstant_1.now_group);
                        MyMain_Method.Look_PocessWhenJudge(this, MyConstant_1.now_group, time);
                    }

                }
                catch { }
            }
        }



    }
}
