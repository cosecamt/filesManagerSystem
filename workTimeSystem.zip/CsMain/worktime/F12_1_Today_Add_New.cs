﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace worktime
{
    public partial class F12_1_Today_Add_New : Form
    {
        public F12_1_Today_Add_New()
        {
            InitializeComponent();
        }

        public F12_1_Today_Add_New(string time)
        {
            InitializeComponent();
            label11.Text = time;
        }

        private void F12_1_Today_Add_New_Load(object sender, EventArgs e)
        {
            string group = "";
            if (label11.Text.Contains("试验班")) {
                group = "试验班";
            }
            else if(label11.Text.Contains("试制班")) {
                group = "试制班";
            }
            else {
                group =MyConstant_1.now_group;
            }

            //初始化任务部分
            //string time_now = DateTime.Now.ToString("yyyyMMdd");
            string time_now = MyTools_Method.Date_ToNum(label11.Text).ToString();
            textBox7.Text = time_now;
            comboBox1.SelectedIndex = comboBox1.Items.IndexOf("临时");

            //初始化员工部分
            dataGridView1.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;

            string sql2 = $"SELECT* FROM 员工信息 WHERE 所属班组 = '{group}' AND 是否隐藏 = '否'";

            DataSet ds2 = MySQL_Method.SQLite_search(sql2);

            foreach (DataRow row in ds2.Tables[0].Rows) {
                string num = row["工号"].ToString();
                string name = row["姓名"].ToString();

                sql2 = $"SELECT* FROM 任务分配0{group} INNER JOIN 任务信息 ON 任务分配0{group}.统一编号 = 任务信息.统一编号 WHERE 工号 = {num} AND 工作类型 == '（分配标记）' AND 发布时间 = {MyTools_Method.Date_ToNum(label11.Text).ToString()}";
             
                string quest = "";

                DataSet ds3 = MySQL_Method.SQLite_search(sql2);
                foreach (DataRow row3 in ds3.Tables[0].Rows) {
                    quest = quest + "\r\n● " + row3["项目名"];
                }
                if (quest != "") {
                    quest = quest.Substring(2);
                }

                dataGridView1.Rows.Add(false, num, name, quest);
            }

            //在载入时自动填入默认的统一编号，格式：“XX班-当日日期-自动生成编号”
            string auto_num_unity = group + "临时-" + time_now;
            string sql5 = $"SELECT* FROM 任务信息 WHERE 录入时间 = {time_now} AND 统一编号 LIKE '{group}%'";
            DataSet ds5 = MySQL_Method.SQLite_search(sql5);
            string quest_number = (ds5.Tables[0].Rows.Count + 1).ToString();
            textBox3.Text = auto_num_unity + "-" + quest_number;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //检查一下至少部署了一个人
            int whether_people = 0;
            for (int i = 0; i < dataGridView1.Rows.Count; i++) {
                if (dataGridView1.Rows[i].Cells[0].Value.ToString() == "True") {
                    whether_people = 1;
                }
            }
            if(whether_people == 1) {
                string today_time = MyTools_Method.Date_ToNum(label11.Text).ToString();
                string group = "";
                if (label11.Text.Contains("试验班")) {
                    group = "试验班";
                }
                else if (label11.Text.Contains("试制班")) {
                    group = "试制班";
                }
                else {
                    group = MyConstant_1.now_group;
                }

                //录入任务
                string num_in = textBox1.Text;
                string num_order = textBox2.Text;
                string num_unify = textBox3.Text;
                string part = textBox4.Text;
                string name = textBox5.Text;
                string ask = textBox6.Text;
                string time = textBox7.Text;

                string type = comboBox1.Text;

                //加一个难度
                string difficult = textBox9.Text;

                //正则：8位数字

                if (MyRegular_Method.Eight_Number(time) == true) {
                    MyOtherWin_Method.Add_NewQuestTemp(num_in, num_order, num_unify, part, name, ask, time, type, difficult);
                    this.Close();
                }
                else {
                    MessageBox.Show("日期不符合格式，请输入8位数字");
                }

                //发布追加任务

                MyOtherWin_Method.Add_Publish(today_time, num_unify, name, group);

                //安排人员
                for (int i = 0; i < dataGridView1.Rows.Count; i++) {
                    if (dataGridView1.Rows[i].Cells[0].Value.ToString() == "True") {
                        string worker_num = dataGridView1.Rows[i].Cells[1].Value.ToString();
                        MyOtherWin_Method.Add_NewDistributePlan(today_time, num_unify, worker_num, group);
                    }
                }

                this.Close();
            }
            else {
                MessageBox.Show("请至少选择一个人员");
            }

            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
