﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace worktime
{
    public partial class F4_2_Change_quest : Form
    {
        public F4_2_Change_quest()
        {
            InitializeComponent();
        }

        public F4_2_Change_quest(string num)
        {
            InitializeComponent();
            label9.Text = num;
        }

        private void F4_2_Change_quest_Load(object sender, EventArgs e)
        {
            string sql = $"SELECT* FROM 任务信息 WHERE 统一编号 = '{label9.Text}'";
            DataSet ds = MySQL_Method.SQLite_search(sql);

            textBox2.Text = ds.Tables[0].Rows[0]["生产订单号"].ToString();
            textBox3.Text = ds.Tables[0].Rows[0]["内部编号"].ToString();
            textBox4.Text = ds.Tables[0].Rows[0]["编制部门"].ToString();
            textBox5.Text = ds.Tables[0].Rows[0]["项目名"].ToString();
            textBox6.Text = ds.Tables[0].Rows[0]["项目要求"].ToString();
            textBox7.Text = ds.Tables[0].Rows[0]["录入时间"].ToString();
            textBox1.Text = ds.Tables[0].Rows[0]["项目等级"].ToString();
            comboBox1.SelectedIndex = comboBox1.Items.IndexOf(ds.Tables[0].Rows[0]["项目分类"].ToString());

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql = $"UPDATE 任务信息 SET 生产订单号 = '{textBox2.Text}', 内部编号 = '{textBox3.Text}', 编制部门 = '{textBox4.Text}', 项目名 = '{textBox5.Text}', 项目要求 = '{textBox6.Text}', 录入时间 = {textBox7.Text}, 项目分类 = '{comboBox1.Text}',项目等级 = '{textBox1.Text}' WHERE 统一编号 = '{label9.Text}'";
            MySQL_Method.SQLite_update(sql);
            this.Close();
        }
    }
}
