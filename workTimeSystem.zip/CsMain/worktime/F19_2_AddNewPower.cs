﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace worktime
{
    public partial class F19_2_AddNewPower : Form
    {
        public F19_2_AddNewPower()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string user = textBox1.Text;
            string password = textBox2.Text;
            string power_kind = comboBox1.Text;

            try {
                string sql = $"insert into [权限] (账号,密码,用户类型)values('{user}','{password}','{power_kind}')";
                MySQL_Method.SQLite_add(sql);

                this.Close();
            }
            catch { MessageBox.Show("账号重复"); }

        }

        private void F19_2_AddNewPower_Load(object sender, EventArgs e)
        {
            comboBox1.SelectedIndex = comboBox1.Items.IndexOf("管理员");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
