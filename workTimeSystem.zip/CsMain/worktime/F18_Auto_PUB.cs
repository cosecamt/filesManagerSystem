﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace worktime
{
    public partial class F18_Auto_PUB : Form
    {
        public F18_Auto_PUB()
        {
            InitializeComponent();
        }

        public F18_Auto_PUB(string num, string name)
        {
            InitializeComponent();
            label3.Text = num;
            label4.Text = name;
        }
        private void F18_Auto_PUB_Load(object sender, EventArgs e)
        {
            MyConstant_1.Auto_Publish_OK = "取消";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MyConstant_1.Auto_Publish_OK = "确定";
            this.Close();
        }
    }
}
