﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Collections;

namespace worktime
{
    public partial class F10_Today_View : Form
    {
        public F10_Today_View()
        {
            InitializeComponent();
        }

        public F10_Today_View(string time, string group)
        {
            InitializeComponent();
            label2.Text = time;
            label3.Text = group;
            this.Text = "今日总结-" + group;
        }

        private void F10_Today_View_Load(object sender, EventArgs e)
        {

            //this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader;


            string group = label3.Text;
            string time = label2.Text;

            //这个地方可能比较复杂，要理清逻辑
            //1.查人员表，先把本组人放进来，如果有暂时不在这个组的，后面再补；
            //2.查本日分配标记，填写项目名并在本行全部写上“未填写”；
            //3.查看本日的废弃属性，直接填写，一般肯定是覆盖了“未填写”；
            //4.查台架任务，并查值班人员，写入“未填写”；
            //5.查台架分配，直接覆盖；
            //6.请假时间填写；
            //7.计算加班时间并填写;
            //8.计算总工时并填写；
            //以上过程中遇到有问题的人，全部在后面加上“（外组）”，由于没想到好的处理方法，台架值班暂时也这样处理

            this.dataGridView1.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            this.dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridView1.Rows.Clear();
            DataTable dt = new DataTable();//建立个数据表
            ArrayList holi_human = new ArrayList();//用于记录已经有的人

            //先把名字作为列
            string sql = $"SELECT * FROM 员工信息 WHERE 所属班组 = '{group}'";
            DataSet ds = MySQL_Method.SQLite_search(sql);

            dt.Columns.Add(new DataColumn("   任务   /   姓名   ", typeof(string)));//在表中添加string类型的列
            foreach (DataRow row in ds.Tables[0].Rows) {
                dt.Columns.Add(new DataColumn($"{row["姓名"].ToString()}\r\n-{row["工号"].ToString()}", typeof(string)));//在表中添加string类型的列
                holi_human.Add(row["工号"].ToString());
            }
                        
            //先把分配到的全都写上“未填报”
            sql = $"SELECT* FROM 任务分配0{group} INNER JOIN 员工信息 ON 任务分配0{group}.工号 = 员工信息.工号 INNER JOIN 任务信息 ON 任务分配0{group}.统一编号 = 任务信息.统一编号 WHERE 发布时间 = {label2.Text} AND 工作类型 = '（分配标记）'";
            DataSet ds2 = MySQL_Method.SQLite_search(sql);
            foreach (DataRow row in ds2.Tables[0].Rows) {
                int t = 0;
                foreach (DataRow row_dt in dt.Rows) {
                    if (row_dt["   任务   /   姓名   "].ToString() == row["项目名"].ToString() + "---" + row["统一编号"].ToString()) {
                        row_dt[row["姓名"].ToString() + "\r\n-" + row["工号"].ToString()] = "未填报！";
                        t = 1;
                    }
                }
                if (t == 0) {
                    DataRow dr = dt.NewRow();
                    dr["   任务   /   姓名   "] = row["项目名"].ToString() + "---" + row["统一编号"].ToString();
                    dr[row["姓名"].ToString() + "\r\n-" + row["工号"].ToString()] = "未填报！";
                    dt.Rows.Add(dr);
                }
            }

            //填工时系数
            sql = $"SELECT* FROM 任务分配0{group} INNER JOIN 员工信息 ON 任务分配0{group}.工号 = 员工信息.工号 INNER JOIN 任务信息 ON 任务分配0{group}.统一编号 = 任务信息.统一编号 WHERE 发布时间 = {label2.Text} AND 工作类型 == '废弃属性'";

            DataSet ds3 = MySQL_Method.SQLite_search(sql);
            foreach (DataRow row in ds3.Tables[0].Rows) {
                foreach (DataRow row_dt in dt.Rows) {
                    if (row_dt["   任务   /   姓名   "].ToString() == row["项目名"].ToString() + "---" + row["统一编号"].ToString()) {
                        if (row_dt[row["姓名"].ToString() + "\r\n-" + row["工号"].ToString()].ToString() == "未填报！") {
                            row_dt[row["姓名"].ToString() + "\r\n-" + row["工号"].ToString()] = row["工作小时"].ToString() + "h" + "*" + row["工时系数"].ToString();
                        }
                        else {
                            row_dt[row["姓名"].ToString() + "\r\n-" + row["工号"].ToString()] = row_dt[row["姓名"].ToString() + "\r\n-" + row["工号"].ToString()] + "+" + row["工作小时"].ToString() + "h" + "*" + row["工时系数"].ToString();
                        }
                    }
                }
            }

            //台架部分追加
            DataRow dr4 = dt.NewRow();
            dr4["   任务   /   姓名   "] = "（以下为台架）";
            dt.Rows.Add(dr4);

            //先把名字弄上去
            string sql10 = $"SELECT* FROM 台架发布 INNER JOIN 员工信息 ON 台架发布.工号 = 员工信息.工号 WHERE 发布时间 = {label2.Text} AND 所属班组 = '{group}' AND 数据类型 = '人员'";
            DataSet ds10 = MySQL_Method.SQLite_search(sql10);
            foreach (DataRow row in ds10.Tables[0].Rows) {
                if (holi_human.Contains(row["工号"].ToString()) == true) {

                }
                else {
                    dt.Columns.Add(new DataColumn($"{row["姓名"].ToString()}-{row["工号"].ToString()}", typeof(string)));//在表中添加int类型的列
                }
            }
            //然后把（未填报）写入
            string sql11 = $"SELECT* FROM 台架发布 INNER JOIN 任务信息 ON 台架发布.统一编号 = 任务信息.统一编号 WHERE 发布时间 = {label2.Text} AND 数据类型 = '项目'";
            DataSet ds11 = MySQL_Method.SQLite_search(sql11);
            foreach (DataRow row in ds11.Tables[0].Rows) {
                DataRow dr5 = dt.NewRow();
                foreach (DataRow row2 in ds10.Tables[0].Rows) {
                    dr5["   任务   /   姓名   "] = row["项目名"].ToString() + "---" + row["统一编号"].ToString();
                    dr5[row2["姓名"].ToString() + "\r\n-" + row2["工号"].ToString()] = "未填报！";
                }
                dt.Rows.Add(dr5);
            }
            //把工时写入
            string sql12 = $"SELECT* FROM 台架分配 INNER JOIN 员工信息 ON 台架分配.工号 = 员工信息.工号 INNER JOIN 任务信息 ON 台架分配.统一编号 = 任务信息.统一编号 WHERE 发布时间 = {label2.Text} AND 所属班组 = '{group}'";

            DataSet ds12 = MySQL_Method.SQLite_search(sql12);
            foreach (DataRow row in ds12.Tables[0].Rows) {
                foreach (DataRow row_dt in dt.Rows) {
                    if (row_dt["   任务   /   姓名   "].ToString() == row["项目名"].ToString() + "---" + row["统一编号"].ToString()) {
                        if (row_dt[row["姓名"].ToString() + "\r\n-" + row["工号"].ToString()].ToString() == "未填报！") {
                            row_dt[row["姓名"].ToString() + "\r\n-" + row["工号"].ToString()] = row["工作小时"].ToString() + "h" + "*" + row["工时系数"].ToString();
                        }
                        else {
                            row_dt[row["姓名"].ToString() + "\r\n-" + row["工号"].ToString()] = row_dt[row["姓名"].ToString() + "\r\n-" + row["工号"].ToString()] + "+" + row["工作小时"].ToString() + "h" + "*" + row["工时系数"].ToString();
                        }
                    }
                }

            }

            //请假部分添加

            DataRow dr3 = dt.NewRow();
            dr3["   任务   /   姓名   "] = "";
            dt.Rows.Add(dr3);

            dr3 = dt.NewRow();
            dr3["   任务   /   姓名   "] = "请假:";
            dt.Rows.Add(dr3);


            string sql4 = $"SELECT* FROM 任务分配0{group} INNER JOIN 员工信息 ON 任务分配0{group}.工号 = 员工信息.工号 WHERE 发布时间 = {label2.Text} AND 工作类型 = '（请假）'";
            DataSet ds6 = MySQL_Method.SQLite_search(sql4);
            foreach (DataRow row in ds6.Tables[0].Rows) {
                if (holi_human.Contains(row["工号"].ToString()) == true) {
                    dr3[row["姓名"].ToString() + "\r\n-" + row["工号"].ToString()] = row["工作小时"].ToString();
                }
                else {
                    dt.Columns.Add(new DataColumn($"{row["姓名"].ToString()}-{row["工号"].ToString()}", typeof(string)));//在表中添加int类型的列
                    dr3[row["姓名"].ToString() + "\r\n-" + row["工号"].ToString()] = row["工作小时"].ToString();
                }

            }

            //加班部分添加

            //查询是否为假期，最后新加的功能，忘了有多少语句了，直接写个7吧
            string sql7 = $"SELECT* FROM 每日流程0{group} WHERE 发布时间 = {label2.Text}";
            DataSet ds7 = MySQL_Method.SQLite_search(sql7);
            string holi_or = ds7.Tables[0].Rows[0]["是否假期"].ToString();

            //查完了

            DataRow dr2 = dt.NewRow();
            dr2["   任务   /   姓名   "] = "";
            dt.Rows.Add(dr2);

            dr2 = dt.NewRow();
            dr2["   任务   /   姓名   "] = "加班:";
            dt.Rows.Add(dr2);

            //string sql2 = $"SELECT DISTINCT 任务分配0{group}.工号 FROM 任务分配0{group} INNER JOIN 员工信息 ON 任务分配0{group}.工号 = 员工信息.工号 WHERE 发布时间 = {label2.Text} AND 工作类型 <> '（分配标记）' AND 工作类型 <> '（请假）'";
            string sql2 = $"SELECT * FROM 员工信息 WHERE 所属班组 = '{group}'";
            DataSet ds4 = MySQL_Method.SQLite_search(sql2);
            foreach (DataRow row in ds4.Tables[0].Rows) {
                string name_time = row["工号"].ToString();
                string sql3 = $"SELECT * FROM 任务分配0{group} INNER JOIN 员工信息 ON 任务分配0{group}.工号 = 员工信息.工号 WHERE 发布时间 = {label2.Text} AND 工作类型 <> '（分配标记）' AND 工作类型 <> '（请假）' AND 任务分配0{group}.工号 = '{name_time}'";
                DataSet ds5 = MySQL_Method.SQLite_search(sql3);
                double overtime = 0;
                foreach (DataRow row2 in ds5.Tables[0].Rows) {
                    overtime += Convert.ToDouble(row2["工作小时"]);
                }

                //看看能不能直接动用以前的表，就不用循环查了
                //上面部分是普通工作的小时，接下来要加上台架和请假
                //先来台架
                foreach (DataRow row3 in ds12.Tables[0].Rows) {
                    if (name_time == row3["工号"].ToString()) {
                        overtime += Convert.ToDouble(row3["工作小时"]);
                    }
                }

                //再来请假
                foreach (DataRow row3 in ds6.Tables[0].Rows) {
                    if (name_time == row3["工号"].ToString()) {
                        overtime += Convert.ToDouble(row3["工作小时"]);
                    }
                }

                overtime -= 8;
                if (overtime >= 0 && holi_or == "否") {
                    dr2[row["姓名"].ToString() + "\r\n-" + row["工号"].ToString()] = overtime.ToString();
                }
                else if (holi_or == "是") { 
                    dr2[row["姓名"].ToString() + "\r\n-" + row["工号"].ToString()] = (overtime + 8).ToString();
                }
                else {
                    dr2[row["姓名"].ToString() + "\r\n-" + row["工号"].ToString()] = "0";
                }


                
            }

            //最后价个总工时
            DataRow dr20 = dt.NewRow();
            dr20["   任务   /   姓名   "] = "";
            dt.Rows.Add(dr20);

            dr20 = dt.NewRow();
            dr20["   任务   /   姓名   "] = "总工时:";
            dt.Rows.Add(dr20);

            foreach (DataRow row in ds4.Tables[0].Rows) {
                string name_time = row["工号"].ToString();
                string sql3 = $"SELECT * FROM 任务分配0{group} INNER JOIN 员工信息 ON 任务分配0{group}.工号 = 员工信息.工号 WHERE 发布时间 = {label2.Text} AND 工作类型 <> '（分配标记）' AND 工作类型 <> '（请假）' AND 任务分配0{group}.工号 = '{name_time}'";
                DataSet ds5 = MySQL_Method.SQLite_search(sql3);
                double alltime = 0;
                foreach (DataRow row2 in ds5.Tables[0].Rows) {
                    alltime = alltime + (Convert.ToDouble(row2["工作小时"]) * Convert.ToDouble(row2["工时系数"]));
                }

                foreach (DataRow row3 in ds12.Tables[0].Rows) {
                    if (name_time == row3["工号"].ToString()) {
                        alltime = alltime + (Convert.ToDouble(row3["工作小时"]) * Convert.ToDouble(row3["工时系数"]));
                    }
                }
                dr20[row["姓名"].ToString() + "\r\n-" + row["工号"].ToString()] = alltime.ToString();

                                
            }

                //关联控件和数据表
            dataGridView1.DataSource = dt;
            dataGridView1.Columns[0].Width = 200;
            for(int i =1;i < dataGridView1.Columns.Count; i++) {
                dataGridView1.Columns[i].Width = 70;
            }
            for (int i = 0; i < dataGridView1.Columns.Count; i++) {
                dataGridView1.Columns[i].SortMode = DataGridViewColumnSortMode.NotSortable;
            }

            



            /*
            ArrayList holi_human = new ArrayList();//用于记录关于请假的人名单





            //先把名字作为列
            string sql = $"SELECT DISTINCT 任务分配0{group}.工号,姓名 FROM 任务分配0{group} INNER JOIN 员工信息 ON 任务分配0{group}.工号 = 员工信息.工号 WHERE 发布时间 = {label2.Text} AND 工作类型 = '（分配标记）'";
            DataSet ds = MySQL_Method.SQLite_search(sql);

            dt.Columns.Add(new DataColumn("任务/姓名", typeof(string)));//在表中添加string类型的列
            foreach (DataRow row in ds.Tables[0].Rows) {
                dt.Columns.Add(new DataColumn($"{row["姓名"].ToString()}-{row["工号"].ToString()}", typeof(string)));//在表中添加string类型的列
                holi_human.Add(row["工号"].ToString());
            }

            //先把分配到的全都写上“未填报”
            sql = $"SELECT* FROM 任务分配0{group} INNER JOIN 员工信息 ON 任务分配0{group}.工号 = 员工信息.工号 INNER JOIN 任务信息 ON 任务分配0{group}.统一编号 = 任务信息.统一编号 WHERE 发布时间 = {label2.Text} AND 工作类型 = '（分配标记）'";
            DataSet ds2 = MySQL_Method.SQLite_search(sql);
            foreach (DataRow row in ds2.Tables[0].Rows) {
                int t = 0;

                foreach (DataRow row_dt in dt.Rows) {
                    if (row_dt["任务/姓名"].ToString() == row["项目名"].ToString() + "---" + row["统一编号"].ToString()) {
                        row_dt[row["姓名"].ToString() + "-" + row["工号"].ToString()] = "未填报！";
                        t = 1;
                    }

                }

                if (t == 0) {
                    DataRow dr = dt.NewRow();
                    dr["任务/姓名"] = row["项目名"].ToString() + "---" + row["统一编号"].ToString();
                    dr[row["姓名"].ToString() + "-" + row["工号"].ToString()] = "未填报！";
                    dt.Rows.Add(dr);
                    //holi_human.Add(row["工号"].ToString());
                }
            }

            //填工时系数
            sql = $"SELECT* FROM 任务分配0{group} INNER JOIN 员工信息 ON 任务分配0{group}.工号 = 员工信息.工号 INNER JOIN 任务信息 ON 任务分配0{group}.统一编号 = 任务信息.统一编号 WHERE 发布时间 = {label2.Text} AND 工作类型 != '（分配标记）' AND 工作类型 != '（请假）'";

            DataSet ds3 = MySQL_Method.SQLite_search(sql);
            foreach (DataRow row in ds3.Tables[0].Rows) {
                foreach (DataRow row_dt in dt.Rows) {
                    if (row_dt["任务/姓名"].ToString() == row["项目名"].ToString() + "---" + row["统一编号"].ToString()) {
                        if (row_dt[row["姓名"].ToString() + "-" + row["工号"].ToString()].ToString() == "未填报！") {
                            row_dt[row["姓名"].ToString() + "-" + row["工号"].ToString()] = row["工作小时"].ToString() + "h" + "*" + row["工时系数"].ToString();
                        }
                        else {
                            row_dt[row["姓名"].ToString() + "-" + row["工号"].ToString()] = row_dt[row["姓名"].ToString() + "-" + row["工号"].ToString()] + "+" + row["工作小时"].ToString() + "h" + "*" + row["工时系数"].ToString();
                        }
                    }
                }
            }

            //加班部分添加

            //查询是否为假期，最后新加的功能，忘了有多少语句了，直接写个7吧
            string sql7 = $"SELECT* FROM 每日流程0{group} WHERE 发布时间 = {label2.Text}";
            DataSet ds7 = MySQL_Method.SQLite_search(sql7);
            string holi_or = ds7.Tables[0].Rows[0]["是否假期"].ToString();

            //查完了

            DataRow dr2 = dt.NewRow();
            dr2["任务/姓名"] = "";
            dt.Rows.Add(dr2);

            dr2 = dt.NewRow();
            dr2["任务/姓名"] = "加班:";
            dt.Rows.Add(dr2);

            string sql2 = $"SELECT DISTINCT 任务分配0{group}.工号 FROM 任务分配0{group} INNER JOIN 员工信息 ON 任务分配0{group}.工号 = 员工信息.工号 WHERE 发布时间 = {label2.Text} AND 工作类型 <> '（分配标记）' AND 工作类型 <> '（请假）'";

            DataSet ds4 = MySQL_Method.SQLite_search(sql2);
            foreach (DataRow row in ds4.Tables[0].Rows) {
                string name_time = row["工号"].ToString();
                string sql3 = $"SELECT * FROM 任务分配0{group} INNER JOIN 员工信息 ON 任务分配0{group}.工号 = 员工信息.工号 WHERE 发布时间 = {label2.Text} AND 工作类型 <> '（分配标记）' AND 工作类型 <> '（请假）' AND 任务分配0{group}.工号 = '{name_time}'";
                DataSet ds5 = MySQL_Method.SQLite_search(sql3);

                double overtime = 0;
                foreach (DataRow row2 in ds5.Tables[0].Rows) {
                    overtime += Convert.ToDouble(row2["工作小时"]);
                }
                overtime -= 8;
                if (overtime >= 0 && holi_or == "否") {
                    dr2[ds5.Tables[0].Rows[0]["姓名"].ToString() + "-" + ds5.Tables[0].Rows[0]["工号"].ToString()] = overtime.ToString();
                }
                else if (holi_or == "是") {
                    dr2[ds5.Tables[0].Rows[0]["姓名"].ToString() + "-" + ds5.Tables[0].Rows[0]["工号"].ToString()] = (overtime + 8).ToString();
                }

                else {
                    dr2[ds5.Tables[0].Rows[0]["姓名"].ToString() + "-" + ds5.Tables[0].Rows[0]["工号"].ToString()] = "0";
                }
            }

            //请假部分添加

            DataRow dr3 = dt.NewRow();
            dr3["任务/姓名"] = "";
            dt.Rows.Add(dr3);

            dr3 = dt.NewRow();
            dr3["任务/姓名"] = "请假:";
            dt.Rows.Add(dr3);


            string sql4 = $"SELECT* FROM 任务分配0{group} INNER JOIN 员工信息 ON 任务分配0{group}.工号 = 员工信息.工号 WHERE 发布时间 = {label2.Text} AND 工作类型 = '（请假）'";
            DataSet ds6 = MySQL_Method.SQLite_search(sql4);
            foreach (DataRow row in ds6.Tables[0].Rows) {
                if (holi_human.Contains(row["工号"].ToString()) == true) {
                    dr3[row["姓名"].ToString() + "-" + row["工号"].ToString()] = row["工作小时"].ToString();
                }
                else {
                    dt.Columns.Add(new DataColumn($"{row["姓名"].ToString()}-{row["工号"].ToString()}", typeof(string)));//在表中添加int类型的列
                    dr3[row["姓名"].ToString() + "-" + row["工号"].ToString()] = row["工作小时"].ToString();
                }

            }

            //台架部分追加
            DataRow dr4 = dt.NewRow();
            dr4["任务/姓名"] = "（以下为台架）";
            dt.Rows.Add(dr4);

            //先把名字弄上去
            string sql10 = $"SELECT* FROM 台架发布 INNER JOIN 员工信息 ON 台架发布.工号 = 员工信息.工号 WHERE 发布时间 = {label2.Text} AND 所属班组 = '{group}' AND 数据类型 = '人员'";
            DataSet ds10 = MySQL_Method.SQLite_search(sql10);
            foreach (DataRow row in ds10.Tables[0].Rows) {
                if (holi_human.Contains(row["工号"].ToString()) == true) {

                }
                else {
                    dt.Columns.Add(new DataColumn($"{row["姓名"].ToString()}-{row["工号"].ToString()}", typeof(string)));//在表中添加int类型的列
                }
            }
            //然后把（未填报）写入
            string sql11 = $"SELECT* FROM 台架发布 INNER JOIN 任务信息 ON 台架发布.统一编号 = 任务信息.统一编号 WHERE 发布时间 = {label2.Text} AND 数据类型 = '项目'";
            DataSet ds11 = MySQL_Method.SQLite_search(sql11);
            foreach (DataRow row in ds11.Tables[0].Rows) {
                DataRow dr5 = dt.NewRow();
                foreach (DataRow row2 in ds10.Tables[0].Rows) {
                    dr5["任务/姓名"] = row["项目名"].ToString() + "---" + row["统一编号"].ToString();
                    dr5[row2["姓名"].ToString() + "-" + row2["工号"].ToString()] = "未填报！";
                }
                dt.Rows.Add(dr5);
            }
            //把工时写入
            string sql12 = $"SELECT* FROM 台架分配 INNER JOIN 员工信息 ON 台架分配.工号 = 员工信息.工号 INNER JOIN 任务信息 ON 台架分配.统一编号 = 任务信息.统一编号 WHERE 发布时间 = {label2.Text}";

            DataSet ds12 = MySQL_Method.SQLite_search(sql12);
            foreach (DataRow row in ds12.Tables[0].Rows) {
                foreach (DataRow row_dt in dt.Rows) {
                    if (row_dt["任务/姓名"].ToString() == row["项目名"].ToString() + "---" + row["统一编号"].ToString()) {
                        if (row_dt[row["姓名"].ToString() + "-" + row["工号"].ToString()].ToString() == "未填报！") {
                            row_dt[row["姓名"].ToString() + "-" + row["工号"].ToString()] = row["工作小时"].ToString() + "h" + "*" + row["工时系数"].ToString();
                        }
                        else {
                            row_dt[row["姓名"].ToString() + "-" + row["工号"].ToString()] = row_dt[row["姓名"].ToString() + "-" + row["工号"].ToString()] + "+" + row["工作小时"].ToString() + "h" + "*" + row["工时系数"].ToString();
                        }
                    }
                }
            }
            */





        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
