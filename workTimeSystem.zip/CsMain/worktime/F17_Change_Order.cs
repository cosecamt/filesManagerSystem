﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace worktime
{
    public partial class F17_Change_Order : Form
    {
        public F17_Change_Order()
        {
            InitializeComponent();
        }

        public F17_Change_Order(string group)
        {
            InitializeComponent();
            label2.Text = group;
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void F17_Change_Order_Load(object sender, EventArgs e)
        {
            listView1.Items.Clear();
            //查询所有员工的信息
            string sql = $"SELECT* FROM 员工信息 WHERE 是否隐藏 = '否' AND 所属班组 = '{label2.Text}'";
            DataSet ds = MySQL_Method.SQLite_search(sql);

            foreach (DataRow row in ds.Tables[0].Rows) {
                ListViewItem first = new ListViewItem(row["工号"].ToString());
                first.SubItems.Add(row["姓名"].ToString());
                listView1.Items.Add(first);
            }
        }

        private void listView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            //干脆抄到右边去
            string num = listView1.FocusedItem.SubItems[0].Text;
            string name = listView1.FocusedItem.SubItems[1].Text;
            //string type = listView1.FocusedItem.SubItems[2].Text;

            //已被标红则不能进行
            if (listView1.FocusedItem.SubItems[0].ForeColor == Color.Red) {
                MessageBox.Show("该员工已经被选择了！");
            }
            else {
                //先抄写，当日说明另说
                ListViewItem first = new ListViewItem(num);
                first.SubItems.Add(name);
                //first.SubItems.Add(type);

                //录完了，绘制
                listView2.Items.Add(first);
                MyTools_Method.OrderPeople_ToRed_WhenBench(this);

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void listView2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listView2_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (listView2.FocusedItem != null) {
                listView2.Items.Remove(listView2.SelectedItems[0]);
                MyTools_Method.OrderPeople_ToRed_WhenBench(this);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (listView1.Items.Count == listView2.Items.Count) {
                //先删后加
                string sql = $"DELETE FROM 员工信息 WHERE 所属班组 = '{label2.Text}'";
                MySQL_Method.SQLite_delete(sql);

                for (int i = 0; i < listView2.Items.Count; i++) {
                    string num = listView2.Items[i].SubItems[0].Text;
                    string name = listView2.Items[i].SubItems[1].Text;

                    string sql2 = $"insert into 员工信息 (工号,姓名,所属班组,是否隐藏)values({num},'{name}','{label2.Text}','否')";
                    MySQL_Method.SQLite_add(sql2);
                }
                this.Close();

            }
            else {
                MessageBox.Show("必须保证所有人员被选择");
            }
        }
    }
}
