﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace worktime
{
    public partial class F5_4_BenchWorker_Change : Form
    {
        public F5_4_BenchWorker_Change()
        {
            InitializeComponent();
        }

        public F5_4_BenchWorker_Change(string publish_time)
        {
            InitializeComponent();
            label4.Text = publish_time;
        }

        private void F5_4_BenchWorker_Change_Load(object sender, EventArgs e)
        {
            MyOtherWin_Method.Read_TwoClassWorker_ForBench_WhenReport(this, label4.Text);//把人员信息和上次是否值班填进去
            MyOtherWin_Method.Check_TodayBenchWorker_WhenReport(this, label4.Text);//把今天排班的人员打勾
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string time = label4.Text;

            //先遍历所有没有勾选的
            //对每一个没被勾选的人删除相关，不用查了，直接删，管他原本有没有

            //先试验班
            for (int i = 0; i < dataGridView1.Rows.Count; i++) {
                if (dataGridView1.Rows[i].Cells[0].Value.ToString() == "False") {
                    string worker_num = dataGridView1.Rows[i].Cells[1].Value.ToString();
                    MyOtherWin_Method.DeleteWorker_BeforeChangeWorker_WhenReport(time, worker_num);
                }
            }
            //再试制班
            for (int i = 0; i < dataGridView2.Rows.Count; i++) {
                if (dataGridView2.Rows[i].Cells[0].Value.ToString() == "False") {
                    string worker_num = dataGridView2.Rows[i].Cells[1].Value.ToString();
                    MyOtherWin_Method.DeleteWorker_BeforeChangeWorker_WhenReport(time, worker_num);
                }
            }

            //遍历所有勾选的
            //对于每一个勾选的人，查表，看看存不存在，

            //先试验班
            for (int i = 0; i < dataGridView1.Rows.Count; i++) {
                if (dataGridView1.Rows[i].Cells[0].Value.ToString() == "True") {
                    string worker_num = dataGridView1.Rows[i].Cells[1].Value.ToString();
                    bool Reslut_OfSearch = MyOtherWin_Method.Search_DistributePlan_Bench(time, worker_num);
                    //存在的不处理
                    //不存在的，添加
                    if (Reslut_OfSearch == false) {
                        MyOtherWin_Method.AddBench_NewDistributePlan(time, worker_num);
                    }
                }
            }
            //再试制班
            for (int i = 0; i < dataGridView2.Rows.Count; i++) {
                if (dataGridView2.Rows[i].Cells[0].Value.ToString() == "True") {
                    string worker_num = dataGridView2.Rows[i].Cells[1].Value.ToString();
                    bool Reslut_OfSearch = MyOtherWin_Method.Search_DistributePlan_Bench(time, worker_num);
                    //存在的不处理
                    //不存在的，添加
                    if (Reslut_OfSearch == false) {
                        MyOtherWin_Method.AddBench_NewDistributePlan(time, worker_num);
                    }
                }
            }

            this.Close();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString() == "True") {
                dataGridView1.Rows[e.RowIndex].Cells[0].Value = false;
            }
            else {
                dataGridView1.Rows[e.RowIndex].Cells[0].Value = true;
            }
        }

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView2.Rows[e.RowIndex].Cells[0].Value.ToString() == "True") {
                dataGridView2.Rows[e.RowIndex].Cells[0].Value = false;
            }
            else {
                dataGridView2.Rows[e.RowIndex].Cells[0].Value = true;
            }
        }
    }
}
