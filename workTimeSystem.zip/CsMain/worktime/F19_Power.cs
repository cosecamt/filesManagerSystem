﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace worktime
{
    public partial class F19_Power : Form
    {
        public F19_Power()
        {
            InitializeComponent();
        }

        private void F19_Power_Load(object sender, EventArgs e)
        {
            //刷新权限名单
            MyOtherWin_Method.Refresh_OfPower(this);

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (listView1.FocusedItem != null) {
                string user = listView1.FocusedItem.SubItems[0].Text;
                string sql = $"DELETE FROM 权限 WHERE 账号 = '{user}'";
                MySQL_Method.SQLite_delete(sql);
                //刷新权限名单
                MyOtherWin_Method.Refresh_OfPower(this);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            F19_2_AddNewPower F19_2_AddNewPower = new F19_2_AddNewPower();
            F19_2_AddNewPower.ShowDialog();
            //刷新权限名单
            MyOtherWin_Method.Refresh_OfPower(this);
        }

        private void listView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (listView1.FocusedItem != null) {
                string num = listView1.FocusedItem.Text;
                F19_3_Change_Power F19_3_Change_Power = new F19_3_Change_Power(num);
                F19_3_Change_Power.ShowDialog();
                //刷新权限名单
                MyOtherWin_Method.Refresh_OfPower(this);
            }
        }
    }
}
