﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace worktime
{
    public partial class F11_Login_In : Form
    {
        public F11_Login_In()
        {
            InitializeComponent();
        }

        private void F11_Login_In_Load(object sender, EventArgs e)
        {
            try {
                string choose = MyIni_Method.getString("LogIn", "choose", "", @"data\setting.ini");
                string user = MyIni_Method.getString("LogIn", "user", "", @"data\setting.ini");
                string password = MyIni_Method.getString("LogIn", "password", "", @"data\setting.ini");
                MyConstant_1.conStr = MyIni_Method.getString("DataSite", "Site", "", @"data\setting.ini");
                MyOtherWin_Method.Auto_WriteIn_LastInfo(this, choose, user, password);//从INI填写上次的登录信息
            }
            catch {
                MessageBox.Show("配置文件不存在");
                MyOtherWin_Method.Auto_WriteIn_LastInfo(this, "1", "", "");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string name = textBox1.Text;
            string password = textBox2.Text;

            //先写入账号和密码到INI，类型等会再判断
            MyIni_Method.writeString("LogIn", "user", $"{name}", @"data\setting.ini");
            MyIni_Method.writeString("LogIn", "password", $"{password}", @"data\setting.ini");

            string kind_of_power = MyOtherWin_Method.Judge_KindOfPower(this);//判断勾选权限的种类
            MyOtherWin_Method.WriteIn_PowerInfo_ToIni(kind_of_power);
            string judge_result = MyOtherWin_Method.Judge_LoginPower(kind_of_power, name, password);

            if (judge_result == "登录失败") {
                MessageBox.Show("登录失败");
            }
            else {
                F1_Main F1_Main = new F1_Main();
                this.Hide();
                F1_Main.ShowDialog();
                this.Close();
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox1.ReadOnly = true;
            textBox2.Text = "";
            textBox2.ReadOnly = true;
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox1.ReadOnly = true;
            textBox2.Text = "";
            textBox2.ReadOnly = true;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            textBox1.ReadOnly = false;
            textBox2.ReadOnly = false;

            string user = MyIni_Method.getString("LogIn", "user", "", @"data\setting.ini");
            string password = MyIni_Method.getString("LogIn", "password", "", @"data\setting.ini");
            textBox1.Text = user;
            textBox2.Text = password;
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            textBox1.ReadOnly = false;
            textBox2.ReadOnly = false;

            string user = MyIni_Method.getString("LogIn", "user", "", @"data\setting.ini");
            string password = MyIni_Method.getString("LogIn", "password", "", @"data\setting.ini");
            textBox1.Text = user;
            textBox2.Text = password;
        }
    }
}
