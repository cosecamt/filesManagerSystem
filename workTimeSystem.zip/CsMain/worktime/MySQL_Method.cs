﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Data.SQLite;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;


namespace worktime
{
    class MySQL_Method   //此class记载：SQLite的增删改查类。
    {
        //单纯地“增”
        public static void SQLite_add(string sql)
        {
            //例句：string sql = $"insert into 员工信息 (工号,姓名,所属班组,是否隐藏)values({num},'{name}','{row}','否')";
            try {
                SQLiteConnection connect = new SQLiteConnection(MyConstant_1.conStr);
                SQLiteCommand cmd = new SQLiteCommand(sql, connect);
                connect.Open();
                cmd.ExecuteNonQuery();
                connect.Close();
            }
            catch (SQLiteException sqlex) {
                MessageBox.Show("数据库连接错误，错误源是" + sqlex);
            }
            catch {
                MessageBox.Show("其他错误");
            }

        }

        //单纯地“删”（估计永远用不着）←结果用到的相当多
        public static void SQLite_delete(string sql)
        {
            //例句：string sql = $"DELETE FROM 任务信息 WHERE 统一编号 = '{num}'";
            try {
                SQLiteConnection connect = new SQLiteConnection(MyConstant_1.conStr);
                SQLiteCommand cmd = new SQLiteCommand(sql, connect);
                connect.Open();
                int rows = cmd.ExecuteNonQuery();
                connect.Close();
            }
            catch (SQLiteException sqlex) {
                MessageBox.Show("数据库连接错误，错误源是" + sqlex);
            }
            catch {
                MessageBox.Show("其他错误");
            }

        }

        //单纯地“改”
        public static void SQLite_update(string sql)
        {
            //例句：string sql = $"UPDATE 员工信息 SET 是否隐藏 = '是' WHERE 工号 = {num}";
            try {
                SQLiteConnection connect = new SQLiteConnection(MyConstant_1.conStr);
                SQLiteCommand cmd = new SQLiteCommand(sql, connect);
                connect.Open();
                int rows = cmd.ExecuteNonQuery();
                connect.Close();
            }
            catch (SQLiteException sqlex) {
                MessageBox.Show("数据库连接错误，错误源是" + sqlex);
            }
            catch {
                MessageBox.Show("其他错误");
            }

        }

        //单纯地“查”
        public static DataSet SQLite_search(string sql)
        {
            //例句:string sql = "SELECT * FROM 员工信息 WHERE 是否隐藏 = '否'";

                DataSet ds = new DataSet();
                SQLiteConnection m_dbConnection = new SQLiteConnection(MyConstant_1.conStr);
                SQLiteDataAdapter oleDapAdapter = new SQLiteDataAdapter(sql, MyConstant_1.conStr);
                oleDapAdapter.Fill(ds);
                return ds;

        }

    }
}
