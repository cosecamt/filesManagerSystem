﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace worktime
{
    public partial class F9_data_way : Form
    {
        public F9_data_way()
        {
            InitializeComponent();
        }

        private void F9_data_way_Load(object sender, EventArgs e)
        {
            string last_connect = MyIni_Method.getString("DataSite", "Site", "", @"data\setting.ini");
            string write_in_text = MyOtherWin_Method.convert_IniData_to_WriteInData(last_connect); //将INI文件中记录的数据库连接剪切成用来显示的地址
            textBox1.Text = write_in_text;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MyConstant_1.conStr = $"Data Source={textBox1.Text};Version=3;";
            this.Close();
            //写入到INI，不用验证对错，要是错了就再改
            MyIni_Method.writeString("DataSite", "Site", $"{MyConstant_1.conStr}", @"data\setting.ini");
        }
    }
}
