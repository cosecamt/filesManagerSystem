﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace worktime
{
    public partial class F6_Dis : Form
    {
        public F6_Dis()
        {
            InitializeComponent();
        }

        public F6_Dis(string num, string time, string quest, string group)
        {
            InitializeComponent();
            label2.Text = num;
            label4.Text = time;
            label5.Text = quest;
            label7.Text = group;
        }

        private void F6_Dis_Load(object sender, EventArgs e)
        {
            MyOtherWin_Method.Read_Worker_AndThierQuest(this,label7.Text);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string time = label4.Text;
            string num = label2.Text;
            string quest = label5.Text;
            string group = label7.Text;

            for (int i = 0; i < dataGridView1.Rows.Count; i++) {
                if (dataGridView1.Rows[i].Cells[0].Value.ToString() == "True") {
                    string worker_num = dataGridView1.Rows[i].Cells[1].Value.ToString();
                    MyOtherWin_Method.Add_NewDistributePlan(time, num, worker_num, group);
                }
            }
            this.Close();
        }
    }
}
