﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Drawing;
using System.IO;
using System.Collections;

namespace worktime
{
    class MyTools_Method    //此class记载：全剧终使用比较频繁的小功能，比如8位数字和文字日期的互转之类的。
    {

        //8位数字转成文字日期
        //常用方法：time = MyMethod_3.num_to_date(Convert.ToInt32(row["时间"].ToString()));

        public static string Num_ToDate(int num)
        {
            string num_s = num.ToString();

            string year = num_s.Substring(0, 4);
            string month = num_s.Substring(4, 2);
            string day = num_s.Substring(6, 2);

            string date = $"{year}年{month}月{day}日";

            return date;
        }


        //文字日期转成8位数字
        //常用方法：string time = MyMethod_3.date_to_num(listBox2.SelectedItem.ToString()).ToString();
        public static int Date_ToNum(string date)
        {
            string year_s = date.Substring(0, 4);
            string month_s = date.Substring(5, 2);
            string day_s = date.Substring(8, 2);

            int year = Convert.ToInt32(year_s);
            int month = Convert.ToInt32(month_s);
            int day = Convert.ToInt32(day_s);

            int num = day + 100 * month + 10000 * year;

            return num;
        }

        //发布界面-寻找已选中的任务-染红
        public static void Find_HasChoose_ToRed(F5_Publish F5_Publish)
        {
            for (int i = 0; i < F5_Publish.listView1.Items.Count; i++) {
                F5_Publish.listView1.Items[i].SubItems[0].ForeColor = Color.Black;
                string left_num = F5_Publish.listView1.Items[i].SubItems[0].Text;
                for (int j = 0; j < F5_Publish.listView2.Items.Count; j++) {
                    string right_num = F5_Publish.listView2.Items[j].SubItems[0].Text;
                    if (left_num == right_num) {
                        F5_Publish.listView1.Items[i].SubItems[0].ForeColor = Color.Red;
                    }
                }

            }
        }

        //发布台架界面-寻找已选中的任务-染红
        public static void Find_HasChoose_ToRed_WhenBench(F5_2_Publish_Bench F5_2_Publish_Bench)
        {
            for (int i = 0; i < F5_2_Publish_Bench.listView1.Items.Count; i++) {
                F5_2_Publish_Bench.listView1.Items[i].SubItems[0].ForeColor = Color.Black;
                string left_num = F5_2_Publish_Bench.listView1.Items[i].SubItems[0].Text;
                for (int j = 0; j < F5_2_Publish_Bench.listView2.Items.Count; j++) {
                    string right_num = F5_2_Publish_Bench.listView2.Items[j].SubItems[0].Text;
                    if (left_num == right_num) {
                        F5_2_Publish_Bench.listView1.Items[i].SubItems[0].ForeColor = Color.Red;
                    }
                }

            }
        }

        //追加任务界面-寻找已选中的任务-染红
        public static void Find_HasChoose_ToRed_WhenAdd(F14_AddPlanQuest F14_AddPlanQuest)
        {
            //for (int i = 0; i < F14_AddPlanQuest.listView1.Items.Count; i++) {
            //    F14_AddPlanQuest.listView1.Items[i].SubItems[0].ForeColor = Color.Black;
            //    string left_num = F14_AddPlanQuest.listView1.Items[i].SubItems[0].Text;
            //    for (int j = 0; j < F14_AddPlanQuest.listView2.Items.Count; j++) {
            //        string right_num = F14_AddPlanQuest.listView2.Items[j].SubItems[0].Text;
            //        if (left_num == right_num) {
            //            F14_AddPlanQuest.listView1.Items[i].SubItems[0].ForeColor = Color.Red;
            //        }
            //    }

            //}

            for (int i = 0; i < F14_AddPlanQuest.listView1.Items.Count; i++) {
                string left_num = F14_AddPlanQuest.listView1.Items[i].SubItems[0].Text;
                for (int j = 0; j < F14_AddPlanQuest.listView2.Items.Count; j++) {
                    string right_num = F14_AddPlanQuest.listView2.Items[j].SubItems[0].Text;
                    if (left_num == right_num) {
                        F14_AddPlanQuest.listView1.Items[i].SubItems[0].ForeColor = Color.Red;
                    }
                }

            }



        }


        //任务排序界面-染红
        public static void OrderPeople_ToRed_WhenBench(F17_Change_Order F17_Change_Order)
        {
            for (int i = 0; i < F17_Change_Order.listView1.Items.Count; i++) {
                F17_Change_Order.listView1.Items[i].SubItems[0].ForeColor = Color.Black;
                string left_num = F17_Change_Order.listView1.Items[i].SubItems[0].Text;
                for (int j = 0; j < F17_Change_Order.listView2.Items.Count; j++) {
                    string right_num = F17_Change_Order.listView2.Items[j].SubItems[0].Text;
                    if (left_num == right_num) {
                        F17_Change_Order.listView1.Items[i].SubItems[0].ForeColor = Color.Red;
                    }
                }

            }
        }

        //删除文件夹下所有文件
        public static void DelectDir(string srcPath)
        {
            try {
                DirectoryInfo dir = new DirectoryInfo(srcPath);
                FileSystemInfo[] fileinfo = dir.GetFileSystemInfos();  //返回目录中所有文件和子目录
                foreach (FileSystemInfo i in fileinfo) {
                    if (i is DirectoryInfo)            //判断是否文件夹
                    {
                        DirectoryInfo subdir = new DirectoryInfo(i.FullName);
                        subdir.Delete(true);          //删除子目录和文件
                    }
                    else {
                        File.Delete(i.FullName);      //删除指定文件
                    }
                }
            }
            catch (Exception e) {
                throw;
            }
        }

        //检测并删除一个月以前的文件
        public static void DelectDir_BeforeOneMonth(string srcPath)
        {
            try {
                DirectoryInfo dir = new DirectoryInfo(srcPath);
                FileSystemInfo[] fileinfo = dir.GetFileSystemInfos();  //返回目录中所有文件和子目录

                //先看看今天的日期，并转成8位数字
                string DateLastMonth_STR = DateTime.Now.AddDays(-30).ToString("yyyyMMdd");
                int DateLastMonth_INT = Convert.ToInt32(DateLastMonth_STR);

                foreach (FileSystemInfo i in fileinfo) {
                    string FileName = i.Name;
                    string[] List_SplitFileName = FileName.Split('-');
                    string Time_ThisFile = Date_ToNum(List_SplitFileName[0]).ToString();
                    int Time_ThisFile_INT = Convert.ToInt32(Time_ThisFile);

                    //判断时间是否小于30天前
                    if (Time_ThisFile_INT < DateLastMonth_INT) {
                        File.Delete(i.FullName);      //删除指定文件
                    }

                }
            }
            catch (Exception e) {
                throw;
            }
        }



        //确认备份文件的存在与否
        public static bool Check_BackupDataExistence()
        {
            bool Wherher_Existence = false;
            //先看看今天是哪天
            string Time_Today = DateTime.Now.ToString("yyyyMMdd");

            string DataAddress_WhenBackup = @"data\BackupData";

            DirectoryInfo directory = new DirectoryInfo(DataAddress_WhenBackup);
            foreach (var file in directory.GetFiles()) {
                string[] List_SplitFileName = file.Name.Split('-');
                string Time_Backup = "";
                if (List_SplitFileName.Length >= 2) {
                    Time_Backup = Date_ToNum(List_SplitFileName[0]).ToString();
                }
                if (Time_Backup == Time_Today) {
                    Wherher_Existence = true;
                }
                
            }
            return Wherher_Existence;

        }





            
            //int i = 0;
            //DirectoryInfo directory = new DirectoryInfo(@"C:\Users\cosecant\Desktop\新建文件夹\");
            //foreach (var file in directory.GetFiles()) {
            //    i++;
            //}
            //Console.WriteLine(i);


        }



    }

   
