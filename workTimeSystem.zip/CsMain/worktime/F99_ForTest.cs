﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;

using System.IO;
using System.Collections;



namespace worktime
{
    public partial class F99_ForTest : Form
    {
        public F99_ForTest()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Console.WriteLine("文件名有{0}");
            string DataAddress_WhenBackup = MyConstant_1.conStr.Substring(12, MyConstant_1.conStr.Length - 36);
            Console.WriteLine(DataAddress_WhenBackup);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            label1.Text = "无";
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

            /*
            label1.Text = DateTime.Now.ToString("yyyy年MM月dd日-hh时mm分ss秒");
            MyConstant_1.Time_Meter++;
            label2.Text = MyConstant_1.Time_Meter.ToString();
            if(MyConstant_1.Time_Meter >= 3) {
                string pLocalFilePath = @"C:\Users\cosecant\Desktop\新建文件夹\data.txt";//要复制的文件路径
                string pSaveFilePath = $@"C:\Users\cosecant\Desktop\新建文件夹\{DateTime.Now.ToString("yyyy年MM月dd日hh时mm分ss秒")}.txt";//指定存储的路径
                if (File.Exists(pLocalFilePath))//必须判断要复制的文件是否存在
                {
                    File.Copy(pLocalFilePath, pSaveFilePath, true);//三个参数分别是源文件路径，存储路径，若存储路径有相同文件是否替换
                }
                MyConstant_1.Time_Meter = 0;

                int i = 0;
                DirectoryInfo directory = new DirectoryInfo(@"C:\Users\cosecant\Desktop\新建文件夹\");
                foreach (var file in directory.GetFiles()) {
                    i++;
                }
                Console.WriteLine(i);
                

            }
            */
        }

        private void F99_ForTest_Load(object sender, EventArgs e)
        {

        }
    }
}
