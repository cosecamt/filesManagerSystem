﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Text.RegularExpressions;

namespace worktime
{
    class MyRegular_Method  //此class记载：正则表达式相关的操作。
    {
        //纯数字，至少一位
        public static bool Pure_Number(string num)
        {
            Regex Regular_Rule = new Regex(@"^\d{1,}$");
            return Regular_Rule.IsMatch(num);
        }

        //纯数字，正好8位，用于时间
        public static bool Eight_Number(string num)
        {
            Regex Regular_Rule = new Regex(@"^\d{8}$");
            return Regular_Rule.IsMatch(num);
        }


        //录入工时：8*1.2+1.25*1.3这样的
        public static bool WorkTimeString(string num)
        {
            Regex Regular_Rule = new Regex(@"^\d+\.?\d*\*[1]\.?\d?(\+\d+\.?\d*\*[1]\.?\d?)*$");
            return Regular_Rule.IsMatch(num);
        }

        //小时数，6.5这样的
        public static bool HoursString(string num)
        {
            Regex Regular_Rule = new Regex(@"^\d+\.?\d*$");
            return Regular_Rule.IsMatch(num);
        }


    }
}
