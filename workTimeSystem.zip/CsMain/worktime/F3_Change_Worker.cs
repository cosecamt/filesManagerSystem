﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace worktime
{
    public partial class F3_Change_Worker : Form
    {
        public F3_Change_Worker()
        {
            InitializeComponent();
        }
        public F3_Change_Worker(string num)
        {
            InitializeComponent();
            label2.Text = num;
        }

        private void F3_Change_Worker_Load(object sender, EventArgs e)
        {
            //还是查一下吧，懒得传参了，反正人员部分基本上不会没事碰他
            string sql = $"SELECT* FROM 员工信息 WHERE 工号 = {label2.Text}";
            DataSet ds = MySQL_Method.SQLite_search(sql);
            textBox1.Text = ds.Tables[0].Rows[0]["姓名"].ToString();
            label5.Text = ds.Tables[0].Rows[0]["所属班组"].ToString();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            label5.Text = "试验班";
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            label5.Text = "试制班";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MyOtherWin_Method.Change_WorkerInfo(label2.Text, textBox1.Text, label5.Text);
            this.Close();
        }
    }
}
