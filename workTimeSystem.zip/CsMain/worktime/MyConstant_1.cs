﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace worktime
{
    class MyConstant_1     //此class记载：可能使用到的常量。
    {
        //数据库地址-连接语句
        public static string conStr = @"Data Source=data\work_info.db3;Version=3;";

        //控制报告工时的框体数量
        public static int box_num = 1;

        //当前的权限
        public static string now_group = "管理员";

        //快捷键排版的参数
        public static string Auto_Publish_OK = "取消";

        //对于排班时的搜索框清空
        public static int Swicth_SearchBox_NotUse = 1;

        //默认的工时系数
        public static string DefaultWorkRadio = "1";

        //计时器——结果好像没用到——又用到了！
        public static int Time_Meter = 2000;

        //计时器2——测试用
        public static int Time_Meter2 = 6;
    }
}
