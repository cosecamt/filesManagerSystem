﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace worktime
{
    public partial class F5_2_Publish_Bench : Form
    {
        public F5_2_Publish_Bench()
        {
            InitializeComponent();
        }

        public F5_2_Publish_Bench(string publish_time)
        {
            InitializeComponent();
            label12.Text = publish_time;
        }


        private void F5_2_Publish_Bench_Load(object sender, EventArgs e)
        {
            string publish_time = label12.Text;

            MyOtherWin_Method.Read_BenchQuest_WhenPublish(this);//把所有未完成的任务按要求都列出来
            MyOtherWin_Method.SearchBench_NearFiveDays(this, publish_time);//把最近5天的历史记录填进去

            MyOtherWin_Method.Read_BenchWorker_Today(this, publish_time);//刷新值班人员选择,要显示最近的一个,等会再写，先显示当天吧
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            MyOtherWin_Method.Read_BenchQuest_WhenPublish(this);
            MyTools_Method.Find_HasChoose_ToRed_WhenBench(this);
        }

        private void button14_Click(object sender, EventArgs e)
        {
            textBox5.Text = "";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            string time = comboBox2.Text;
            MyOtherWin_Method.SearchBench_HistoryQuest(this, time);
            MyTools_Method.Find_HasChoose_ToRed_WhenBench(this);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //干脆抄到右边去
            string num = listView1.FocusedItem.SubItems[0].Text;
            string name = listView1.FocusedItem.SubItems[1].Text;
            //string type = listView1.FocusedItem.SubItems[2].Text;

            //已被标红则不能进行
            if (listView1.FocusedItem.SubItems[0].ForeColor == Color.Red) {
                MessageBox.Show("该任务已经被选择了！");
            }
            else {
                //先抄写，当日说明另说
                ListViewItem first = new ListViewItem(num);
                first.SubItems.Add(name);
                //first.SubItems.Add(type);

                //来读取当日说明

                string sql = $"SELECT* FROM 台架说明 WHERE 发布时间 = {label12.Text} AND 统一编号 = '{num}'";
                DataSet ds = MySQL_Method.SQLite_search(sql);
                if (ds.Tables[0].Rows.Count >= 1) {
                    first.SubItems.Add(ds.Tables[0].Rows[0]["当日说明"].ToString());
                }
                else {
                    //如果没有要查找最近的带进来
                    string sql3 = $"SELECT* FROM 台架说明 WHERE 发布时间 < {label12.Text} AND 统一编号 = '{num}' AND 当日说明 <> '' ORDER BY 发布时间 DESC";
                    DataSet ds3 = MySQL_Method.SQLite_search(sql3);
                    if (ds3.Tables[0].Rows.Count >= 1) {
                        first.SubItems.Add(ds3.Tables[0].Rows[0]["当日说明"].ToString());
                        string sql4 = $"insert into [台架说明](发布时间,统一编号,当日说明)values({label12.Text},'{num}','{ds3.Tables[0].Rows[0]["当日说明"].ToString()}')";
                        MySQL_Method.SQLite_update(sql4);
                    }
                    else {
                        first.SubItems.Add("");
                    }
                }

                //录完了，绘制
                listView2.Items.Add(first);
                MyTools_Method.Find_HasChoose_ToRed_WhenBench(this);

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (listView2.FocusedItem != null) {
                listView2.Items.Remove(listView2.SelectedItems[0]);
                MyTools_Method.Find_HasChoose_ToRed_WhenBench(this);
            }

        }

        private void listView2_MouseClick(object sender, MouseEventArgs e)
        {
            try {
                string time = label12.Text;
                string num = listView2.FocusedItem.Text;
                MyOtherWin_Method.ReadBench_TodayAsk(this, time, num);
                MyOtherWin_Method.Show_BenchQuestInfo_AndNearAsk(this, time, num);

            }
            catch { }
        }

        private void button5_Click(object sender, EventArgs e)
        {


            if (listView2.FocusedItem != null) {
                string time = label12.Text;
                string num = listView2.FocusedItem.Text;
                string ask = textBox2.Text;
                string sql = $"SELECT* FROM 台架说明 WHERE 发布时间 = {time} AND 统一编号 = '{num}'";
                DataSet ds = MySQL_Method.SQLite_search(sql);
                if (ds.Tables[0].Rows.Count != 0) {
                    MyOtherWin_Method.ChangeBench_TodayAsk(time, num, ask);
                    listView2.FocusedItem.SubItems[2].Text = ask;
                }
                else {
                    MyOtherWin_Method.AddBench_TodayAsk(time, num, ask);
                    listView2.FocusedItem.SubItems[2].Text = ask;
                }
            }else {
                MessageBox.Show("先选择一项"); 
            }

            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (listView2.Items.Count >= 1) {
                if (MessageBox.Show($"确定要发布{label12.Text}的工作么？", "Confirm Message", MessageBoxButtons.OKCancel) == DialogResult.OK) {
                    //判断一下是否假期


                    //先录入“每日流程”，保证不会重复排班，时间相同触发key值相同而跳出
                    try {
                        //MyOtherWin_Method.Change_BenchProcess(label12.Text);
                        //先不改流程了

                        //先删后加

                        //再录入任务发布
                        MyOtherWin_Method.DeleteQuest_BeforeAdd_PublishBench(label12.Text);
                        for (int i = 0; i < listView2.Items.Count; i++) {
                            string num = listView2.Items[i].SubItems[0].Text;
                            MyOtherWin_Method.AddBench_Publish(label12.Text, num);
                        }
                        //还得让两边已分配，但是要注意判断是否已经有了，因为两边是分开的
                        //MyOtherWin_Method.Change_BenchProcess(label12.Text);

                        //接下来要判断一下，当日有没有安排人，如果没安排，那么要把最近的录入
                        MyOtherWin_Method.Judge_WhetherTodayWorker_AndCopyNear(label12.Text);


                        this.Close();
                    }
                    catch {
                        MessageBox.Show("在当日已经提交过了");
                    }
                }

            }
            else {
                MessageBox.Show("请至少选择一项任务");
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            F5_3_BenchWorker F5_3_BenchWorker = new F5_3_BenchWorker(label12.Text);
            F5_3_BenchWorker.ShowDialog();
            MyOtherWin_Method.Read_BenchWorker_Today(this, label12.Text);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            /*
            MyOtherWin_Method.SearchBench_NearFiveDays(this, textBox1.Text);//把最近5天的历史记录填进去

            MyOtherWin_Method.Read_BenchWorker_Today(this, textBox1.Text);//刷新值班人员选择
            */
        }

        private void listView1_MouseClick(object sender, MouseEventArgs e)
        {
            string time = label12.Text;
            string num = listView1.FocusedItem.Text;
            MyOtherWin_Method.Show_BenchQuestInfo_AndNearAsk(this, time, num);
        }

        private void listView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            //干脆抄到右边去
            string num = listView1.FocusedItem.SubItems[0].Text;
            string name = listView1.FocusedItem.SubItems[1].Text;
            //string type = listView1.FocusedItem.SubItems[2].Text;

            //已被标红则不能进行
            if (listView1.FocusedItem.SubItems[0].ForeColor == Color.Red) {
                MessageBox.Show("该任务已经被选择了！");
            }
            else {
                //先抄写，当日说明另说
                ListViewItem first = new ListViewItem(num);
                first.SubItems.Add(name);
                //first.SubItems.Add(type);

                //来读取当日说明

                string sql = $"SELECT* FROM 台架说明 WHERE 发布时间 = {label12.Text} AND 统一编号 = '{num}'";
                DataSet ds = MySQL_Method.SQLite_search(sql);
                if (ds.Tables[0].Rows.Count >= 1) {
                    first.SubItems.Add(ds.Tables[0].Rows[0]["当日说明"].ToString());
                }
                else {
                    //如果没有要查找最近的带进来
                    string sql3 = $"SELECT* FROM 台架说明 WHERE 发布时间 < {label12.Text} AND 统一编号 = '{num}' AND 当日说明 <> '' ORDER BY 发布时间 DESC";
                    DataSet ds3 = MySQL_Method.SQLite_search(sql3);
                    if (ds3.Tables[0].Rows.Count >= 1) {
                        first.SubItems.Add(ds3.Tables[0].Rows[0]["当日说明"].ToString());
                        string sql4 = $"insert into [台架说明](发布时间,统一编号,当日说明)values({label12.Text},'{num}','{ds3.Tables[0].Rows[0]["当日说明"].ToString()}')";
                        MySQL_Method.SQLite_update(sql4);
                    }
                    else {
                        first.SubItems.Add("");
                    }
                }

                //录完了，绘制
                listView2.Items.Add(first);
                MyTools_Method.Find_HasChoose_ToRed_WhenBench(this);

            }
        }

        private void listView2_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (listView2.FocusedItem != null) {
                listView2.Items.Remove(listView2.SelectedItems[0]);
                MyTools_Method.Find_HasChoose_ToRed_WhenBench(this);
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            F4_Add_Quest F4_Add_Quest = new F4_Add_Quest();
            F4_Add_Quest.ShowDialog();
            MyOtherWin_Method.Read_BenchQuest_WhenPublish(this);
            MyTools_Method.Find_HasChoose_ToRed_WhenBench(this);

        }
    }
}
