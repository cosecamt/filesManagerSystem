﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace worktime
{
    public partial class F4_3_Quest_Ansys : Form
    {
        public F4_3_Quest_Ansys()
        {
            InitializeComponent();
        }
        public F4_3_Quest_Ansys(string num)
        {
            InitializeComponent();
            label9.Text = num;

            string sql = $"SELECT* FROM 任务信息 WHERE 统一编号 = '{label9.Text}'";
            DataSet ds = MySQL_Method.SQLite_search(sql);
            if (ds.Tables[0].Rows[0]["项目状态"].ToString() == "未完成") {
                label10.Visible = false;
            }
            else {
                button1.Visible = false;
            }

        }

        private void F4_3_Quest_Ansys_Load(object sender, EventArgs e)
        {
            string sql = $"SELECT* FROM 任务信息 WHERE 统一编号 = '{label9.Text}'";
            DataSet ds = MySQL_Method.SQLite_search(sql);

            textBox2.Text = ds.Tables[0].Rows[0]["生产订单号"].ToString();
            textBox3.Text = ds.Tables[0].Rows[0]["内部编号"].ToString();
            textBox4.Text = ds.Tables[0].Rows[0]["编制部门"].ToString();
            textBox5.Text = ds.Tables[0].Rows[0]["项目名"].ToString();
            textBox6.Text = ds.Tables[0].Rows[0]["项目要求"].ToString();
            textBox7.Text = ds.Tables[0].Rows[0]["录入时间"].ToString();
            textBox1.Text = ds.Tables[0].Rows[0]["项目分类"].ToString();

            this.dataGridView1.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            this.dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;

            //查两次，先查试验，再查试制
            //先查实验
            sql = $"SELECT* FROM 任务分配0试验班 INNER JOIN 员工信息 ON 任务分配0试验班.工号 = 员工信息.工号 WHERE 统一编号 = '{label9.Text}' AND 工作类型 <> '（分配标记）'";
            DataSet ds2 = MySQL_Method.SQLite_search(sql);

            string result = "";
            string time = "";
            if (ds2.Tables[0].Rows.Count >= 1) {
                foreach (DataRow row in ds2.Tables[0].Rows) {
                    if (time == "") {
                        time = row["发布时间"].ToString();
                        result = result + "\r\n" + row["姓名"].ToString() + "-" + row["工作小时"].ToString() + "h；";
                    }
                    else {
                        if (time == row["发布时间"].ToString()) {
                            result = result + "\r\n" + row["姓名"].ToString() + "-" + row["工作小时"].ToString() + "h；";
                        }
                        else {
                            result = result.Substring(2);
                            this.dataGridView1.Rows.Add(MyTools_Method.Num_ToDate(Convert.ToInt32(row["发布时间"].ToString())), result);
                            time = row["发布时间"].ToString();
                            result = "\r\n" + row["姓名"].ToString() + "-" + row["工作小时"].ToString() + "h；";
                        }
                    }
                }
                result = result.Substring(2);
                this.dataGridView1.Rows.Add(MyTools_Method.Num_ToDate(Convert.ToInt32(time)), result);
            }

            //再查实验
            sql = $"SELECT* FROM 任务分配0试制班 INNER JOIN 员工信息 ON 任务分配0试制班.工号 = 员工信息.工号 WHERE 统一编号 = '{label9.Text}' AND 工作类型 <> '（分配标记）'";
            DataSet ds3 = MySQL_Method.SQLite_search(sql);

            result = "";
            time = "";
            if (ds3.Tables[0].Rows.Count >= 1) {
                foreach (DataRow row in ds3.Tables[0].Rows) {
                    if (time == "") {
                        time = row["发布时间"].ToString();
                        result = result + "\r\n" + row["姓名"].ToString() + "-" + row["工作小时"].ToString() + "h；";
                    }
                    else {
                        if (time == row["发布时间"].ToString()) {
                            result = result + "\r\n" + row["姓名"].ToString() + "-" + row["工作小时"].ToString() + "h；";
                        }
                        else {
                            result = result.Substring(2);
                            this.dataGridView1.Rows.Add(MyTools_Method.Num_ToDate(Convert.ToInt32(row["时间"].ToString())), result);
                            time = row["发布时间"].ToString();
                            result = "\r\n" + row["姓名"].ToString() + "-" + row["工作小时"].ToString() + "h；";
                        }
                    }
                }
                result = result.Substring(2);
                this.dataGridView1.Rows.Add(MyTools_Method.Num_ToDate(Convert.ToInt32(time)), result);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("将会让该任务的状态变为已完成，可以么？", "Confirm Message", MessageBoxButtons.OKCancel) == DialogResult.OK) {
                string sql = $"UPDATE 任务信息 SET 项目状态 = '已完成' WHERE 统一编号 = '{label9.Text}'";
                MySQL_Method.SQLite_update(sql);

                this.Close();
            }
        }
    }
}
