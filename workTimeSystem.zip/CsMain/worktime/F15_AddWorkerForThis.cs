﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace worktime
{
    public partial class F15_AddWorkerForThis : Form
    {
        public F15_AddWorkerForThis()
        {
            InitializeComponent();
        }
    }
}
