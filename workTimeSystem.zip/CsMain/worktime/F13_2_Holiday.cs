﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace worktime
{
    public partial class F13_2_Holiday : Form
    {
        public F13_2_Holiday()
        {
            InitializeComponent();
        }
    }
}
