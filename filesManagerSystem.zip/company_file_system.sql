﻿# Host: localhost  (Version: 5.5.53)
# Date: 2021-05-24 17:47:11
# Generator: MySQL-Front 5.3  (Build 4.234)

/*!40101 SET NAMES utf8 */;

#
# Structure for table "cfs_quest_info"
#

DROP TABLE IF EXISTS `cfs_quest_info`;
CREATE TABLE `cfs_quest_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `qi_quest_number` varchar(32) NOT NULL DEFAULT '' COMMENT '项目编号',
  `qi_quest_name` varchar(32) NOT NULL DEFAULT '' COMMENT '项目名',
  `qi_create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `qi_manager` varchar(32) NOT NULL DEFAULT '' COMMENT '创建者，负责人',
  `qi_del` int(11) NOT NULL DEFAULT '0' COMMENT '删除标记',
  `qi_partner` varchar(128) NOT NULL DEFAULT '' COMMENT '参与者（复数）',
  `qi_complete` int(11) NOT NULL DEFAULT '0' COMMENT '项目完成标记',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='项目信息';

#
# Data for table "cfs_quest_info"
#

/*!40000 ALTER TABLE `cfs_quest_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `cfs_quest_info` ENABLE KEYS */;

#
# Structure for table "cfs_user_power"
#

DROP TABLE IF EXISTS `cfs_user_power`;
CREATE TABLE `cfs_user_power` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `up_worker_number` varchar(32) NOT NULL DEFAULT '' COMMENT '账户名',
  `up_password` varchar(32) NOT NULL DEFAULT '' COMMENT '密码',
  `up_worker_name` varchar(32) NOT NULL DEFAULT '' COMMENT '真实名字',
  `up_power_level` varchar(32) NOT NULL DEFAULT '' COMMENT '权限等级',
  `up_del` int(11) NOT NULL DEFAULT '0' COMMENT '删除标记',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COMMENT='用户权限';

#
# Data for table "cfs_user_power"
#

/*!40000 ALTER TABLE `cfs_user_power` DISABLE KEYS */;
INSERT INTO `cfs_user_power` VALUES (1,'admin','admin','张三','管理员',0);
/*!40000 ALTER TABLE `cfs_user_power` ENABLE KEYS */;
