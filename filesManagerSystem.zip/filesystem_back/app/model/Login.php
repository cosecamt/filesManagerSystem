<?php

namespace app\model;

use think\model;

class Login extends Model {
    protected $table = 'cfs_user_power';
}