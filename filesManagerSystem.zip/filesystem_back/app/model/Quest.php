<?php

namespace app\model;

use think\model;

class Quest extends Model {
    protected $table = 'cfs_quest_info';
}