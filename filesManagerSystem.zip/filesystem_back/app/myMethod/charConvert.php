<?php

namespace app\myMethod;

class charConvert{
    //UTF-8转成GBK，TP在操作系统时用GBK
    public static function convert_UtoG($word){
        return iconv("UTF-8", "GBK",$word);
        //return mb_convert_encoding($word,"GBK","UTF-8");
    }
    //GBK转成UTF-8，前端和数据库用UTF-8
    public static function convert_GtoU($word){
        return iconv("GBK", "UTF-8",$word);
    }

}