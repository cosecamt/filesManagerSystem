import shutil
import sys

# 此参数为目标文件夹的名字，移动的前后名字不会改变，现在来拼接地址
fileDir = sys.argv[1]

sourceDir = "../../fileSave/" + fileDir
aimDir = "../../fileStorage/delete/" + fileDir

shutil.move(sourceDir, aimDir)

