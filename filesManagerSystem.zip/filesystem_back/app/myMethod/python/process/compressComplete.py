import sys
import compressMethod
import shutil

# 传入项目名字，要将该项目压缩到complete文件夹中
# folderName = "智2021-001-刚凤凰"
folderName = sys.argv[1]

# 1.拼接出项目所在的完整路径
folderPath = "../../fileSave/" + folderName

# 2.将文件夹压缩到complete文件夹中
outputPath = "../../fileStorage/complete/" + folderName + ".zip"
compressMethod.makeZip(folderPath, outputPath)

# 3.将源文件夹删除
shutil.rmtree(folderPath)

# 4.输出成功
print("success")
