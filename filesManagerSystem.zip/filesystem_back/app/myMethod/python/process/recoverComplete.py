import sys
import os
import zipfile

# 传入项目名字
# folderName = "智2021-001-刚凤凰"
folderName = sys.argv[1]

# 1.拼接出完成后压缩文件所在的完整路径
folderPath = "../../fileStorage/complete/" + folderName + ".zip"

# 2.将压缩文件解压到fileSave文件夹中
zipOut = zipfile.ZipFile(folderPath, 'r')
zipOut.extractall(path=r"../../fileSave")
zipOut.close()

# 3.将源压缩文件删除
os.remove(folderPath)

# 4.输出成功
print("success")
