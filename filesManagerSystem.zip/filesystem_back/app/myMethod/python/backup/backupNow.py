# 本脚本适用于手动备份，不管三七二十一，全部打包放到备份区
import compressMethod
import time

nowTime = time.strftime("%Y%m%d-%H%M%S", time.localtime()) + ".zip"
sourcePath = "../../fileSave"
outputPath = "../../fileStorage/backup/" + nowTime
compressMethod.makeZip(sourcePath, outputPath)
