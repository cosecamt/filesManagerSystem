import os
import json

# 用来读取备份文件夹中的所有文件，只会是压缩文件，所以不需要判断是否为文件夹
all_files = []
path = "../../fileStorage/backup"
file_list = os.listdir(path)
# 由于不用判断是否为文件万，所以只要循环添加就可以了
for file in file_list:
    all_files.append(file)
# 排个序，降序
all_files.sort(reverse=True)
# 最后输出的结果是数组
print(json.dumps(all_files))
