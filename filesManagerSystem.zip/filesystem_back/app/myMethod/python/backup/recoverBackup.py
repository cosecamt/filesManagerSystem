import shutil
import zipfile
import sys

# 1.接收到待恢复的文件的名字
fileName = sys.argv[1]
# fileName = "20210519-100704.zip"
# 2.删除fileSave文件夹
fileDir = "../../fileSave"
# fileDir = "F:/Script/ProjectForCompany/210328_FileSystem/fileSave"
shutil.rmtree(fileDir)
# 3.将待恢复文件解压缩到filesava文件夹（要注意一下解压到哪里）
zipDir = "../../fileStorage/backup" + "/" + fileName
# zipDir = "F:/Script/ProjectForCompany/210328_FileSystem/fileStorage/backup" + "/" + fileName
zipOut = zipfile.ZipFile(zipDir, 'r')
zipOut.extractall(path=r"../../")
# zipOut.extractall(path=r"F:/Script/ProjectForCompany/210328_FileSystem")
zipOut.close()
# 4.返回成功消息
print("success")
