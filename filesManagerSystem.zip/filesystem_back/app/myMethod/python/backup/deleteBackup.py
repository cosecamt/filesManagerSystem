import os
import sys

# 传入参数为需要保留的文件个数
# numCount = 7
numCount = int(sys.argv[1])

# 先降序把文件列表排出来
all_files = []
path = "../../fileStorage/backup"
# path = "F:/Script/ProjectForCompany/210328_FileSystem/fileStorage/backup"
file_list = os.listdir(path)
for file in file_list:
    all_files.append(file)
all_files.sort(reverse=True)

# 要考虑数量不足的问题
if numCount < len(file_list):
    # 然后根据传进来的数字来决定从哪里开始遍历
    for i in range(numCount, len(all_files)):
        os.remove(path + "/" + all_files[i])
print("success")
