import zipfile
import os


# 本方法用于打包，没有减少大小，只是打包
def makeZip(source_dir, output_filename):
    zipWait = zipfile.ZipFile(output_filename, 'w')
    pre_len = len(os.path.dirname(source_dir))
    for parent, _, filenames in os.walk(source_dir):
        for filename in filenames:
            pathfile = os.path.join(parent, filename)
            arcname = pathfile[pre_len:].strip(os.path.sep)  # 相对路径
            zipWait.write(pathfile, arcname)
    zipWait.close()
