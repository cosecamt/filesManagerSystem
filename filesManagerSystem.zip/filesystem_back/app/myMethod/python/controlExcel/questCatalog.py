# 输入一个目录，然后会在该目录下生成该目录中三个文件夹的文件目录
# 文件夹的结构就采用之前的树形图递归，考虑到以后可能要做些改变，比如增加创建时间，所以单独领出来一份，也保证本功能的完整
# 好吧，也没法直接接出来，因为之前return的是print的
import questCatalog_fileListTree
import questCatalog_writeIn

# 先树形递归出来
path = "F:/Script/ProjectForCompany/210328_FileSystem/fileSave/2-项目B"
fileTree = questCatalog_fileListTree.recurseCatalog(path)

# 然后开始生成和填入excel
questCatalog_writeIn.writeInExcel(path, fileTree)

