# 输入一个项目地址和一个数组，将内容填到Excel表中，该表保存到地址中，从地址中也可以解析出项目的名字和编号
# 其实没有“归”的过程，应该叫迭代

import openpyxl
from openpyxl.styles import PatternFill, Border, Side, Alignment, Protection, Font
import os

rowGolbal = 2
colMax = 1


# 主函数
def writeInExcel(folderDir, fileList):
    # 把数组拿出来
    fileList = fileList[0]['children']
    # 方便拼接
    folderDir = folderDir + "/"
    # 导出路径
    excelOutDir = folderDir + "文件目录.xlsx"

    # 把数组拆成3个，每个其实是键值对
    # python在os.path的时候是任意的，一定要注意，所以还是判断一下
    DictBusiness = []
    DictTechnology = []
    DictScript = []
    for DictJudge in fileList:
        if DictJudge['label'] == '商务':
            DictBusiness = DictJudge
        if DictJudge['label'] == '技术':
            DictTechnology = DictJudge
        if DictJudge['label'] == '程序':
            DictScript = DictJudge

    # 可以开始填了
    # 创建新的Excel
    WorkBook_Result = openpyxl.Workbook()
    Sheet_1 = WorkBook_Result.active
    Sheet_1.title = "文件目录"

    # 填写标题
    Sheet_1.cell(1, 1).value = folderDir.split("/")[-2]
    # 递归填写文件和文件夹
    # 传入：表、本次填写的起点的行数（列数永远是2）、待递归的数组、用来拼接的前置路径
    # 传出：最终的行数给后面用，最大的列数给标题用，填写过得表单
    recurseWriteIn(Sheet_1, DictBusiness, folderDir)
    recurseWriteIn(Sheet_1, DictTechnology, folderDir)
    recurseWriteIn(Sheet_1, DictScript, folderDir)
    # 根据最大列数，合并并居中第一行
    Sheet_1.merge_cells(F'A1:{TransfromNumberToChar(colMax)}1')
    Sheet_1.cell(1, 1).alignment = Alignment(horizontal='center', vertical='center', wrapText=True)
    # 最后别忘了导出
    WorkBook_Result.save(excelOutDir)


# 子函数：递归填写文件和文件夹
def recurseWriteIn(Sheet_1, Dict, folderDir):
    # 递归函数：输入当前的Dict、当前位置、表格、拼接用路径
    # 1.判断是文件夹还是文件，文件的话将label填入，同时满足终止条件
    # 2.如果是文件夹，将label填入，列数要增加1来代入文件夹中的文件
    def recuseFunction(DictInner, col, SheetThis, folderDirThis):
        global rowGolbal
        global colMax
        # 不管怎么样先填上这个格子
        SheetThis.cell(rowGolbal, col).value = DictInner["label"]
        # 同样不管如何，把边框加上
        SheetThis.cell(rowGolbal, col).border = Border(left=Side(border_style='thin', color='000000'),
                                                       right=Side(border_style='thin', color='000000'),
                                                       top=Side(border_style='thin', color='000000'),
                                                       bottom=Side(border_style='thin', color='000000'))
        # 然后判断是文件还是文件夹
        if os.path.isdir(folderDirThis + DictInner["label"]):
            # 如果是文件夹：
            # 后来发现一种可能，那就是文件夹是空的，那就只是行数+1就行
            if len(DictInner["children"]) == 0:
                rowGolbal = rowGolbal + 1
                return
            # 首先列数要变
            col = col + 1
            # 为了寻求最大列数，这里要比较并记录一下
            if col > colMax:
                colMax = col
            # 然后遍历自己“chindren”中的数组，其中的每一个Dict都作为下一个递归对象
            mergeRow = rowGolbal
            for DictThis in DictInner["children"]:
                recuseFunction(DictThis, col, SheetThis, folderDirThis + DictInner["label"] + "/")
            # 循环结束以后，可以对此列进行合并操作
            SheetThis.merge_cells(F'{TransfromNumberToChar(col-1)}{mergeRow}:{TransfromNumberToChar(col-1)}{rowGolbal - 1}')
            SheetThis.cell(mergeRow, col-1).alignment = Alignment(horizontal='center', vertical='center', wrapText=True)

        else:
            # 如果是单文件：
            # 行数要加1
            rowGolbal = rowGolbal + 1
            Sheet_1.cell(rowGolbal - 1, col).fill = PatternFill(fill_type='solid', fgColor="66B3FF")

    # 执行递归函数
    recuseFunction(Dict, 1, Sheet_1, folderDir)
    # 返回需要的参数


# 用于openpyxl里合并单元格，实现数字和字母的转换，用1-26替换A-Z
# 传进来的数字应该介于1-26这个范围
def TransfromNumberToChar(Number):
    if Number >= 27:
        N_Other = Number - 26
        C_Other = chr(N_Other + 64)
        return F"A{C_Other}"
    return chr(Number + 64)