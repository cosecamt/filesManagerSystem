import shutil
import os
import sys

source_path = sys.argv[1]
stringSplit = source_path.split("/")[-1]
# 输出的目录是固定的，待拼接，后面要接上名字，不然不行，也就是说，最后一个节点时会新建出文件夹的
# 但是复制的如果是文件就没关系，只要精确到目标文件夹就行了，不用拼接文件名字
target_path = "../../fileStorage/delete/" + stringSplit

# 如果目标路径存在原文件夹的话就先删除
if os.path.exists(target_path):
    shutil.rmtree(target_path)

# 要判断是文件夹还是文件再删除
if os.path.isfile(source_path):
    shutil.copy(source_path, target_path)
else:
    shutil.copytree(source_path, target_path)
