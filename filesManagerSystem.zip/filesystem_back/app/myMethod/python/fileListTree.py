import os
import sys
import json


def show_files_tree(path, all_files):
    # 先遍历所有的文件和文件夹，之后再分辨
    global labelId
    file_list = os.listdir(path)
    # 准备循环判断每个元素是否是文件夹还是文件，是文件的话，把名称传入list
    # 是文件夹的话，就有点麻烦了，要递归，而且还是里面做数组的那种
    for file in file_list:
        # 利用os.path.join()方法取得路径全名，并存入cur_path变量，否则每次只能遍历一层目录
        cur_path = os.path.join(path, file)
        # 判断是否是文件夹
        if os.path.isdir(cur_path):
            dictFile = makeKeyValue_folder(labelId, file, {})
            labelId = labelId + 1
            children_value = show_files_tree(cur_path, [])
            dictFile["children"] = children_value
            all_files.append(dictFile)
        else:
            dictFile = makeKeyValue_files(labelId, file, {})
            labelId = labelId + 1
            all_files.append(dictFile)
    return all_files


# 文件的键值对生成
def makeKeyValue_files(labelId, fileName, dictFile):
    dictFile = {"id": labelId, "label": fileName, "icon": "el-icon-document"}
    return dictFile


# 文件夹的键值对生成
# 其实确实没必要写两种，但是我怕搞混，回头再优化
def makeKeyValue_folder(labelId, fileName, dictFile):
    dictFile = {"id": labelId, "label": fileName, "icon": "el-icon-folder"}
    return dictFile


# 解释型语言，主程序要放在最后
fileDir = sys.argv[1]
fileDir = "../../fileSave/" + fileDir
# 传入空的list接收文件名
labelId = 2
contents = show_files_tree(fileDir, [])
contents = [{"id": 1, "label": fileDir[-2:], "children": contents, "icon": "el-icon-folder"}]

print(json.dumps(contents))
