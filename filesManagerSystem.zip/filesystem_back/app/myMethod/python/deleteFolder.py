import shutil
import os
import sys

fileDir = sys.argv[1]
# 要判断是文件夹还是文件再删除
if os.path.isfile(fileDir):
    os.unlink(fileDir)
else:
    shutil.rmtree(fileDir)
