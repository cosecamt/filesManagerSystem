import os
from os.path import getsize, join
import json


def getdirsize(dir):
    size = 0
    for root, dirs, files in os.walk(dir):
        size += sum([getsize(join(root, name)) for name in files])
    return size


# path = "../../fileSave"
path = "F:/Script/ProjectForCompany/210328_FileSystem/fileSave"
filesList = os.listdir(path)
filesList.sort(reverse=True)
sizeList = []
for looperFile in filesList:
    fileSize = getdirsize(path + "/" + looperFile) / 1024 / 1024
    sizeList.append(round(fileSize, 2))

print(json.dumps([filesList, sizeList]))
