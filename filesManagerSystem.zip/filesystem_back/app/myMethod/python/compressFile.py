import os
import sys
import json
import zipfile
import time


# 打包目录为zip文件的方法，但是其实没有压缩大小
def make_zip(source_dir, output_filename):
    zipf = zipfile.ZipFile(output_filename, 'w')
    pre_len = len(os.path.dirname(source_dir))
    for parent, _, filenames in os.walk(source_dir):
        for filename in filenames:
            pathfile = os.path.join(parent, filename)
            arcname = pathfile[pre_len:].strip(os.path.sep)  # 相对路径
            zipf.write(pathfile, arcname)
    zipf.close()


def trytry():
    print("success")


if __name__ == '__main__':
    # 解释型语言，主程序要放在最后
    fileDir = sys.argv[1]
    nameSplit = fileDir.split('/')
    # 作为压缩文件名的文件夹名字，要先提取出来
    folderName = time.strftime("%Y%m%d-%H%M%S-", time.localtime()) + nameSplit[-1] + ".zip"
    # 然后要拼接成输出路径
    folderName = "../../fileStorage/compress/" + folderName
    make_zip(fileDir, folderName)
    print(json.dumps(folderName))
