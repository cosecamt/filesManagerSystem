import shutil
import sys

fileDir = sys.argv[1]
fileDir = "../../fileStorage/delete/" + fileDir
shutil.rmtree(fileDir)
