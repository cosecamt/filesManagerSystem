import shutil
import sys

fileDir = sys.argv[1]

# 直接移动文件夹
sourceDir = "../../fileStorage/delete/" + fileDir
aimDir = "../../fileSave/" + fileDir

shutil.move(sourceDir, aimDir)
