<?php

namespace app\controller;

use Exception;
use think\facade\Db;
use think\Request;
use app\model\Quest;
use app\model\Login;

use app\myMethod\charConvert;

class QuestApi
{
    //创建新的项目，生成项目目录
    public function newQuest(Request $request){
        //取值
        $questName = $request->param('questName');
        $username = $request->param('workerName');
        //数据库-增
        try {
            $quest = new Quest;
            $quest->qi_quest_name = $questName;
            $quest->qi_manager = $username;
            //查一下数据库中本年编号最大的那个编号是多少
            $listThisYear = $quest->where("qi_quest_number","like","智".date("Y")."-%")
                ->order("qi_quest_number","desc")
                ->select();
            //先定义一下后面要用的编号
            $questNumber = "";
            if(count($listThisYear) == 0){
                //首先还要考虑为空的问题，此时后缀为001
                $questNumber = "智".date("Y")."-".sprintf("%03d",1);
            }else{
                //否则就先把最大的编号拿出来
                $maxQuestNumber = $listThisYear[0]["qi_quest_number"];
                //将最大的编号+1形成新的编号
                $laterNumber = explode("-",$maxQuestNumber)[1];
                $questNumber = "智".date("Y")."-".sprintf("%03d",$laterNumber + 1);
            }
            //设计编号
            $quest->qi_quest_number = $questNumber;
            $quest->save();
        }catch (\Exception $e){
            return json($e->getMessage());
        }
        //创建文件夹
        $dir = charConvert::convert_UtoG($questNumber."-".$questName);
        $dir = $questNumber."-".$questName;
        $dir = "../../fileSave/" . $dir;
        try{
            mkdir ($dir);
            mkdir ($dir."/商务");
            $myfile = fopen($dir."/商务/"."index.txt", "w");
            mkdir ($dir."/技术");
            $myfile = fopen($dir."/技术/"."index.txt", "w");
            mkdir ($dir."/程序");
            $myfile = fopen($dir."/程序/"."index.txt", "w");
        }catch (\Exception $e) {
            return json($e->getMessage());
        }

        return json("success");
    }

    //查询项目列表
    public function searchQuestList(){
        $questList = Db::table('cfs_quest_info')
            ->join('cfs_user_power','cfs_quest_info.qi_manager = cfs_user_power.up_worker_number')
            ->where("cfs_quest_info.qi_del", "<>", 1)
            ->where("cfs_quest_info.qi_complete", "<>", 1)
            ->select();
        return json($questList);
    }

    //遍历该项目所有的文件列表，根据项目编号返回项目名和内部的文件列表
    public function searchFilesList(Request $request){
        $checkTable = new Quest;
        //先查项目信息
        $questInfo = $checkTable->where("qi_quest_number", $request->param("data"))->select();
        $questFullName = $questInfo[0]->qi_quest_number . "-" . $questInfo[0]->qi_quest_name;
        //然后准备使用python文件来递归文件夹结构
        $output1 = shell_exec("python ../app/myMethod/python/fileListTree.py \"$questFullName./商务\"");
        $output1 = json_decode($output1, true);
        $output2 = shell_exec("python ../app/myMethod/python/fileListTree.py \"$questFullName./技术\"");
        $output2 = json_decode($output2, true);
        $output3 = shell_exec("python ../app/myMethod/python/fileListTree.py \"$questFullName./程序\"");
        $output3 = json_decode($output3, true);
        return json([$questFullName, $output1, $output2, $output3]);
    }

    //修改某项目的负责人和参与者,项目名字也进行修改
    public function changeWorker(Request $request){
        $quest_id = $request->param("qi_quest_number");
        $power_id = $request->param("up_worker_number");
        $partner = $request->param("qi_partner");
        $quest_name = $request->param("qi_quest_name");
        //项目名修改的话，文件夹的名字也要跟着改，为了防止频繁修改，判断一下再改
        //先与数据库中的数据进行比较，然后如果有所改变，就把文件夹名先改，不然找没改名的文件夹不好找了
        $questTable = Quest::where('qi_quest_number',$quest_id)->find();
        $oldQuestName = $questTable->qi_quest_name;
        if($oldQuestName != $quest_name){
            //先拼出老的文件夹路径，由于还没修改，肯定是存在的
            $oldDir = "../../fileSave/" . $quest_id."-".$oldQuestName;
            $newDir = "../../fileSave/" . $quest_id."-".$quest_name;
            //将其重命名
            rename($oldDir, $newDir);
        }
        //进行update
        $questTable->qi_manager = $power_id;
        $questTable->qi_partner = $partner;
        $questTable->qi_quest_name = $quest_name;
        $questTable->save();

        return json("success");

    }

    //删除项目，除了在数据库中删除，还要将文件夹转移至其他地方
    public function deleteQuest(Request $request){
        //先删数据库
        $questTable = Quest::where('qi_quest_number',$request->param("qi_quest_number"))->find();
        $questTable->qi_del = 1;
        $questTable->save();
        //再移动文件夹，先把编号和名字拼接出来
        $folderName = $request->param("qi_quest_number")."-".$request->param("qi_quest_name");
        //然后移动
        shell_exec("python ../app/myMethod/python/moveFolder.py \"$folderName\"");
        return $folderName;
    }

    //在进入该项目的文件列表时，进行权限的验证
    public function rightClickPowerCheck(Request $request){
        //信息提出来
        $userInfo = $request->param("userInfo");
        $questIndo = $request->param("questInfo");
        //先查查是不是管理员，是的话返回
        $workerNumber = explode("-",$userInfo)[1];
        $powerCheck = Login::where("up_worker_number", $workerNumber)->select();
        if($powerCheck[0]["up_power_level"] == "管理员"){
            return json("管理员");
        }
        //否则就查出项目信息，拿出管理者和参与者字段
        $questCheck = Quest::where("qi_quest_number",$questIndo)->select();
        //分割用户信息，得到编号，进行比对，两边都是string，应该可以直接比对，是负责人直接返回
        if($workerNumber == $questCheck[0]["qi_manager"]){
            return json("负责人");
        }
        //否则用用户信息在参与这种搜索，结果返回
        if(strpos($questCheck[0]["qi_partner"],$userInfo) || $questCheck[0]["qi_partner"] == "所有人"){
            return json("参与者");
        }else{
            return json("无权限");
        }
    }
}
