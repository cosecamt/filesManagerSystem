<?php

namespace app\controller;

use think\Request;

class BackupApi{
    //进行备份
    public function backupNow(){
        //1.将当前的文件全都打包，位置固定不需要传参
        shell_exec("python ../app/myMethod/python/backup/backupNow.py");
        //2.打包完后返回成功信息
        return "success";
    }
    // 读取备份列表
    public function readBackupList(){
        //1.调用python读取列表
        $output = shell_exec("python ../app/myMethod/python/backup/readBackupList.py");
        //2.将列表返回
        return json_decode($output, true);
    }
    // 删除一定数量的备份
    public function deleteBackup(Request $request){
        //1.调用python进行删除，传入的参数为保留的文件个数，要考虑数量不足的问题
        $numCount = $request->param("count");
        $output = shell_exec("python ../app/myMethod/python/backup/deleteBackup.py $numCount");
        //2.返回删除结果
        return $output;
    }
    //然后恢复选定文件
    public function recoverBackup(Request $request){
        //把文件名字取出来
        $zipName = $request->param("name");
        //1.先删除原本的文件夹，因为已经备份过，所以没关系
        //2.再将选择的备份文件解压回项目文件夹内，这两项合并到一个py文件中
        $output = shell_exec("python ../app/myMethod/python/backup/recoverBackup.py $zipName");
        //3.返回结果
        return $output;
    }

}
