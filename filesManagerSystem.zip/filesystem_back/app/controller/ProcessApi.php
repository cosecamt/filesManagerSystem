<?php

namespace app\controller;

use think\Request;
use app\model\Quest;

class ProcessApi{
    // 根据筛选来读取任务列表
    public function readProcessQuest(Request $request){
        $radio = $request->param("radio");
        //根据查找的类型来决定完成标记是什么
        $completeMark = 0;
        if($radio == "已完成的项目"){
            $completeMark = 1;
        }
        //开始查询
        $searchTable = new Quest;
        $questInfo = $searchTable->where("qi_complete","=",$completeMark)->select();
        return json($questInfo);
    }
    // 将该项目标记为已完成
    public function markComplete(Request $request){
        $id = $request->param("id");
        //1.查出改文件的信息，拼接出文件的名字
        $itemTable = new Quest;
        $itemInfo = $itemTable->where("qi_quest_number","=",$id)->find();
        $itemFolderName = $itemInfo["qi_quest_number"]."-".$itemInfo["qi_quest_name"];
        //2.将目标文件夹压缩到complete文件夹
        //3.删除源文件夹，与2一起为py脚本
        shell_exec("python ../app/myMethod/python/process/compressComplete.py $itemFolderName");
        //4.修改数据库中的完成状态
        $itemInfo->qi_complete = 1;
        $itemInfo->save();
        return json($itemFolderName);
    }
    // 把项目恢复到未完成的状态
    public function recoverComplete(Request $request){
        $id = $request->param("id");
        //1.查出改文件的信息，拼接出文件的名字
        $itemTable = new Quest;
        $itemInfo = $itemTable->where("qi_quest_number","=",$id)->find();
        $itemZipName = $itemInfo["qi_quest_number"]."-".$itemInfo["qi_quest_name"];
        //2.将目标文件夹解压缩到fileSave文件夹
        //3.删除源压缩文件,与2一起为py脚本
        shell_exec("python ../app/myMethod/python/process/recoverComplete.py $itemZipName");
        //4.修改数据库中的完成状态
        $itemInfo->qi_complete = 0;
        $itemInfo->save();
        return json($itemZipName);
    }
}
