<?php

namespace app\controller;

use think\Request;
use app\model\Quest;

class DeleteApi{
    //读取已经删除的任务信息
    public function readDeleteList(){
        //直接查询
        $searchTable = new Quest;
        $questInfo = $searchTable->where("qi_del","=",1)->select();
        return json($questInfo);
    }
    // 恢复项目
    public function recoverQuestDel(Request $request){
        //将文件夹转移回fileSave
        $idName = $request->param("idName");
        shell_exec("python ../app/myMethod/python/delete/recoverFolder.py $idName");
        //在数据库中修改删除标记
        $searchTable = new Quest;
        $itemInfo = $searchTable->where("qi_quest_number","=",$request->param("id"))->find();
        $itemInfo->qi_del = 0;
        $itemInfo->save();
        return json("success");
    }
    // 彻底删除
    public function deleteQuestDel(Request $request){
        $idName = $request->param("idName");
        //先将文件夹删除
        shell_exec("python ../app/myMethod/python/delete/deleteFolder.py $idName");
        //然后在数据库中删除该条数据
        $id = $request->param("id");
        $searchTable = new Quest;
        $itemInfo = $searchTable->where("qi_quest_number","=",$id)->delete();
        return "success";
    }
}
