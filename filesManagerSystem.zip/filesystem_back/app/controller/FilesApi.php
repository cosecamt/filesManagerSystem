<?php

namespace app\controller;

use app\myMethod\charConvert;
use think\Request;

class FilesApi {
    //文件上传
    public function upload(Request $request){
        try{
            //获取文件
            $file = $request->file('file');
            //获取文件名，话说这么获取之后好像不需要Gbk转Utf8了，不知道原因
            $item = $file->getOriginalName();
            //取出里面携带的参数
            $info = $request->param('fileDir');
            $info2 = $request->param('fileQuestNumber');
            //拼接上传的地址
            $desUrl = "../../fileSave/" . $info2 . $info . "/" . $item;
            //上传文件
            $status = move_uploaded_file($file, $desUrl);
            //返回信息
            return json($desUrl);
        }
        catch (\Exception $e){
            return json($e->getMessage());
        }
    }

    //单文件下载
    public function download($dir = 'default'){
        $fileName = explode('/',$dir);
        $fileName = $fileName[count($fileName) - 1];
        return download("$dir",$fileName);
    }

    //对目标文件夹进行压缩
    public function compressFolder(Request $request){
        $request = $request->param("dir");
        $output = shell_exec("python ../app/myMethod/python/compressFile.py \"$request\"");
        $output = json_decode($output, true);
        $output = json_decode($output, true);
        return json($output);
    }

    //删除文件和文件夹
    public function deleteFile(Request $request){
        $request = $request->param("dir");
        shell_exec("python ../app/myMethod/python/deleteFolder.py \"$request\"");
        return json($request);
    }

    //新建文件夹
    public function buildFolder(Request $request){
        $folderName = $request->param("folderName");
        $folderDir = $request->param("folderDir");
        $dir = charConvert::convert_UtoG($folderDir."/".$folderName);
        mkdir ($dir);
        //创建文件夹
        return json("success");
    }

    //文件夹上传
    public function uploadFolder(Request $request){
        //把一级地址先拼出来
        $firstDir = "../../fileSave/".$request->param('questNumber').$request->param('firstDir');
        //然后开始处理文件
        $files = $request->file('files');
        //二级地址，是个数组，等会要和文件一同遍历
        $itemSecondDir = $request->param('webkitRelativePath');
        //遍历二级地址数组和文件数组;
        //1.拆分此二级地址，遍历出最后一个值以外的值（最后一个为文件名，必然不存在）;
        //2.将此时的二级地址与一级地址拼接，查询该文件夹是否存在;
        //3.如果存在，就继续遍历;
        //4.如果不存在，就创建该文件夹，继续遍历;
        //5.直至二级地址遍历完成，即可将原本的二级地址和一级地址拼接，用于文件储存。
        for($i = 0; $i < count($files); $i++){
            //先把文件本体取出来
            $thisFile = $files[$i];
            //把二级地址弄出来
            $thisSecondDir = $itemSecondDir[$i];
            //先分割成数组
            $listSecondDir = explode("/",$thisSecondDir,-1);
            //把最后的文件名去掉
            $deepDir = "";
            if(count($listSecondDir) == 1){
                $deepDir = $listSecondDir[0];
            }else{
                $deepDir = implode("/",$listSecondDir);
            }
            //拼成待检测文件路径，并建立文件夹
            $checkDir = $firstDir."/".$deepDir;
            if(!is_dir($checkDir)){
                mkdir($checkDir, 0777, true);
            }
            //最后存入文件
            move_uploaded_file($thisFile, $firstDir."/".$thisSecondDir);
        }
        return json("success");
    }
}
