<?php

namespace app\controller;

class SpaceApi{
    //读取所有项目的信息
    public function readAllQuestInfo(){
        $output = shell_exec("python ../app/myMethod/python/space/readSpace.py");
        $output = json_decode($output, true);
        return json($output);
    }
}
