<?php

namespace app\controller;

use think\Request;
use app\model\Login;

class LoginApi
{
    //核验登录密码
    public function loginCheck(Request $request){
        $workerNumber = $request->param('workNumber');
        $password = $request->param('password');
        $selectInfo = Login::where('up_worker_number',$workerNumber)->find();
        if($selectInfo == null){
            return 'NoUser';
        }
        $realPassword = $selectInfo->up_password;
        if($realPassword == $password){
            return json($selectInfo);
        }else{
            return 'failed';
        }
    }

    //获取所有员工的信息
    public function getWorkerList(){
        $selectInfo = Login::select();
        return json($selectInfo);
    }
}
