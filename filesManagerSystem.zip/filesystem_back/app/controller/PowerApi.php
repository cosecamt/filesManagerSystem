<?php

namespace app\controller;

use think\Request;
use app\model\Login;

class PowerApi
{
    //修改登录密码
    public function changePassword(Request $request){
        $powerTable = new Login;
        $findResult = $powerTable->where("up_worker_number",$request->param("workerNumber"))
            ->where("up_password",$request->param("old"))
            ->find();
        if($findResult == null){
            return "failed";
        }
        //没问题就修改密码
        $findResult->up_password = $request->param("new");
        $findResult->save();
        return "success";
    }

    //修改用户基本信息
    public function changeWorkerInfo(Request $request){
        $powerTable = new Login;
        $findResult = $powerTable->where("up_worker_number",$request->param("up_worker_number"))->find();
        //既然能看到，那肯定能找到，进行修改
        $findResult->up_worker_name = $request->param("up_worker_name");
        $findResult->up_power_level = $request->param("up_power_level");
        $findResult->save();
        return "success";
    }

    //查看人员的密码
    public function searchPassword(Request $request){
        $powerTable = new Login;
        $findResult = $powerTable->where("up_worker_number",$request->param("up_worker_number"))->find();
        //能在前端看到，肯定是能找到的，查询密码并返回
        return $findResult->up_password;
    }

    //增加新的员工
    public function addNewWorker(Request $request){
        $findResult = Login::where("up_worker_number",$request->param("up_worker_number"))->find();
        if($findResult != null){
            return "failed";
        }
        $powerTable = new Login;
        $powerTable->up_worker_number = $request->param("up_worker_number");
        $powerTable->up_password = $request->param("up_worker_number");
        $powerTable->up_worker_name = $request->param("up_worker_name");
        $powerTable->up_power_level = $request->param("up_power_level");
        $powerTable->save();
        return "success";
    }
}