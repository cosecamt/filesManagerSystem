<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006~2018 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: liu21st <liu21st@gmail.com>
// +----------------------------------------------------------------------
use think\facade\Route;

Route::get('think', function () {
    return 'hello,ThinkPHP6!';
});

Route::get('hello/:name', 'index/hello');

//---------- 此处为登录界面Api ----------
//登录检测
Route::rule('loginCheck','LoginApi/loginCheck');

//获取所有员工的信息
Route::rule('getWorkerList','LoginApi/getWorkerList');

//---------- 此处为项目列表界面Api ----------
//新建项目
Route::rule('newQuest','QuestApi/newQuest');

//查询项目列表
Route::rule('searchQuestList','QuestApi/searchQuestList');

//遍历该项目所有的文件列表，根据项目编号返回项目名和内部的文件列表
Route::rule('searchFilesList','QuestApi/searchFilesList');

//修改某项目的负责人和参与者
Route::rule('changeWorker','QuestApi/changeWorker');

//删除项目，除了在数据库中删除，还要将文件夹转移至其他地方
Route::rule('deleteQuest','QuestApi/deleteQuest');

//在进入该项目的文件列表时，进行权限的验证
Route::rule('rightClickPowerCheck','QuestApi/rightClickPowerCheck');

//---------- 此处为任务列表界面Api ----------
//接收上传的文件
Route::rule('upload','FilesApi/upload');

//下载指定的文件
Route::rule('download','FilesApi/download');

//对目标文件夹进行压缩
Route::rule('compressFolder','FilesApi/compressFolder');

//删除文件和文件夹
Route::rule('deleteFile','FilesApi/deleteFile');

//新建文件夹
Route::rule('buildFolder','FilesApi/buildFolder');

//上传文件夹
Route::rule('uploadFolder','FilesApi/uploadFolder');

//---------- 此处为权限管理界面Api ----------
//修改密码
Route::rule('changePassword','PowerApi/changePassword');

//修改用户基本信息
Route::rule('changeWorkerInfo','PowerApi/changeWorkerInfo');

//查看人员的密码
Route::rule('searchPassword','PowerApi/searchPassword');

//增加新的人员
Route::rule('addNewWorker','PowerApi/addNewWorker');

//---------- 此处为备份相关界面Api ----------
//备份此时文件
Route::rule('backupNow','BackupApi/backupNow');

// 读取备份列表
Route::rule('readBackupList','BackupApi/readBackupList');

// 删除一定数量的备份
Route::rule('deleteBackup','BackupApi/deleteBackup');

//恢复选定文件
Route::rule('recoverBackup','BackupApi/recoverBackup');

//---------- 此处为进度管理相关界面Api ----------
// 根据筛选来读取任务列表
Route::rule('readProcessQuest','ProcessApi/readProcessQuest');

// 将该项目标记为已完成
Route::rule('markComplete','ProcessApi/markComplete');

// 把项目恢复到未完成的状态
Route::rule('recoverComplete','ProcessApi/recoverComplete');

//---------- 此处为删除管理相关界面Api ----------
// 读取已经删除的任务信息
Route::rule('readDeleteList','DeleteApi/readDeleteList');

// 恢复项目
Route::rule('recoverQuestDel','DeleteApi/recoverQuestDel');

// 彻底删除
Route::rule('deleteQuestDel','DeleteApi/deleteQuestDel');

//---------- 此处为储存空间相关界面Api ----------
// 读取所有项目的信息
Route::rule('readAllQuestInfo','SpaceApi/readAllQuestInfo');
