import Vue from 'vue'
import App from './App.vue'
import router from './router'
import './plugins/element.js'
import './plugins/antDesign'

// // 使用AntDesign——导入
// import { Button } from 'ant-design-vue'
// import 'ant-design-vue/dist/antd.css'

// 全局CSS初始化
import './assets/css/global.css'

// Ajax
import axios from 'axios'

// 使用AntDesign——使用
// 两种使用方法皆可
// Vue.component(Button.name, Button)
// Vue.use(Button)

Vue.config.productionTip = false

// axios相关信息设置
// axios.defaults.baseURL = 'api/'
// axios.defaults.baseURL = 'http://www.tp6env.com/'
axios.defaults.baseURL = process.env.VUE_APP_API_URL
Vue.prototype.$axios = axios

new Vue({
  router,
  render: h => h(App)
}).$mount('#app')
