<template>
  <!--权限管理-->
  <div>
    <!--用户信息，以及修改密码的功能-->
    <el-card class="box-card" style="width: 300px">
      <div slot="header" class="clearfix">
        <span>修改密码</span>
      </div>
      <div class="text item">
        <span>账号：{{userInfo.workerNumber}}</span><br>
        <span>姓名：{{userInfo.workerName}}</span><br>
        <!--修改密码功能-->
        <el-button plain size="mini" style="float: right;margin: 10px 0" @click="dialogFormVisible = true">修改密码</el-button>
      </div>
    </el-card>
    <el-divider></el-divider>
    <!--暂且隐藏的修改密码的dialog框-->
    <el-dialog title="修改密码" :visible.sync="dialogFormVisible" @open="cleanPassword" :close-on-click-modal="false" @keyup.enter.native="submitChangePassword">
      <el-form :model="password">
        <el-form-item label="原密码：" label-width="100px">
          <el-input v-model="password.old" autocomplete="off" style="width: 300px"></el-input>
        </el-form-item>
        <el-form-item label="新密码：" label-width="100px">
          <el-input v-model="password.new" autocomplete="off" show-password style="width: 300px" @input="checkSame"></el-input>
        </el-form-item>
        <el-form-item label="重复密码：" label-width="100px">
          <el-input v-model="password.repect" autocomplete="off" show-password style="width: 300px" @input="checkSame"></el-input>
        </el-form-item>
        <span style="margin-left: 20px; color: limegreen">{{tipsWord}}</span>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="submitChangePassword">确 定</el-button>
      </div>
    </el-dialog>
    <!--此处为所有人员的信息，只有管理员才能观看-->
    <div v-if="showAllWorkerInfo">
      <el-card class="box-card" style="width: 800px">
        <div slot="header" class="clearfix">
          <span>人员信息管理</span>
          <el-button style="float: right;margin: -5px 20px 0 0" size="small" plain @click="addNewWorkerFormVisible = true">增加人员</el-button>
        </div>
        <div v-for="worker in workerInfo" :key="worker.up_worker_number" class="text item WorkerInfo">
          <pre style="font-size: 20px;font-family: 微软雅黑,serif; display: inline-block">   {{worker.up_worker_number}}   {{worker.up_worker_name}}   {{worker.up_power_level}}</pre>
          <el-button plain size="mini" style="float: right;margin: 20px 20px 0 0" @click="openWorkerInfo(worker)">修改信息</el-button>
        </div>
      </el-card>
    </div>
    <!--暂时隐藏的修改人员信息的dialog-->
    <el-dialog title="修改人员信息" :visible.sync="workerFormVisible" :close-on-click-modal="false" @keyup.enter.native="submitChangeWorkerInfo">
      <el-form :model="workerInfoForChange">
        <el-form-item label="账号：" label-width="100px">
          <el-input v-model="workerInfoForChange.up_worker_number" autocomplete="off" style="width: 300px" disabled></el-input>
        </el-form-item>
        <el-form-item label="姓名：" label-width="100px">
          <el-input v-model="workerInfoForChange.up_worker_name" autocomplete="off" style="width: 300px"></el-input>
        </el-form-item>
        <el-form-item label="权限：" label-width="100px">
          <el-radio v-model="workerInfoForChange.up_power_level" label="管理员">管理员</el-radio>
          <el-radio v-model="workerInfoForChange.up_power_level" label="研发人员">研发人员</el-radio>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer" style="margin-top: 20px">
        <el-popover placement="bottom" title="密码查询结果" width="200" trigger="click"
          :content="searchPasswordResult">
          <el-button slot="reference" plain size="mini" style="float: left;margin: 10px 0" @click="searchPassword">查看密码</el-button>
        </el-popover>
        <el-button @click="workerFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="submitChangeWorkerInfo">修 改</el-button>
      </div>
    </el-dialog>
    <!--暂时隐藏的增加新人员的dialog-->
    <el-dialog title="新增人员" :visible.sync="addNewWorkerFormVisible" :close-on-click-modal="false" @open="cleanAddInfo">
      <el-form :model="addNewWorkerInfo">
        <el-form-item label="账号：" label-width="100px">
          <el-input v-model="addNewWorkerInfo.up_worker_number" autocomplete="off" style="width: 300px"></el-input>
        </el-form-item>
        <el-form-item label="姓名：" label-width="100px">
          <el-input v-model="addNewWorkerInfo.up_worker_name" autocomplete="off" style="width: 300px"></el-input>
        </el-form-item>
        <el-form-item label="权限：" label-width="100px">
          <el-radio v-model="addNewWorkerInfo.up_power_level" label="管理员">管理员</el-radio>
          <el-radio v-model="addNewWorkerInfo.up_power_level" label="研发人员">研发人员</el-radio>
        </el-form-item>
        <span style="margin-left: 20px; color: limegreen">{{tipsWord}}</span>
      </el-form>
      <div slot="footer" class="dialog-footer" style="margin-top: 20px">
        <el-button @click="addNewWorkerFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="submitNewWorker">提 交</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
export default {
  data () {
    return {
      // 用户信息
      userInfo: {
        workerNumber: 0,
        workerName: '默认'
      },
      // 控制修改密码的dialog的显示
      dialogFormVisible: false,
      // 修改密码部分的数据
      password: {
        old: '',
        new: '',
        repect: '',
        workerNumber: 0
      },
      // 检验密码时所用的提示语句
      tipsWord: '',
      // 控制所有人员的信息是否显示，只有管理员能看
      showAllWorkerInfo: false,
      // 所有人员的信息列表
      workerInfo: [{
        up_worker_number: '',
        up_worker_name: '',
        up_power_level: '默认'
      }],
      // 控制人员信息修改是否显示
      workerFormVisible: false,
      // 在修改人员信息时临时储存信息的地方
      workerInfoForChange: {
        up_worker_number: '',
        up_worker_name: '',
        up_power_level: ''
      },
      // 密码查询的结果
      searchPasswordResult: '查询中……',
      // 控制新增人员是否显示
      addNewWorkerFormVisible: false,
      // 在新增人员信息时临时储存信息的地方
      addNewWorkerInfo: {
        up_worker_number: '',
        up_worker_name: '',
        up_power_level: ''
      }
    }
  },
  methods: {
    // 检验重复密码是否一样
    checkSame () {
      if (this.password.new !== this.password.repect) {
        this.tipsWord = '新密码与重复密码不一致'
      } else {
        this.tipsWord = ''
      }
    },
    // 在打开修改密码的表单时，将框内数据清空
    cleanPassword () {
      this.password.new = ''
      this.password.old = ''
      this.password.repect = ''
      // 提示信息也要清空
      this.tipsWord = ''
    },
    // 提交密码修改的申请
    async submitChangePassword () {
      // 先验证数据的合法性
      if (this.password.old === '' || this.password.new === '') {
        this.tipsWord = '密码不能为空'
        return
      } else if (this.password.new !== this.password.repect) {
        this.tipsWord = '新密码与重复密码不一致'
        return
      } else if (this.password.new === this.password.old) {
        this.tipsWord = '新密码与原密码相同'
        return
      }
      // 然后传输请求
      this.password.workerNumber = this.userInfo.workerNumber
      const { data: res } = await this.$axios.post('changePassword', this.password)
      if (res === 'success') {
        this.$message({ message: '密码修改成功', type: 'success' })
        this.dialogFormVisible = false
      } else {
        this.tipsWord = '原密码不正确'
      }
    },
    // 取得所有人员的信息，并绑定数据
    async getAllWorkerInfo () {
      const { data: res } = await this.$axios.post('getWorkerList')
      this.workerInfo = res
    },
    // 打开人员信息修改框，并且将信息存入临时区
    openWorkerInfo (worker) {
      this.workerFormVisible = true
      // 这里要深拷贝一份临时数据，免得取消修改以后，影响外面的数据
      this.workerInfoForChange = JSON.parse(JSON.stringify(worker))
    },
    // 修改信息的表单提交，进行信息修改
    async submitChangeWorkerInfo () {
      const { data: res } = await this.$axios.post('changeWorkerInfo', this.workerInfoForChange)
      console.log(res)
      // 别忘了最后关上
      this.workerFormVisible = false
      // 关上后更新一下数据
      await this.getAllWorkerInfo()
    },
    // 查看人员的密码
    async searchPassword () {
      // 查询密码之前先清空查询结果
      this.searchPasswordResult = '查询中……'
      const { data: res } = await this.$axios.post('searchPassword', this.workerInfoForChange)
      this.searchPasswordResult = res
    },
    // 在添加新人员前，将信息清空
    cleanAddInfo () {
      this.addNewWorkerInfo.up_worker_number = ''
      this.addNewWorkerInfo.up_worker_name = ''
      this.addNewWorkerInfo.up_power_level = '研发人员'
    },
    // 向后台发送增加新员工的表单
    async submitNewWorker () {
      // 共用一个提示信息没问题，不过得清空
      this.tipsWord = ''
      // 先判断一下，账号和姓名不能为空
      if (this.addNewWorkerInfo.up_worker_number === '' || this.addNewWorkerInfo.up_worker_name === '') {
        this.tipsWord = '账号与姓名不能为空'
        return
      }
      const { data: res } = await this.$axios.post('addNewWorker', this.addNewWorkerInfo)
      if (res === 'failed') {
        this.tipsWord = '账号已存在'
        return
      }
      this.$message({ message: '增加成功，密码与账号相同', type: 'success' })
      // 别忘了把窗口关上
      this.addNewWorkerFormVisible = false
      // 再把数据刷新一下
      await this.getAllWorkerInfo()
    }
  },
  mounted () {
    // 取出用户名
    const nowUser = window.sessionStorage.getItem('nowUser').split('-')
    this.userInfo.workerNumber = nowUser[1]
    this.userInfo.workerName = nowUser[0]
    // 如果是管理员，就可以看到所有人的信息
    this.showAllWorkerInfo = window.sessionStorage.getItem('power_level') === '管理员'
    // 然后获取并绑定所有人员的信息，由于生命周期问题，要稍微推迟一点
    this.$nextTick(function () {
      // 获取数据库中所有的员工名单
      this.getAllWorkerInfo()
    })
  }
}
</script>

<style lang="less" scoped>
//所有员工的信息部分，鼠标悬停效果
.WorkerInfo:hover{
  background-color: #F5F7FA;
}
</style>
