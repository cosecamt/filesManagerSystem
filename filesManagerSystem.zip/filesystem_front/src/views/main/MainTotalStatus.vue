<template>
  <!--项目统计-->
  <div>
    项目总体
  </div>
</template>

<script>
export default {
  data()   {
    return 
  },
  methods:{
    rurn(){
      let sda =23123
      console.log(sda)
    }

  }

}
</script>

<style>

</style>
