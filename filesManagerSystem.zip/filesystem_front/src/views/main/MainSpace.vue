<template>
  <div>
    <div id="main" style="width: 600px;height:400px;"></div>
    <!--总计的空间统计-->
    <!--各项目的空间统计-->
  </div>
</template>

<script>
// import echarts from 'echarts'
import * as echarts from 'echarts'

export default {
  data () {
    return {
      fileList: [],
      sizeList: []
    }
  },
  methods: {
    // 从后台取出所有项目的数据
    async readAllQuestInfo () {
      const { data: res } = await this.$axios.post('readAllQuestInfo')
      this.fileList = res[0]
      this.sizeList = res[1]
    }

  },
  async mounted () {
    await this.readAllQuestInfo()
    // 可视化
    var myChart = echarts.init(document.getElementById('main'))

    var option = {
      title: {
        text: '项目所占大小总量',
        subtext: '单位为：Mb'
      },
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      grid: {
        left: '3%',
        right: '4%',
        bottom: '3%',
        containLabel: true
      },
      xAxis: {
        type: 'value',
        boundaryGap: [0, 0.01]
      },
      yAxis: {
        type: 'category',
        data: ['巴西', '印尼', '美国', '印度', '中国', '世界人口(万)']
      },
      series: [
        {
          name: '2011年',
          type: 'bar',
          data: [18203, 23489, 29034, 104970, 131744, 630230],
          label: {
            show: true,
            position: ['95%', '20%'],
            formatter: '{c} Mb'
          }
        }
      ]
    }

    option.yAxis.data = this.fileList
    option.series[0].data = this.sizeList

    console.log(this.sizeList)

    myChart.setOption(option)
  }
}
</script>

<style lang="less" scoped>

</style>
