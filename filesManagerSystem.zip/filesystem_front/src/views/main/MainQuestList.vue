<template>
  <!--用户-项目列表-->
  <div>
    <el-button type="success" style="margin-bottom: 15px" @click="dialogFormVisible = true">新增项目</el-button>
    <!--选择显示的项目-->
    <el-radio-group v-model="radioData" @change="searchStart" style="display: block; margin-bottom: 20px;">
      <el-radio-button label="所有项目"></el-radio-button>
      <el-radio-button label="负责的项目"></el-radio-button>
      <el-radio-button label="参加的项目"></el-radio-button>
      <el-radio-button label="所有人参与"></el-radio-button>
      <el-radio-button label="搜索"></el-radio-button>
      <el-input v-model="wordSearch" placeholder="请输入内容" class="SearchInput" :disabled="switchSearch"></el-input>
    </el-radio-group>
    <!--项目列表-->
    <el-table :data="filterData(tableData)" @cell-click="clickCell" border
              :default-sort = "{prop: 'qi_create_time', order: 'descending'}">
      <el-table-column prop="qi_quest_number" label="编号" min-width="5%"></el-table-column>
      <el-table-column prop="qi_quest_name" label="项目名" min-width="30%"></el-table-column>
      <el-table-column prop="combineNumerName" label="负责人" min-width="8%"></el-table-column>
      <el-table-column prop="qi_partner" label="参与者" min-width="20%"></el-table-column>
      <el-table-column label="操作" min-width="5%">
        <template slot-scope="scope">
          <el-button plain size="mini" style="margin: 0 0 0 15px" @click="changeQuestInfo(scope.row)">修 改</el-button>
        </template>
      </el-table-column>
      <el-table-column prop="qi_create_time" label="创建时间" min-width="5%" sortable></el-table-column>
    </el-table>
    <!--暂时隐藏的新建项目表单-->
    <el-dialog title="新建项目" :visible.sync="dialogFormVisible" :close-on-click-modal="false" @open="cleanNewForm">
      <el-form :model="formInformation" @keyup.enter.native="submitForm">
        <el-form-item label="项目名称" label-width="120px">
          <el-input v-model="formInformation.questName" autocomplete="off"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="submitForm">确 定</el-button>
      </div>
    </el-dialog>
    <!--暂时隐藏的修改负责人和参与者的框，现在项目信息也加在里面-->
    <el-dialog title="修改项目信息" :visible.sync="dialogWorkerVisible" :close-on-click-modal="false" width="800px" @keyup.enter.native="submitFormWorkerChange">
      <div class="WorkerChange">
        <span class="WorkerChangeItem">项目编号：{{workerChangeInfo.qi_quest_number}}</span><br>
        <span class="WorkerChangeItem">项目名：</span>
        <el-input v-model="formInfoForChange.qi_quest_name" placeholder="不能为空" class="QuestNameInput" :disabled="switchChangeQuestName"></el-input>
        <!--修改项目名和删除功能-->
        <el-button type="warning" size="mini" :disabled="switchDeleteAndChange" @click="switchChangeQuestName=!switchChangeQuestName" style="margin-right: 20px">修改项目名</el-button>
        <el-popconfirm title="确定删除吗？" @confirm="deleteQuest">
          <el-button type="danger" slot="reference" :disabled="switchDeleteAndChange" size="mini">删除项目</el-button>
        </el-popconfirm><br>
        <!--负责人下拉菜单-->
        <span class="WorkerChangeItem">负责人：</span>
        <el-select v-model="formInfoForChange.up_worker_number" placeholder="请选择" size="small" :disabled="powerSelect">
          <el-option
            v-for="item in workerList"
            :key="item.up_worker_number"
            :label="item.up_worker_name+'-'+item.up_worker_number"
            :value="item.up_worker_number">
          </el-option>
        </el-select><br>
        <!--参与者多选-->
        <span class="WorkerChangeItem">参与者：{{formInfoForChange.qi_partner}}</span><br>
        <el-checkbox v-model="checkedPartnerIsAll" :disabled="powerPartnerIsAll" style="margin-bottom: 20px" @change="changeCheckAndBox">所有人都可以编辑</el-checkbox>
        <el-checkbox-group v-model="partnerList" size="small" @change="changePartner" :disabled="powerCheckBox">
          <el-checkbox v-for="worker in workerList" v-bind:key="worker.up_worker_number"
                       :label="worker.up_worker_name + '-' +worker.up_worker_number" border
                       style="width: 150px;margin-left: 10px;">
          </el-checkbox>
        </el-checkbox-group>
      </div>
      <div slot="footer" class="dialog-footer" style="margin-top: 500px">
        <el-button @click="dialogWorkerVisible = false">取 消</el-button>
        <el-button type="primary" @click="submitFormWorkerChange">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>

export default {
  data () {
    return {
      // 从后端读取的表格的值
      tableData: [{
        // 其实很多值没任何用，只是容易理解里面都有什么东西
        qi_quest_number: '',
        up_worker_number: '',
        qi_quest_name: '',
        qi_create_time: '',
        qi_partner: '',
        up_worker_name: '',
        combineNumerName: ''
      }],
      // 新建项目时表单的值
      formInformation: {
        questName: '',
        workerName: ''
      },
      // 控制新建项目表单的显示和隐藏
      dialogFormVisible: false,
      // 雷达图绑定数据
      radioData: '所有项目',
      // 控制修改人员表单的显示和隐藏
      dialogWorkerVisible: false,
      // 人员调整窗口所需用到的绑定数据
      workerChangeInfo: {
        qi_quest_number: '',
        up_worker_number: '',
        qi_quest_name: '',
        qi_partner: '',
        up_worker_name: ''
      },
      // 将数据库中的人员全部拿出来，提供给人员调整的备选项用
      workerList: [],
      // 参与者绑定数组
      partnerList: [],
      // 在打开窗口时用此处数据进行修改，以保证原数据不被更改
      formInfoForChange: {
        qi_quest_number: '',
        up_worker_number: '',
        qi_quest_name: '',
        qi_partner: '',
        up_worker_name: ''
      },
      // 修改人员时下拉条的操作权限，要注意，这里true是禁止，false是允许
      powerSelect: true,
      // 修改人员时多选框的操作权限，要注意，这里true是禁止，false是允许
      powerCheckBox: true,
      // 用于确认参与者是否为所有人
      checkedPartnerIsAll: false,
      // 修改人员时所有人为参与者的操作权限，要注意，这里true是禁止，false是允许
      powerPartnerIsAll: true,
      // 筛选字段的输入框
      wordSearch: '',
      // 搜索功能控制
      switchSearch: true,
      // 修改项目名的输入框的可编辑开关
      switchChangeQuestName: true,
      // 修改项目名的功能和删除的功能开关
      switchDeleteAndChange: true
    }
  },
  methods: {
    // 提交表单，建立新的项目
    async submitForm () {
      // 先确认不是开头空格且不为空
      if (this.formInformation.questName[0] === ' ' || this.formInformation.questName === '') {
        return
      }
      const { data: result } = await this.$axios.post('newQuest', this.formInformation)
      console.log(result)
      if (result === 'success') {
        this.$message({ message: '新建成功', type: 'success' })
        this.dialogFormVisible = false
        // 本来是刷新页面来着，但是更新绑定数据来得好
        await this.searchQusetList()
      } else {
        this.$message({ message: '新建失败', type: 'warning' })
      }
    },
    // 读取项目列表
    async searchQusetList () {
      const { data: result } = await this.$axios.post('searchQuestList')
      this.tableData = result
      this.tableData.forEach(value => {
        // 把员工名字和编号拼接起来
        value.combineNumerName = value.up_worker_name + '-' + value.up_worker_number
        // 把时间处理下，只保留年月日
        value.qi_create_time = value.qi_create_time.split(' ')[0]
      })
    },
    // 获取ID并且跳转到相应的文件列表路由
    clickCell (row, col) {
      if (col.label === '项目名') {
        this.$router.push('/main/filelist/' + row.qi_quest_number)
      }
    },
    // 筛选表格数据
    filterData (tableData) {
      switch (this.radioData) {
        case '所有项目':
          return tableData
        case '负责的项目':
          // 用filter()筛选出和缓存中一样的用户
          tableData = tableData.filter((dataCheck) => {
            if ((dataCheck.up_worker_name + '-' + dataCheck.up_worker_number) === window.sessionStorage.getItem('nowUser')) {
              return dataCheck
            }
          })
          return tableData
        case '参加的项目':
          // 用filter()筛选出缓存中用户包含在参与者中的数据
          tableData = tableData.filter((dataCheck) => {
            if (dataCheck.qi_partner.search(window.sessionStorage.getItem('nowUser')) !== -1) {
              return dataCheck
            }
          })
          return tableData
        case '所有人参与':
          // 筛选出参与者为“所有人”的数据
          tableData = tableData.filter((dataCheck) => {
            if (dataCheck.qi_partner === '所有人') {
              return dataCheck
            }
          })
          return tableData
        case '搜索':
          // 按搜索框搜索
          tableData = tableData.filter((dataCheck) => {
            // 编号这里比较特殊，编号是int，但是search函数本质是正则，只能作用于字符串
            if (dataCheck.qi_partner.search(this.wordSearch) !== -1 ||
                dataCheck.qi_quest_name.search(this.wordSearch) !== -1 ||
                dataCheck.combineNumerName.search(this.wordSearch) !== -1 ||
                dataCheck.qi_quest_number.search(this.wordSearch) !== -1
            ) {
              return dataCheck
            }
          })
          return tableData
      }
    },
    // 在开始就获取数据库中所有的员工名单
    async getWorkerList () {
      const { data: res } = await this.$axios.post('getWorkerList')
      this.workerList = res
    },
    // 修改一下参与者的数组以保持绑定数据同步
    changePartner () {
      // 如果所有人的钩是被勾上，那么就不做后续的事情
      if (this.checkedPartnerIsAll) {
        return
      }
      // 不是所有人，那就正常拆分
      if (this.partnerList.length !== 0) {
        this.formInfoForChange.qi_partner = this.partnerList.join(';') + ';'
      } else {
        this.formInfoForChange.qi_partner = ''
      }
    },
    // 提交人员修改表单到后台
    async submitFormWorkerChange () {
      // 不能将名字改为空格
      if (this.formInfoForChange.qi_quest_name[0] === ' ' || this.formInfoForChange.qi_quest_name === '') {
        this.formInfoForChange.qi_quest_name = this.workerChangeInfo.qi_quest_name
      }
      const { data: res } = await this.$axios.post('changeWorker', this.formInfoForChange)
      // 关闭窗口，刷新数据
      this.dialogWorkerVisible = false
      await this.searchQusetList()
      console.log(res)
    },
    // 将“所有人”勾选后，更新数据为所有人
    changeCheckAndBox () {
      if (this.checkedPartnerIsAll) {
        this.formInfoForChange.qi_partner = '所有人'
      } else {
        this.formInfoForChange.qi_partner = ''
        this.partnerList = []
      }
    },
    // 搜索功能开启
    searchStart () {
      if (this.radioData === '搜索') {
        this.switchSearch = false
      } else {
        this.switchSearch = true
        this.wordSearch = ''
      }
    },
    // 删除项目的功能
    async deleteQuest () {
      // 将项目编号发送给后台进行删除
      const { data: res } = await this.$axios.post('deleteQuest', this.workerChangeInfo)
      // 删除完毕关闭窗口，刷新数据
      this.dialogWorkerVisible = false
      await this.searchQusetList()
      console.log(res)
    },
    // 点击按钮，进行项目信息的修改
    changeQuestInfo (row) {
      // 同时将人员调整所需要的数据同步
      const indexQuest = this.tableData.findIndex(rowData => {
        return rowData.qi_quest_number === row.qi_quest_number
      })
      this.workerChangeInfo = this.tableData[indexQuest]
      // 拷贝到临时表单数组中去，这样不对原数据产生影响，注意使用深拷贝
      this.formInfoForChange = JSON.parse(JSON.stringify(this.workerChangeInfo))
      // 把参与者同步到数组，将字符串以分号切分，组成数组
      if (this.formInfoForChange.qi_partner === '') {
        this.partnerList = []
      } else {
        const stringDelSymbol = this.formInfoForChange.qi_partner.slice(0, -1)
        this.partnerList = stringDelSymbol.split(';')
      }
      // 修改人员时，负责人下拉条的操作权限，要注意，这里true是禁止，false是允许
      this.powerSelect = !(window.sessionStorage.getItem('power_level') === '管理员')
      // 修改人员时，参与者多选框的操作权限，删除和修改项目的权限也在这，要注意，这里true是禁止，false是允许
      if (window.sessionStorage.getItem('power_level') === '管理员' ||
        window.sessionStorage.getItem('nowUser').split('-')[1] === this.formInfoForChange.up_worker_number) {
        this.powerCheckBox = false
        this.powerPartnerIsAll = false
        this.switchDeleteAndChange = false
      } else {
        this.powerCheckBox = true
        this.powerPartnerIsAll = true
        this.switchDeleteAndChange = true
      }
      // 再看一下参与者是否是所有人，如果是的话，勾选选项并且禁用多选框
      this.checkedPartnerIsAll = this.formInfoForChange.qi_partner === '所有人'
      // 打开前让项目名的编辑框不能编辑
      this.switchChangeQuestName = true
      // 打开该项目的人员调整界面
      this.dialogWorkerVisible = true
    },
    // 再打开新建项目时，清空之前残留的文字
    cleanNewForm () {
      this.formInformation.questName = ''
    }
  },
  mounted () {
    // 读取缓存中的用户名，以作他用
    const usernameSplit = window.sessionStorage.getItem('nowUser').split('-')
    this.formInformation.workerName = usernameSplit[usernameSplit.length - 1]
    // 由于生命周期问题，将读取列表的工作稍微推迟一点
    this.$nextTick(function () {
      // 读取项目列表
      this.searchQusetList()
      // 在开始就获取数据库中所有的员工名单
      this.getWorkerList()
    })
  }
}
</script>

<style lang="less" scoped>
//修改成员对话框中的样式
.WorkerChange
{
  position: absolute;
  left: 50%;
  transform: translate(-50%, 0);
  padding: 10px;
  width: 80%;
  //其中的三行字的样式
  .WorkerChangeItem{
    display: inline-block;
    font-size: 20px;
    margin-bottom: 20px;
    margin-right: 10px;
  }
}
//对话框下两个按钮的位置
.dialog-footer{
  margin-top: 400px;
}
//搜索框
.SearchInput{
  top: 5px;
  margin-left: 30px;
  width: 300px;
}
//修改项目名的输入框
.QuestNameInput{
  margin-right: 20px;
  width: 300px;
}
</style>
