<template>
  <div>
    <span style="display: inline-block;margin-bottom: 15px">已删除项目列表：</span>
    <el-card style="width: 850px;">
      <div class="ContainerList">
        <div class="ContainerCarton" :key="questItem.qi_quest_number" v-for="questItem in questList">
          <span class="ItemCarton-3">{{questItem.qi_quest_number + ":" + questItem.qi_quest_name}}</span>
          <!--恢复项目-->
          <el-popconfirm class="ItemCarton-2" title="要恢复这个项目么？" @confirm="recoverQuestDel(questItem.qi_quest_number,questItem.qi_quest_number+'-'+questItem.qi_quest_name)">
            <el-button slot="reference" size="mini">恢复项目</el-button>
          </el-popconfirm>
          <!--彻底删除-->
          <el-popconfirm class="ItemCarton-1" title="你要彻底删除这个项目么？" @confirm="deleteQuestDel(questItem.qi_quest_number,questItem.qi_quest_number+'-'+questItem.qi_quest_name)">
            <el-button slot="reference" size="mini">彻底删除</el-button>
          </el-popconfirm>
        </div>
      </div>
    </el-card>
  </div>
</template>

<script>
export default {
  data () {
    return {
      questList: []
    }
  },
  methods: {
    // 读取已经被删除的任务信息
    async readDeleteList () {
      const { data: res } = await this.$axios.post('readDeleteList')
      this.questList = res
      console.log(res)
    },
    // 恢复项目
    async recoverQuestDel (id, idName) {
      const { data: res } = await this.$axios.post('recoverQuestDel', { id: id, idName: idName })
      console.log(res)
      // 弄完记得重新读一下数据
      await this.readDeleteList()
    },
    // 彻底删除
    async deleteQuestDel (id, idName) {
      const { data: res } = await this.$axios.post('deleteQuestDel', { id: id, idName: idName })
      console.log(res)
      // 弄完记得重新读一下数据
      await this.readDeleteList()
    }
  },
  mounted () {
    this.readDeleteList()
  }
}
</script>

<style lang="less" scoped>
//列表的grid
.ContainerList{
  display: grid;
  grid-gap: 10px 0;
}
//条目的grid
.ContainerCarton{
  display: grid;
  grid-gap: 0 10px;
  grid-template-columns: repeat(auto-fill, 100px);
  .ItemCarton-1{
    grid-column: -2 / -1;
  }
  .ItemCarton-2{
    grid-column: -3 / -2;
  }
  .ItemCarton-3{
    grid-column: 1 / 3;
  }
}
</style>
