<template>
  <div>
    操作日志
    <!--查看项目的操作日志-->
  </div>
</template>

<script>
export default {

}
</script>

<style scoped>

</style>
