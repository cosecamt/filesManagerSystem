<template>
  <!--用户-欢迎界面-->
  <div>
    <p>欢迎 {{userName}} 使用智能车辆研究所档案管理系统！</p>
  </div>
</template>

<script>
export default {
  data () {
    return {
      userName: '未知'
    }
  },
  mounted () {
    this.userName = window.sessionStorage.getItem('nowUser')
  }
}
</script>

<style>

</style>
