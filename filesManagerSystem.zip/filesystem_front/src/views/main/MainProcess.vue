<template>
  <div>
    <!--上方功能区-->
    <!--筛选已完成和未完成-->
    <el-radio-group @change="changeRadio" v-model="radioComplete">
      <el-radio-button label="已完成的项目"></el-radio-button>
      <el-radio-button label="未完成的项目"></el-radio-button>
    </el-radio-group>
    <el-divider></el-divider>
    <!--备份列表-->
    <el-card style="width: 850px;">
      <div class="ContainerList">
        <div class="ContainerCarton" :key="questItem.qi_quest_number" v-for="questItem in questList">
          <span class="ItemCarton-3">{{questItem.qi_quest_number + ":" + questItem.qi_quest_name}}</span>
          <!--标记为已完成-->
          <el-popconfirm v-show="switchShow(radioComplete)" class="ItemCarton-1" title="要标记为已完成么？" @confirm="markComplete(questItem.qi_quest_number)">
            <el-button slot="reference" size="mini">标记为已完成</el-button>
          </el-popconfirm>
          <!--下载压缩包-->
          <el-popconfirm v-show="!switchShow(radioComplete)" class="ItemCarton-2" title="你要下载这个压缩包么？" @confirm="downloadComplete(questItem.qi_quest_number+'-'+questItem.qi_quest_name)">
            <el-button slot="reference" size="mini">下载此压缩包</el-button>
          </el-popconfirm>
          <!--标记为未完成-->
          <el-popconfirm v-show="!switchShow(radioComplete)" class="ItemCarton-1" title="要还原成未完成状态么？" @confirm="recoverComplete(questItem.qi_quest_number)">
            <el-button slot="reference" size="mini">恢复为未完成</el-button>
          </el-popconfirm>
        </div>
      </div>
    </el-card>
  </div>
</template>

<script>
export default {
  data () {
    return {
      radioComplete: '已完成的项目',
      questList: []
    }
  },
  methods: {
    // 根据筛选来读取任务列表
    async readProcessQuest () {
      const { data: res } = await this.$axios.post('readProcessQuest', { radio: this.radioComplete })
      this.questList = res
    },
    // 调整功能按钮的显示
    switchShow (radioComplete) {
      return radioComplete !== '已完成的项目'
    },
    // 在单选变化的时候，要重新读取数据
    changeRadio () {
      this.readProcessQuest()
    },
    // 将该项目标记为已完成
    async markComplete (id) {
      const { data: res } = await this.$axios.post('markComplete', { id: id })
      console.log(res)
      await this.readProcessQuest()
    },
    // 下载这个已完成的项目
    async downloadComplete (idName) {
      // const backDir = '../../fileStorage/complete/智2021-001-刚凤凰.zip'
      const backDir = '../../fileStorage/complete/' + idName + '.zip'
      console.log(backDir)
      window.open(process.env.VUE_APP_DOWNLOAD_URL + backDir)
    },
    // 把项目恢复到未完成的状态
    async recoverComplete (id) {
      const { data: res } = await this.$axios.post('recoverComplete', { id: id })
      console.log(res)
      await this.readProcessQuest()
    }
  },
  mounted () {
    this.readProcessQuest()
  }
}
</script>

<style lang="less" scoped>
//列表的grid
.ContainerList{
  display: grid;
  grid-gap: 10px 0;
}
//条目的grid
.ContainerCarton{
  display: grid;
  grid-gap: 0 10px;
  grid-template-columns: repeat(auto-fill, 100px);
  .ItemCarton-1{
    grid-column: -2 / -1;
  }
  .ItemCarton-2{
    grid-column: -3 / -2;
  }
  .ItemCarton-3{
    grid-column: 1 / 3;
  }
}
</style>
