<template>
  <!--整体布局容器-->
  <el-container class="BoxContainer">
    <!--头部栏-->
    <el-header class="BoxHeader" height="80px">
      <div class="BoxHeaderInformation">
        <img src="../../assets/picture/MainLogo.png" alt="">
        <span>智能车辆研究所档案管理系统</span>
      </div>
      <!--登出账户-->
      <el-button type="success" @click="logout">退出</el-button>
    </el-header>
    <el-container>
      <!--边栏-->
      <el-aside class="BoxAside" width="200px">
        <el-menu
          :default-active="highlightItem"
          class="el-menu-vertical-demo"
          background-color="#333744"
          text-color="#fff"
          active-text-color="#ffd04b"
          router
          style="border-right: none">
          <!--项目浏览-->
          <el-menu-item index="/main/questlist">
            <i class="el-icon-s-management"></i>
            <span ref="text" slot="title">项目浏览</span>
          </el-menu-item>
          <!--权限管理-->
          <el-menu-item index="/main/power">
            <i class="el-icon-s-check"></i>
            <span slot="title">权限管理</span>
          </el-menu-item>
          <!--文件备份-->
          <el-menu-item index="/main/backup">
            <i class="el-icon-s-finance"></i>
            <span slot="title">文件备份</span>
          </el-menu-item>
          <!--进度管理-->
          <el-menu-item index="/main/process">
            <i class="el-icon-s-flag"></i>
            <span slot="title">进度管理</span>
          </el-menu-item>
          <!--操作日志，暂时隐藏-->
          <el-menu-item index="/main/journal" v-show="false">
            <i class="el-icon-s-order"></i>
            <span slot="title">操作日志</span>
          </el-menu-item>
          <!--删除回收-->
          <el-menu-item index="/main/delete">
            <i class="el-icon-s-release"></i>
            <span slot="title">删除回收</span>
          </el-menu-item>
          <!--储存空间-->
          <el-menu-item index="/main/space">
            <i class="el-icon-s-data"></i>
            <span slot="title">数据可视</span>
          </el-menu-item>
          <!--这个总体概览感觉没用，暂时隐藏-->
          <el-menu-item index="/main/total" v-show="false">
            <i class="el-icon-menu"></i>
            <span slot="title">总体概览</span>
          </el-menu-item>
        </el-menu>
      </el-aside>
      <!--子组件部分-->
      <el-main>
        <router-view></router-view>
      </el-main>
    </el-container>
  </el-container>
</template>

<script>
export default {
  data () {
    return {
      highlightItem: ''
    }
  },
  methods: {
    // 登出账户
    logout () {
      window.sessionStorage.clear()
      this.$router.push('/')
    },
    // 根据路由高亮菜单栏
    highlightFresh () {
      this.highlightItem = this.$route.path
    }
  },
  mounted () {
    this.highlightFresh()
  }
}
</script>

<style lang="less" scoped>
//整体布局容器
.BoxContainer{
  height: 100%;
}
//头部栏
.BoxHeader{
  display: flex;
  align-items: center;
  background-color: #373d41;
  //头部栏内容
  .BoxHeaderInformation{
    display: flex;
    position: relative;
    align-items: center;
    img{
      display: inline-block;
      height: 70px;
      width: 70px;
    }
    span{
      color: white;
      font-size: 20px;
    }
  }
  button{
    position: absolute;
    right: 30px;
  }
}
//边栏
.BoxAside{
  background-color: #333744;
}

</style>
