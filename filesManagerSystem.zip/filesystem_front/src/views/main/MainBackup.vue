<template>
  <div>
    <!--上方功能区-->
    <div class="containerButton">
      <!--上次备份的时间显示-->
      <span class="itemButton itemButton-1">最新备份时间为：{{LastestTime}}</span>
      <!--备份按钮-->
      <div class="itemButton">
        <el-popconfirm title="确定要备份么？" @confirm="backupNow">
          <el-button type="primary" slot="reference">现在备份</el-button>
        </el-popconfirm>
      </div>
      <div class="itemButton">
        <el-popconfirm title="确定要删除么？" @confirm="deleteBackup">
          <el-button type="primary" slot="reference">删除多余备份</el-button>
        </el-popconfirm>
        <br>
        保留
        <input v-model="inputCount" style="width: 30px;margin-top: 5px;">
        个备份文件(时间最接近)
      </div>
    </div>
    <el-divider></el-divider>
    <!--备份列表-->
    <el-card style="width: 800px;">
      <span>备份文件列表</span>
      <el-divider></el-divider>
      <div class="containerList">
        <div class="containerCarton" :key="backupItem" v-for="backupItem in backupList">
          <span class="itemBackupList-1">{{backupItem}}</span>
          <!--使用备份文件-->
          <el-popconfirm title="确定要使用备份么？" @confirm="recoverBackup(backupItem)">
            <el-button slot="reference" size="mini">使用此备份</el-button>
          </el-popconfirm>
        </div>
      </div>
    </el-card>
    <!--保留最近的10份，其余删除-->
  </div>
</template>

<script>
export default {
  data () {
    return {
      // 后台给的备份文件列表
      backupList: [],
      // 最新的文件的时间
      LastestTime: '无',
      // 要删除的数量
      inputCount: 10
    }
  },
  methods: {
    // 此时备份
    async backupNow () {
      const { data: res } = await this.$axios.post('backupNow')
      console.log(res)
      // 完成后重新读数据
      await this.readBackupList()
    },
    // 读取备份列表
    async readBackupList () {
      const { data: res } = await this.$axios.post('readBackupList')
      this.backupList = res
      // 分析一下最近的备份时间，显示到上面去
      this.LastestTime = this.timeNum2Word(res[0])
    },
    // 根据数字，返回时间的汉字
    timeNum2Word (numTime) {
      // 给入的数字格式为：20210518-114835.zip
      // 需要转换成为：2021年05月18日-11时48分35秒
      const date = numTime.slice(0, 4) + '年' + numTime.slice(4, 6) + '月' + numTime.slice(6, 8) + '日'
      const clock = numTime.slice(9, 11) + '时' + numTime.slice(11, 13) + '分' + numTime.slice(13, 15) + '秒'
      return date + '-' + clock
    },
    // 删除一定数量的备份
    async deleteBackup () {
      const { data: res } = await this.$axios.post('deleteBackup', { count: this.inputCount })
      console.log(res)
      // 弄完刷新一下数据
      await this.readBackupList()
    },
    // 指定备份文件恢复，不过会先将当前文件备份，再恢复
    async recoverBackup (backupItem) {
      // 先备份当前文件
      await this.backupNow()
      // 然后恢复选定文件
      const { data: res } = await this.$axios.post('recoverBackup', { name: backupItem })
      console.log(res)
    }
  },
  mounted () {
    this.readBackupList()
  }
}
</script>

<style lang="less" scoped>
//上方功能区grid
.containerButton{
  display: grid;
  grid-gap: 0 15px;
  grid-template-columns: 100px 300px;
  grid-template-rows: repeat(auto-fill, 40px);
  .itemButton{

  }
  .itemButton-1{
    grid-column: 1 / -1;
  }
}
//每条列表中的grid
.containerList{
  display: grid;
  grid-gap: 15px 0;
  //grid-template-columns: repeat(auto-fill, 100px);
}
//备份列表grid
.containerCarton{
  font-size: 22px;
  display: grid;
  grid-template-columns: auto 100px;
}

</style>
