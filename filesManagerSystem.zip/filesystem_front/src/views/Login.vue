<!--suppress ALL -->
<template>
  <!--登录界面-->
  <div class="BoxHighly">
    <!--登录表单盒子-->
    <div class="BoxForm">
      <!--登录表单-->
      <el-form class="FormInput" ref="refFormInformation" :model="formInformation" label-width="60px">
        <el-form-item prop="username" label="账号">
          <el-input v-model="formInformation.workNumber" @keyup.enter.native="login"></el-input>
        </el-form-item>
        <el-form-item prop="password" label="密码">
          <el-input v-model="formInformation.password" show-password @keyup.enter.native="login"></el-input>
        </el-form-item>
      </el-form>
    </div>
    <!--登录界面Logo盒子-->
    <div class="BoxPicture">
      <img src="../assets/picture/LoginLogo.png" alt=""  >
    </div>
    <!--按钮盒子-->
    <div class="BoxButton">
      <!--登录和清空按钮-->
      <el-row>
        <el-button type="success" @click="login">登录</el-button>
        <el-button type="info" @click="resetForm">清空</el-button>
      </el-row>
    </div>
  </div>
</template>

<script>
export default {
  data () {
    return {
      // 表单数据
      formInformation: {
        workNumber: '',
        password: ''
      }
    }
  },
  methods: {
    // 表单清空
    resetForm () {
      this.$refs.refFormInformation.resetFields()
    },
    // 登录功能
    async login () {
      const info = this.formInformation
      const { data: res } = await this.$axios.post('loginCheck', info)
      if (res === 'failed' || res === 'NoUser') {
        alert('登陆失败！')
      } else {
        // 保留Token
        window.sessionStorage.setItem('token', 'testToken')
        // 存入账号，用于后续检测
        window.sessionStorage.setItem('nowUser', res.up_worker_name + '-' + res.up_worker_number)
        // 存个权限等级吧，暂且这样用于调试，以后给axios加过滤器，带token
        window.sessionStorage.setItem('power_level', res.up_power_level)
        await this.$router.push('/main/welcome')
      }
    }
  }
}
</script>

<style lang="less" scoped>
//登录界面
.BoxHighly{
  height: 100%;
  background-color: #2b4b66;
  //登录界面Logo盒子
  .BoxPicture{
    position: absolute;
    left: 50%;
    top: 38%;
    transform: translate(-50%, -50%);
    width: 400px;
    height: 80px;
    img{
      height: 100%;
      width: 100%;
    }
  }
  //登录表单盒子
  .BoxForm{
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
    width: 500px;
    height: 400px;
    border: 2px solid gray;
    border-radius: 10px;
    box-shadow: 5px 5px 50px gray;
    background-color: #eeeeeeee;
    //登录表单
    .FormInput{
      position: absolute;
      left: 50%;
      top: 58%;
      transform: translate(-50%, -50%);
      width: 380px;
      //字体大小
      /deep/.el-form-item__label{
        font-size: 16px;
      }
    }
  }
  //按钮盒子
  .BoxButton{
    position: absolute;
    left: 50%;
    top: 63%;
    transform: translate(-50%, -50%);
    //按钮大小和间隔
    .el-button{
      margin: 0 20px;
      /deep/span{
      font-size: 18px;
      }
    }
  }
}
</style>
