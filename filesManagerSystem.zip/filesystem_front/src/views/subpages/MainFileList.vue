<template>
  <!--用户-项目-文件列表-->
  <div>
    <!--头部面包屑-->
    <el-breadcrumb separator-class="el-icon-arrow-right" style="margin-bottom: 20px">
      <el-breadcrumb-item :to="{ path: '/main/questlist' }">项目浏览</el-breadcrumb-item>
      <el-breadcrumb-item>{{pageQuest}}</el-breadcrumb-item>
    </el-breadcrumb>
    <!--搜索框-->
    <span>搜索：</span>
    <el-input placeholder="输入关键字进行过滤" v-model="filterText" style="width: 500px;"></el-input>
    <!--树形文件列表-->
    <div class="custom-tree-container">
      <div class="block">
        <span style="margin: 0">商务类文件</span>
        <span class="DirWord">{{dirBusiness}}</span>
        <el-tree :data="dataBusiness" node-key="id" highlight-current
                 @node-click="(event, node) => labelWork(event, node, '商务')"
                 :default-expanded-keys = '[nodeExtend.nodeBusiness]' @node-contextmenu="rightClick"
                 :filter-node-method="filterNode" ref="tree">
          <span class="custom-tree-node" slot-scope="{ node, data }">
            <span><i :class="data.icon"></i>{{ node.label }}</span>
          </span>
        </el-tree>
      </div>
      <div class="block">
        <span style="margin: 0">技术类文件</span>
        <span class="DirWord">{{dirTechnique}}</span>
        <el-tree :data="dataTechnique" node-key="id" highlight-current
                 @node-click="(event, node) => labelWork(event, node, '技术')"
                 :default-expanded-keys = '[nodeExtend.nodeTechnique]' @node-contextmenu="rightClick"
                 :filter-node-method="filterNode" ref="tree">
          <span class="custom-tree-node" slot-scope="{ node, data }">
            <span><i :class="data.icon"></i>{{ node.label }}</span>
          </span>
        </el-tree>
      </div>
      <div class="block">
        <span style="margin: 0">程序类文件</span>
        <span class="DirWord">{{dirScript}}</span>
        <el-tree :data="dataScript" node-key="id" highlight-current
                 @node-click="(event, node) => labelWork(event, node, '程序')"
                 :default-expanded-keys = '[nodeExtend.nodeScript]' @node-contextmenu="rightClick"
                 :filter-node-method="filterNode" ref="tree">
          <span class="custom-tree-node" slot-scope="{ node, data }">
            <span><i :class="data.icon"></i>{{ node.label }}</span>
          </span>
        </el-tree>
      </div>
    </div>
    <!--右键菜单-暂时隐藏-单文件-->
    <div v-show="menuVisibleFile">
      <ul id="menuFile" class="menu">
        <!--下载单文件功能-->
        <li class="menu__item" @click="downloadFile" v-show="power_partner">下载文件</li>
        <li class="menu__item" @click="deleteFile" v-show="power_admin">删除文件</li>
        <li class="menu__item" v-show="power_guest">无可用功能</li>
      </ul>
    </div>
    <!--右键菜单-暂时隐藏-文件夹-->
    <div v-show="menuVisibleFolder">
      <ul id="menuFolder" class="menu">
        <!--往文件夹中上传功能-->
        <li class="menu__item" @click="dialogFormVisible = true" v-show="power_admin">上传文件</li>
        <li class="menu__item" @click="openFolderUpload" v-show="power_admin">上传文件夹</li>
        <li class="menu__item" @click="downloadFolder" v-show="power_partner">下载文件夹</li>
        <li class="menu__item" @click="buildFolderFormVisible = true" v-show="power_admin">新建文件夹</li>
        <li class="menu__item" @click="deleteFile" v-show="power_admin">删除文件夹</li>
        <li class="menu__item" v-show="power_guest">无可用功能</li>
      </ul>
    </div>
    <!--上传文件的表单-暂时隐藏-->
    <el-dialog title="上传文件" :visible.sync="dialogFormVisible" :close-on-click-modal="false"
               :show-close="false">
      <!--上传文件部分-->
      <el-upload
        class="upload-demo"
        ref="upload"
        :action="apiUpload"
        :data="carryData"
        :file-list="fileList"
        :auto-upload="false"
        multiple
        :on-success="resShow"
        :before-upload="checkFileSize">
        <el-button slot="trigger" size="small" type="primary">选取文件</el-button>
        <el-button style="margin-left: 10px;" size="small" type="success" @click="submitUpload">上传到服务器</el-button>
        <el-button @click="closeAndUpdate" style="margin-left: 180px">退 出</el-button>
        <div slot="tip" class="el-upload__tip">尽量不要上传大文件</div>
      </el-upload>
    </el-dialog>
    <!--新建文件夹的窗口，暂时隐藏-->
    <el-dialog title="新建文件夹" :visible.sync="buildFolderFormVisible" :close-on-click-modal="false"  @keyup.enter.native="buildFolder">
      <el-form :model="buildFolderFormData">
        <span class="buildFolderDir">当前文件夹路径：{{this.rightClickAimData.aimDir}}</span>
        <el-form-item label="文件夹名称" label-width="120px">
          <el-input v-model="buildFolderFormData.folderName" autocomplete="off"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="buildFolderFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="buildFolder">确 定</el-button>
      </div>
    </el-dialog>
    <!--上传整个文件夹的窗口，暂且隐藏-->
    <el-dialog title="上传文件夹" :visible.sync="floderUploadFormVisible" :close-on-click-modal="false"
               :show-close="false">
      <!--上传文件夹部分-->
      <a-upload action="api/uploadFolder" directory :showUploadList="false"
                :file-list="fileListFolder" :remove="handleRemove" :before-upload="handleBeforeUpload">
        <a-button :disabled="switchUploadButton"> <a-icon type="upload" /> {{wordInUploadButton}} </a-button>
      </a-upload>
      <!--进度条-->
      <el-progress type="line" :percentage="completeNumber" class="progress" :show-text="true"></el-progress>
      <!--页脚-->
      <div slot="footer" class="dialog-footer">
        <el-button @click="handleUpload">上 传</el-button>
        <el-button @click="closeFloderUpload">退 出</el-button>
      </div>
    </el-dialog>
    <!--结束-->
  </div>
</template>

<script>

export default {
  data () {
    return {
      // 页面面包屑标签的ID
      pageQuest: '0',
      // 树形图的数据,分为三部分
      // 商务类文件列表
      dataBusiness: [],
      // 技术类文件列表
      dataTechnique: [],
      // 程序类文件列表
      dataScript: [],

      // 商务类文件路径
      dirBusiness: '/商务',
      // 技术类文件路径
      dirTechnique: '/技术',
      // 程序类文件路径
      dirScript: '/程序',

      // 控制菜单显示和隐藏
      menuVisibleFile: false,
      menuVisibleFolder: false,

      // 右击时，分辨所属项目，分辨是文件还是文件夹，递归出所选路径，并存于此组参数中
      // 右击项目时会更新，同时也只有在右击菜单中才可以使用到这组数据
      rightClickAimData: {
        aimCategory: '',
        aimDir: ''
      },

      // 控制上传文件框体的显示和隐藏
      dialogFormVisible: false,

      // 上传文件列表
      fileList: [],
      // 上传文件时携带的数据
      carryData: {
        fileDir: '',
        fileQuestNumber: '',
        webkitRelativePath: ''
      },

      // 为了保持在上传后更新时，文件夹路径依然展开，储存节点
      nodeExtend: {
        nodeBusiness: 1,
        nodeTechnique: 1,
        nodeScript: 1
      },

      // 新建文件夹框体的显示和隐藏
      buildFolderFormVisible: false,
      // 绑定新建文件夹的名字
      buildFolderFormData: {
        folderName: '',
        folderDir: ''
      },
      // 用来筛选的关键字
      filterText: '',
      // 上传文件夹窗口控制显示
      floderUploadFormVisible: false,
      // 上传文件的端口拼接
      apiUpload: process.env.VUE_APP_API_URL + 'upload',
      // 上传文件列表——文件夹版本
      fileListFolder: [],
      // 文件右键时的行为-管理员/负责人级
      power_admin: false,
      // 文件右键时的行为-合作者级
      power_partner: false,
      // 文件右键时的行为-没有任何权限级，这里用的是v-if，稍微不同一点
      power_guest: true,
      // 文件夹上传时显示上传框的信息
      wordInUploadButton: '请选择要上传的文件夹',
      // 在选择文件夹后，将上传按钮禁用
      switchUploadButton: false,
      // 人工上传进度条的进度数字
      completeNumber: 0
    }
  },
  methods: {
    // 初始化文件目录
    async inputNode () {
      const { data: result } = await this.$axios.post('searchFilesList', { data: this.$route.params.id })
      this.pageQuest = result[0]
      this.dataBusiness = result[1]
      this.dataTechnique = result[2]
      this.dataScript = result[3]
    },
    // 在点击节点后的行为，分为文件夹和文件两种情况
    labelWork (e, node, message) {
      console.log(e.children)
      // 首先要判断下点击的是文件夹还是文件,根据对象是否有chindren来判断
      if (e.children === undefined) {
        // 如果是文件，则进行下载工作
        console.log('文件')
      } else {
        // 如果是文件夹，则将路径更新绑定到data
        const fullDir = this.recusionDir(node)
        switch (message) {
          case '商务':
            this.dirBusiness = fullDir
            this.nodeExtend.nodeBusiness = e.id
            break
          case '技术':
            this.dirTechnique = fullDir
            this.nodeExtend.nodeTechnique = e.id
            break
          case '程序':
            this.dirScript = fullDir
            this.nodeExtend.nodeScript = e.id
        }
      }
    },
    // 输入当前节点，输出完整路径
    recusionDir (node) {
      if (node.parent === null) {
        return ''
      }
      const nodeLabel = node.data.label
      return this.recusionDir(node.parent) + '/' + nodeLabel
    },
    // 以下为右键菜单相关的方法
    rightClick (MouseEvent, object, node) {
      // 先把两个菜单全关了
      this.menuVisibleFile = false
      this.menuVisibleFolder = false
      // 然后递归出所选路径，反正要用到
      this.rightClickAimData.aimDir = this.recusionDir(node)
      // 先判断是单文件还是文件夹
      if (object.children === undefined) {
        this.rightClickAimData.aimCategory = '单文件'
        // 然后开始处理菜单——单文件
        this.menuVisibleFile = true // 显示模态窗口，跳出自定义菜单栏
        const menu = document.querySelector('#menuFile')
        document.addEventListener('click', this.fooFile) // 给整个document添加监听鼠标事件，点击任何位置执行foo方法
        menu.style.left = MouseEvent.clientX + 10 + 'px'
        menu.style.top = MouseEvent.clientY - 10 + 'px'
      } else {
        this.rightClickAimData.aimCategory = '文件夹'
        // 然后开始处理菜单——文件夹
        this.menuVisibleFolder = true // 显示模态窗口，跳出自定义菜单栏
        const menu = document.querySelector('#menuFolder')
        document.addEventListener('click', this.fooFolder) // 给整个document添加监听鼠标事件，点击任何位置执行foo方法
        menu.style.left = MouseEvent.clientX + 10 + 'px'
        menu.style.top = MouseEvent.clientY - 10 + 'px'
      }
    },
    fooFile () { // 取消鼠标监听事件 菜单栏——单文件
      this.menuVisibleFile = false
      document.removeEventListener('click', this.fooFile) // 要及时关掉监听，不关掉的是一个坑，不信你试试，虽然前台显示的时候没有啥毛病，加一个alert你就知道了
    },
    fooFolder () { // 取消鼠标监听事件 菜单栏——文件夹
      this.menuVisibleFolder = false
      document.removeEventListener('click', this.fooFolder) // 要及时关掉监听，不关掉的是一个坑，不信你试试，虽然前台显示的时候没有啥毛病，加一个alert你就知道了
    },
    submitUpload () {
      // 上传前把当前目录放进携带信息里
      this.carryData.fileDir = this.rightClickAimData.aimDir
      this.carryData.fileQuestNumber = this.pageQuest
      // 然后就可以上传了
      this.$refs.upload.submit()
    },
    // 关闭上传框并且更新任务数据
    closeAndUpdate () {
      this.fileList = []
      this.dialogFormVisible = false
      this.inputNode()
    },
    // 返回上传时的后端信息
    resShow (res) {
      console.log(res)
    },
    // 向后端要求下载文件
    downloadFile () {
      // 希望有更好的下载方案
      const backDir = '../../fileSave/' + this.pageQuest + this.rightClickAimData.aimDir
      console.log(backDir)
      window.open(process.env.VUE_APP_DOWNLOAD_URL + backDir)
    },
    // 向后端下载打包好的文件夹：先让后端压缩，再下载压缩文件
    async downloadFolder () {
      const backDir = '../../fileSave/' + this.pageQuest + this.rightClickAimData.aimDir
      const { data: downloadURL } = await this.$axios.post('compressFolder', { dir: backDir })
      window.open(process.env.VUE_APP_DOWNLOAD_URL + downloadURL)
    },
    // 删除文件或文件夹，用一个方法就行了
    async deleteFile () {
      // 删除前弹框确认
      this.$msgbox.confirm('此操作将永久删除该文件, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        // 在得到确认后回调删除过程
        const backDir = '../../fileSave/' + this.pageQuest + this.rightClickAimData.aimDir
        this.$axios.post('deleteFile', { dir: backDir }).then(({ data: res }) => {
          // 在删除成功后给出提示
          console.log(res)
          // 在删除后重新绑定数据
          this.inputNode()
          this.$message({
            type: 'success',
            message: '删除成功!'
          })
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    },
    // 新建文件夹
    async buildFolder () {
      // 先确认不是开头空格
      if (this.buildFolderFormData.folderName[0] === ' ' || this.buildFolderFormData.folderName === '') {
        return
      }
      // 获取名字和地址并发送
      this.buildFolderFormData.folderDir = '../../fileSave/' + this.pageQuest + this.rightClickAimData.aimDir
      const { data: res } = await this.$axios.post('buildFolder', this.buildFolderFormData)
      console.log(res)
      // 弄完记得把名字清空，免得留在表单里
      this.buildFolderFormData.folderName = ''
      // 再把窗口关掉
      this.buildFolderFormVisible = false
      // 然后数据重新绑定
      await this.inputNode()
    },
    // 筛选关键字搜索功能
    filterNode (value, data) {
      if (!value) return true
      return data.label.indexOf(value) !== -1
    },
    // 打开上传文件夹的窗口
    openFolderUpload () {
      this.floderUploadFormVisible = true
    },
    // 关闭上传文件夹的窗口
    closeFloderUpload () {
      this.floderUploadFormVisible = false
      this.fileListFolder = []
      this.switchUploadButton = false
      this.wordInUploadButton = '请选择要上传的文件夹'
      this.inputNode()
    },
    // 手动上传，阻止自动上传
    handleBeforeUpload (file) {
      this.fileListFolder = [...this.fileListFolder, file]
      this.switchUploadButton = true
      this.wordInUploadButton = '准备上传：' + this.fileListFolder[0].webkitRelativePath.split('/')[0] + '/'
      return false
    },
    // 手动上传，也需要手动控制删除
    handleRemove (file) {
      const index = this.fileListFolder.indexOf(file)
      const newFileList = this.fileListFolder.slice()
      newFileList.splice(index, 1)
      this.fileListFolder = newFileList
    },
    // 手动上传的具体方法
    handleUpload () {
      // 先确认一下列表是否为空，是空的话返回
      if (this.fileListFolder.length === 0) {
        return
      }
      // 确认文件的数量和总计大小，数量不能大于200个，总大小不能超过1024mb
      if (this.fileListFolder.length > 200) {
        alert('文件超过200个，无法上传，如果有特殊需求请联系管理员！')
        return
      }
      // 再来计算所有文件的大小总和
      let sumSize = 0
      for (let i = 0; i < this.fileListFolder.length; i++) {
        sumSize += this.fileListFolder[i].size
      }
      if (sumSize > 1024 * 1024 * 1024) {
        alert('文件总大小超过1024mb，无法上传，如果有特殊需求请联系管理员！')
        return
      }
      const { fileListFolder } = this
      const formDataFolder = new FormData()
      fileListFolder.forEach(file => {
        formDataFolder.append('files[]', file)
        formDataFolder.append('webkitRelativePath[]', file.webkitRelativePath)
      })
      // 上传前把当前目录放进携带信息里
      this.carryData.fileDir = this.rightClickAimData.aimDir
      this.carryData.fileQuestNumber = this.pageQuest
      // 这里可以再添加点额外的参数，我把前置路径传一下
      formDataFolder.append('firstDir', this.carryData.fileDir)
      formDataFolder.append('questNumber', this.carryData.fileQuestNumber)
      // 接口上传文件
      this.$axios.post('uploadFolder', formDataFolder, {
        onUploadProgress: progressEvent => {
          this.completeNumber = (progressEvent.loaded / progressEvent.total).toFixed(2) * 100
        },
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
          // 'Content-Type': 'multipart/form-data'
        }
      }).then(res => {
        console.log(res.data)
        // 传完关闭
        this.completeNumber = 0
        this.closeFloderUpload()
      })
    },
    // 在进入项目时，查询权限，根据确认的权限来分配在该页面中，项目的右键功能
    async rightClickPowerCheck () {
      const checkData = {
        userInfo: window.sessionStorage.getItem('nowUser'),
        questInfo: this.$route.params.id
      }
      const { data: res } = await this.$axios.post('rightClickPowerCheck', checkData)
      // 有管理员、负责人、参与者和无权限四种情况
      if (res === '管理员' || res === '负责人') {
        this.power_admin = true
        this.power_partner = true
        this.power_guest = false
      } else if (res === '参与者') {
        this.power_admin = false
        this.power_partner = true
        this.power_guest = false
      } else {
        this.power_admin = false
        this.power_partner = false
        this.power_guest = true
      }
    },
    // 上传单个文件的时候，确认大小
    checkFileSize (file) {
      // 如果文件大于1024mb，就要返回并弹出错误信息
      if (file.size > 1024 * 1024 * 1024) {
        alert('文件：[' + file.name + ']大于1024mb！如有特殊需求可联系管理员修改配置！')
        return false
      }
      console.log(file)
    }
  },
  watch: {
    // 筛选关键字搜索功能
    filterText (val) {
      this.$refs.tree.filter(val)
    }
  },
  mounted () {
    this.$nextTick(function () {
      // 初始化文件目录
      this.inputNode()
      this.rightClickPowerCheck()
    })
  }
}
</script>

<style lang="less" scoped>
.block{
  position: relative;
  top: 10px;
  display: inline-block;
  vertical-align: top;
  margin: 0.5%;
  padding: 1%;
  width: 30%;
  border: 1px solid black;
  min-height: 100px;
  .DirWord{
    display: block;
    font-size: 10px;
  }
  .ButtonControlFile{
    width: 20px;
    height: 10px;
    font-size: 5px;
  }
}
//这之后皆为右键菜单的样式
.menu__item {
  display: block;
  line-height: 20px;
  text-align: center;
  margin: 10px 0;

}
.menu {
  padding: 0;
  width: 120px;
  position: absolute;
  border-radius: 10px;
  border: 1px solid #999999;
  background-color: #f4f4f4;
}
li:hover {
  background-color: #1790ff;
  color: white;
  cursor:pointer;
}
//新建文件夹部分的路径样式
.buildFolderDir{
  display: inline-block;
  margin-bottom: 20px;
  margin-left: 35px;
}
//上传文件夹时的进度条
.progress{
  width: 200px;
  margin-top: 10px;
}

</style>
