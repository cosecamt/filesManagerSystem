import Vue from 'vue'
// 使用AntDesign——导入
import { Button, Upload, Icon } from 'ant-design-vue'
import 'ant-design-vue/dist/antd.css'

Vue.use(Button)
Vue.use(Upload)
Vue.use(Icon)
