import Vue from 'vue'
import {
  Button, Form, FormItem, Input, Container, Header, Aside, Main, Menu, MenuItem, Row, Table,
  TableColumn, Message, MessageBox, Select, Option, Dialog, Breadcrumb, BreadcrumbItem, Tree,
  Upload, Radio, RadioButton, RadioGroup, Checkbox, CheckboxGroup, Popconfirm, Card, Divider,
  Popover, Progress
} from 'element-ui'

Vue.use(Button)
Vue.use(Form)
Vue.use(FormItem)
Vue.use(Input)
Vue.use(Container)
Vue.use(Header)
Vue.use(Aside)
Vue.use(Main)
Vue.use(Menu)
Vue.use(MenuItem)
Vue.use(Row)
Vue.use(Table)
Vue.use(TableColumn)
Vue.prototype.$message = Message
Vue.prototype.$msgbox = MessageBox
Vue.use(Select)
Vue.use(Option)
Vue.use(Dialog)
Vue.use(Breadcrumb)
Vue.use(BreadcrumbItem)
Vue.use(Tree)
Vue.use(Upload)
Vue.use(Radio)
Vue.use(RadioButton)
Vue.use(RadioGroup)
Vue.use(Checkbox)
Vue.use(CheckboxGroup)
Vue.use(Popconfirm)
Vue.use(Card)
Vue.use(Divider)
Vue.use(Popover)
Vue.use(Progress)
