import Vue from 'vue'
import VueRouter from 'vue-router'

// 导入页面
import Login from '@/views/Login'
import Main from '@/views/main/Main'
import MainWelcome from '@/views/main/MainWelcome'
import MainQuestList from '@/views/main/MainQuestList'
import MainFileList from '@/views/subpages/MainFileList'
import MainPower from '@/views/main/MainPower'
import MainTotalStatus from '@/views/main/MainTotalStatus'
import MainBackup from "@/views/main/MainBackup";
import MainProcess from "@/views/main/MainProcess";
import MainJournal from "@/views/main/MainJournal";
import MainDelete from "@/views/main/MainDelete";
import MainSpace from "@/views/main/MainSpace";

Vue.use(VueRouter)

const router = new VueRouter({
  routes: [
    {
      // 登录界面
      path: '/',
      component: Login
    },
    {
      // 用户主页
      path: '/main',
      component: Main,
      children: [
        // 用户-欢迎页面
        { path: '/main/welcome', component: MainWelcome },
        // 用户-任务列表
        { path: '/main/questlist', component: MainQuestList },
        // 用户-任务-文件列表(需传参)
        { path: '/main/filelist/:id', component: MainFileList },
        // 用户-权限管理
        { path: '/main/power', component: MainPower },
        // 用户-文件备份
        { path: '/main/backup', component: MainBackup },
        // 用户-进度管理
        { path: '/main/process', component: MainProcess },
        // 用户-操作日志
        { path: '/main/journal', component: MainJournal },
        // 用户-删除回收
        { path: '/main/delete', component: MainDelete },
        // 用户-储存空间
        { path: '/main/space', component: MainSpace },
        // 用户-总体浏览
        { path: '/main/total', component: MainTotalStatus }
      ]
    }
  ]
})

router.beforeEach((to, form, next) => {
  if (to.path === '/') return next()

  const tokenStr = window.sessionStorage.getItem('token')
  if (!tokenStr) return next('/')
  next()
})

export default router
