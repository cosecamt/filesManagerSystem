// vue.config.js

// 跨域
module.exports = {
  devServer: {
    proxy: {
      // 配置跨域
      '/api': {
        // target: 'http://www.tp6env.com/',
        target: 'http://127.0.0.1/ProjectForCompany/210328_FileSystem/filesystem_back/public/',
        changOrigin: true, // 设置允许跨域
        pathRewrite: { '^/api': '' }
      }
    }
  },

  // 打包地址修正
  lintOnSave: true,
  publicPath: './',
  outputDir: 'dist',
  assetsDir: 'static'

}
